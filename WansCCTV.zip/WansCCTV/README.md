# WansCCTV (versi rekam + akses keluarga)
- Build: push ke GitHub, ambil APK dari Actions (apk-kamera, apk-monitor). Workflow: .github/workflows/build.yml
- Rekaman disimpan di: Android/data/com.wans.cctv.camera/files/rekaman (kartu SD jika terdeteksi)
- Playback: tombol "Rekaman" di layar utama Monitor (langsung terbuka di aplikasi), atau lewat browser: http://ALAMAT:8080/playback?k=KUNCI
