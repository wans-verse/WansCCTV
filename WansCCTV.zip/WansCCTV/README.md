# WansCCTV (versi rekam + akses keluarga)
- Build: push ke GitHub, ambil APK dari Actions (apk-kamera, apk-monitor). Workflow: .github/workflows/build.yml
- Rekaman disimpan di: Android/data/com.wans.cctv.camera/files/rekaman (kartu SD jika terdeteksi)
- Playback: http://ALAMAT:8080/playback?k=KUNCI
