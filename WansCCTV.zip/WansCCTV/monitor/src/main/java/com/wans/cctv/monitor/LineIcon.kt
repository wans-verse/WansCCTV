package com.wans.cctv.monitor

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View

/** Ikon garis tipis satu gaya, digambar langsung (tanpa emoji dan tanpa file gambar). */
class LineIcon(ctx: Context, private val kind: String, tint0: Int = 0xFFFFFFFF.toInt(), private val sizeFrac: Float = 0.46f) : View(ctx) {

    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private var col = tint0

    /** Khusus ikon baterai: tampilkan petir di dalamnya saat sedang di-charge. */
    var charging = false
        set(v) { field = v; invalidate() }

    fun setColor(c: Int) {
        col = c
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height) * sizeFrac
        val u = s / 24f
        p.color = col
        p.strokeWidth = maxOf(1.5f * resources.displayMetrics.density, 1f)
        c.save()
        c.translate((width - s) / 2f, (height - s) / 2f)
        c.scale(u, u)
        // Karena strokeWidth sudah dalam piksel, bagi dengan skala supaya tebalnya tetap.
        p.strokeWidth = p.strokeWidth / u
        drawIcon(c)
        c.restore()
    }

    private fun line(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float) = c.drawLine(x1, y1, x2, y2, p)

    private fun drawIcon(c: Canvas) {
        when (kind) {
            "flash" -> { // senter
                val a = Path().apply { moveTo(8f, 3f); lineTo(16f, 3f); lineTo(15f, 9f); lineTo(9f, 9f); close() }
                c.drawPath(a, p)
                c.drawRoundRect(RectF(9f, 9f, 15f, 21f), 2f, 2f, p)
                line(c, 12f, 13f, 12f, 16f)
            }
            "mic" -> {
                c.drawRoundRect(RectF(9f, 3f, 15f, 14f), 3f, 3f, p)
                val a = Path().apply { moveTo(5f, 11f); cubicTo(5f, 17f, 19f, 17f, 19f, 11f) }
                c.drawPath(a, p)
                line(c, 12f, 17f, 12f, 21f)
            }
            "apps" -> {
                c.drawRoundRect(RectF(4f, 4f, 10.5f, 10.5f), 2f, 2f, p)
                c.drawRoundRect(RectF(13.5f, 4f, 20f, 10.5f), 2f, 2f, p)
                c.drawRoundRect(RectF(4f, 13.5f, 10.5f, 20f), 2f, 2f, p)
                c.drawRoundRect(RectF(13.5f, 13.5f, 20f, 20f), 2f, 2f, p)
            }
            "screen" -> {
                c.drawRoundRect(RectF(3f, 4f, 21f, 16f), 2f, 2f, p)
                line(c, 9f, 20f, 15f, 20f)
                line(c, 12f, 16f, 12f, 20f)
            }
            "pad" -> { // kontrol arah
                c.drawCircle(12f, 12f, 9f, p)
                line(c, 12f, 6.5f, 12f, 9f)
                line(c, 12f, 15f, 12f, 17.5f)
                line(c, 6.5f, 12f, 9f, 12f)
                line(c, 15f, 12f, 17.5f, 12f)
            }
            "flip" -> { // balik kamera
                val a = Path().apply { moveTo(4f, 12f); cubicTo(4f, 7f, 8f, 4.5f, 12f, 4.5f); cubicTo(14.5f, 4.5f, 17f, 5.6f, 18.5f, 7.5f) }
                c.drawPath(a, p)
                val ah = Path().apply { moveTo(18.8f, 3.5f); lineTo(18.8f, 7.8f); lineTo(14.5f, 7.8f) }
                c.drawPath(ah, p)
                val b = Path().apply { moveTo(20f, 12f); cubicTo(20f, 17f, 16f, 19.5f, 12f, 19.5f); cubicTo(9.5f, 19.5f, 7f, 18.4f, 5.5f, 16.5f) }
                c.drawPath(b, p)
                val bh = Path().apply { moveTo(5.2f, 20.5f); lineTo(5.2f, 16.2f); lineTo(9.5f, 16.2f) }
                c.drawPath(bh, p)
            }
            "full" -> { // layar penuh: empat sudut
                c.drawPath(Path().apply { moveTo(4f, 9f); lineTo(4f, 4f); lineTo(9f, 4f) }, p)
                c.drawPath(Path().apply { moveTo(15f, 4f); lineTo(20f, 4f); lineTo(20f, 9f) }, p)
                c.drawPath(Path().apply { moveTo(20f, 15f); lineTo(20f, 20f); lineTo(15f, 20f) }, p)
                c.drawPath(Path().apply { moveTo(9f, 20f); lineTo(4f, 20f); lineTo(4f, 15f) }, p)
            }
            "exitfull" -> { // keluar layar penuh: empat sudut menghadap ke dalam
                c.drawPath(Path().apply { moveTo(9f, 4f); lineTo(9f, 9f); lineTo(4f, 9f) }, p)
                c.drawPath(Path().apply { moveTo(15f, 4f); lineTo(15f, 9f); lineTo(20f, 9f) }, p)
                c.drawPath(Path().apply { moveTo(20f, 15f); lineTo(15f, 15f); lineTo(15f, 20f) }, p)
                c.drawPath(Path().apply { moveTo(4f, 15f); lineTo(9f, 15f); lineTo(9f, 20f) }, p)
            }
            "battery" -> {
                c.drawRoundRect(RectF(2f, 7f, 20f, 17f), 2.5f, 2.5f, p)
                line(c, 22.5f, 10.5f, 22.5f, 13.5f)
                if (charging) {
                    val st = p.style
                    p.style = Paint.Style.FILL
                    c.drawPath(Path().apply {
                        moveTo(12.5f, 8f); lineTo(7.5f, 12.6f); lineTo(10.6f, 12.6f)
                        lineTo(9.5f, 16f); lineTo(14.5f, 11.4f); lineTo(11.4f, 11.4f); close()
                    }, p)
                    p.style = st
                }
            }
            "sun" -> { // filter kecerahan
                c.drawCircle(12f, 12f, 4.2f, p)
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0)
                    val cs = Math.cos(a).toFloat(); val sn = Math.sin(a).toFloat()
                    line(c, 12f + cs * 7.6f, 12f + sn * 7.6f, 12f + cs * 10f, 12f + sn * 10f)
                }
            }
            "ear" -> { // headphone
                c.drawPath(Path().apply { moveTo(4f, 15f); lineTo(4f, 12f); cubicTo(4f, 5f, 20f, 5f, 20f, 12f); lineTo(20f, 15f) }, p)
                c.drawRoundRect(RectF(3f, 14f, 8f, 20f), 2f, 2f, p)
                c.drawRoundRect(RectF(16f, 14f, 21f, 20f), 2f, 2f, p)
            }
            "say" -> { // gelembung pesan
                c.drawPath(Path().apply {
                    moveTo(7f, 4f); lineTo(17f, 4f); cubicTo(19.2f, 4f, 21f, 5.8f, 21f, 8f)
                    lineTo(21f, 12f); cubicTo(21f, 14.2f, 19.2f, 16f, 17f, 16f)
                    lineTo(11f, 16f); lineTo(6.5f, 20f); lineTo(7f, 16f)
                    cubicTo(4.8f, 16f, 3f, 14.2f, 3f, 12f); lineTo(3f, 8f); cubicTo(3f, 5.8f, 4.8f, 4f, 7f, 4f); close()
                }, p)
                line(c, 8f, 9f, 16f, 9f)
                line(c, 8f, 12.5f, 13f, 12.5f)
            }
            "chevdown" -> c.drawPath(Path().apply { moveTo(5f, 9f); lineTo(12f, 16f); lineTo(19f, 9f) }, p)
            "chevup" -> c.drawPath(Path().apply { moveTo(5f, 15f); lineTo(12f, 8f); lineTo(19f, 15f) }, p)
            "rotate" -> { // putar gambar: panah melingkar + bingkai kecil
                val a = Path().apply {
                    moveTo(20f, 12f); cubicTo(20f, 16.4f, 16.4f, 20f, 12f, 20f)
                    cubicTo(7.6f, 20f, 4f, 16.4f, 4f, 12f); cubicTo(4f, 7.6f, 7.6f, 4f, 12f, 4f)
                    cubicTo(14.5f, 4f, 16.8f, 5.1f, 18.4f, 6.9f)
                }
                c.drawPath(a, p)
                c.drawPath(Path().apply { moveTo(19f, 3f); lineTo(19f, 7.4f); lineTo(14.6f, 7.4f) }, p)
                c.drawRoundRect(RectF(9f, 9f, 15f, 15f), 1.5f, 1.5f, p)
            }
            "grip" -> { // pegangan ubah ukuran: dua garis miring di pojok kanan bawah
                line(c, 20f, 9f, 9f, 20f)
                line(c, 20f, 15f, 15f, 20f)
            }
            "close" -> {
                line(c, 6f, 6f, 18f, 18f)
                line(c, 18f, 6f, 6f, 18f)
            }
            "back" -> {
                val a = Path().apply { moveTo(15f, 5f); lineTo(8f, 12f); lineTo(15f, 19f) }
                c.drawPath(a, p)
            }
            "home" -> c.drawCircle(12f, 12f, 7f, p)
            "recents" -> c.drawRoundRect(RectF(5f, 5f, 19f, 19f), 3f, 3f, p)
            "bell" -> {
                val a = Path().apply {
                    moveTo(6f, 17f); lineTo(6f, 11f); cubicTo(6f, 5f, 18f, 5f, 18f, 11f); lineTo(18f, 17f); close()
                }
                c.drawPath(a, p)
                line(c, 4.5f, 17f, 19.5f, 17f)
                val b = Path().apply { moveTo(10f, 20f); cubicTo(10.8f, 21.6f, 13.2f, 21.6f, 14f, 20f) }
                c.drawPath(b, p)
            }
            "gear" -> {
                c.drawCircle(12f, 12f, 3.2f, p)
                c.drawCircle(12f, 12f, 7f, p)
                for (k in 0 until 8) {
                    val ang = Math.toRadians(k * 45.0)
                    val cs = Math.cos(ang).toFloat()
                    val sn = Math.sin(ang).toFloat()
                    line(c, 12f + cs * 7f, 12f + sn * 7f, 12f + cs * 9.8f, 12f + sn * 9.8f)
                }
            }
            "photo" -> {
                c.drawRoundRect(RectF(3f, 7f, 21f, 19f), 3f, 3f, p)
                line(c, 8f, 7f, 9.5f, 4.5f)
                line(c, 9.5f, 4.5f, 14.5f, 4.5f)
                line(c, 14.5f, 4.5f, 16f, 7f)
                c.drawCircle(12f, 13f, 3.2f, p)
            }
        }
    }
}
