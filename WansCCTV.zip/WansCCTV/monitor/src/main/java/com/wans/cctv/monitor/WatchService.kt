package com.wans.cctv.monitor

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.content.ContextCompat
import java.net.HttpURLConnection
import java.net.URL

/**
 * Memantau kamera di latar belakang: cek /status tiap 30 detik.
 * Kalau kamera tidak menjawab selama 2 menit, muncul notifikasi "Kamera tidak terhubung";
 * saat tersambung lagi muncul notifikasi "Kamera kembali online".
 */
class WatchService : Service() {

    companion object {
        private const val CH_WATCH = "cctv_watch"
        private const val CH_ALERT = "cctv_alert"
        private const val ID_WATCH = 11
        private const val ID_ALERT = 12
        private const val INTERVAL_MS = 30_000L
        private const val OFFLINE_AFTER_MS = 120_000L

        @Volatile var running = false

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, WatchService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, WatchService::class.java))
        }
    }

    @Volatile private var alive = false
    private var worker: Thread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_WATCH, "Pemantauan kamera", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_ALERT, "Peringatan kamera", NotificationManager.IMPORTANCE_HIGH))
        val n = Notification.Builder(this, CH_WATCH)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Memantau kamera")
            .setContentText("Akan memberi tahu jika kamera tidak terhubung")
            .setOngoing(true)
            .setContentIntent(openApp())
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(ID_WATCH, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(ID_WATCH, n)
            }
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        running = true
        if (worker == null) {
            alive = true
            worker = Thread { loop() }.also { it.start() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        alive = false
        running = false
        worker?.interrupt()
        worker = null
        super.onDestroy()
    }

    private fun openApp(): PendingIntent = PendingIntent.getActivity(
        this, 0,
        Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun ping(base: String, key: String): Boolean {
        val url = base + "/status" + (if (key.isEmpty()) "" else "?k=$key")
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 4000
        c.readTimeout = 4000
        return try {
            c.inputStream.bufferedReader().readText().contains("cam=")
        } finally {
            c.disconnect()
        }
    }

    private fun alert(title: String, text: String) {
        val n = Notification.Builder(this, CH_ALERT)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(title)
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(openApp())
            .build()
        getSystemService(NotificationManager::class.java).notify(ID_ALERT, n)
    }

    private fun loop() {
        val prefs = getSharedPreferences("cctv", MODE_PRIVATE)
        var lastOk = System.currentTimeMillis()
        var offline = false
        while (alive) {
            if (!prefs.getBoolean("watch", true)) {
                stopSelf()
                break
            }
            val base = prefs.getString("base", null)
            val key = prefs.getString("key", "") ?: ""
            val ok = base != null && try { ping(base, key) } catch (e: Exception) { false }
            val now = System.currentTimeMillis()
            if (ok) {
                if (offline) {
                    offline = false
                    alert("Kamera kembali online", "Kamera sudah tersambung lagi.")
                }
                lastOk = now
            } else if (!offline && base != null && now - lastOk >= OFFLINE_AFTER_MS) {
                offline = true
                alert("Kamera tidak terhubung", "Kamera tidak menjawab lebih dari 2 menit. Cek listrik atau WiFi HP kamera.")
            }
            try {
                Thread.sleep(INTERVAL_MS)
            } catch (e: InterruptedException) {
                break
            }
        }
    }
}
