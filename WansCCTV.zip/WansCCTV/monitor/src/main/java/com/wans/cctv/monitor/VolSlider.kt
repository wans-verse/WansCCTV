package com.wans.cctv.monitor

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

/** Slider volume vertikal (gaya panel volume iOS): geser ke atas = lebih keras. Rentang 10–100. */
class VolSlider(ctx: Context) : View(ctx) {

    companion object {
        const val MIN = 10
        const val MAX = 100
    }

    var onChange: ((Int) -> Unit)? = null
    var onDone: (() -> Unit)? = null

    var value: Int = MAX
        set(v) {
            field = v.coerceIn(MIN, MAX)
            invalidate()
        }

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#CC1C1C1E") }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val rect = RectF()
    private val clip = Path()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = w / 2f
        rect.set(0f, 0f, w, h)
        c.drawRoundRect(rect, r, r, bg)
        val top = h - h * (value / 100f)
        clip.reset()
        clip.addRoundRect(rect, r, r, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        c.drawRect(0f, top, w, h, fill)
        c.restore()
        txt.textSize = w * 0.3f
        txt.color = if (top < w * 0.75f) Color.BLACK else Color.parseColor("#8E8E93")
        c.drawText("$value%", w / 2f, w * 0.85f, txt)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                setFromY(e.y)
            }
            MotionEvent.ACTION_MOVE -> setFromY(e.y)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> onDone?.invoke()
        }
        return true
    }

    private fun setFromY(y: Float) {
        val f = 1f - (y / height.coerceAtLeast(1)).coerceIn(0f, 1f)
        value = (f * 100f).toInt()
        onChange?.invoke(value)
    }
}
