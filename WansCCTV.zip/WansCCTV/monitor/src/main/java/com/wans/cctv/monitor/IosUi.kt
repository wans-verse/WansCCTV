package com.wans.cctv.monitor

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ClipDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.StateListDrawable
import android.text.InputType
import android.util.StateSet
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

/** Komponen tampilan gaya iOS (mode gelap): dialog, action sheet, kolom isian, toast, slider. */
object IosUi {
    const val NORMAL = 0
    const val BOLD = 1
    const val DESTRUCTIVE = 2
    const val CANCEL = 3

    val BG = Color.parseColor("#F22C2C2E")
    val SEP = Color.parseColor("#80545458")
    val BLUE = Color.parseColor("#0A84FF")
    val RED = Color.parseColor("#FF453A")
    val SUB = Color.parseColor("#99EBEBF5")

    fun dp(ctx: Context, v: Float) = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

    fun round(color: Int, radiusPx: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radiusPx.toFloat()
    }

    /** Kolom isian iOS: kotak bulat gelap tanpa garis bawah. */
    fun field(ctx: Context, hint: String, type: Int = InputType.TYPE_CLASS_TEXT, text: String? = null): EditText =
        EditText(ctx).apply {
            this.hint = hint
            inputType = type
            setSingleLine(true)
            if (text != null) setText(text)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#66EBEBF5"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            background = round(Color.parseColor("#59000000"), dp(ctx, 9f))
            setPadding(dp(ctx, 12f), dp(ctx, 10f), dp(ctx, 12f), dp(ctx, 10f))
            // setTextCursorDrawable baru ada di Android 10 (API 29); di bawah itu bikin crash.
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                textCursorDrawable = GradientDrawable().apply {
                    setColor(BLUE)
                    setSize(dp(ctx, 2f), -1)
                }
            }
        }

    /** Pemberitahuan singkat berbentuk pil di bawah layar, pengganti Toast bawaan Android. */
    fun toast(act: Activity, msg: String, long: Boolean = false) {
        val host = act.findViewById<ViewGroup>(android.R.id.content) ?: return
        host.findViewWithTag<View>("ios_toast")?.let { host.removeView(it) }
        val t = TextView(act).apply {
            tag = "ios_toast"
            text = msg
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setPadding(dp(act, 18f), dp(act, 11f), dp(act, 18f), dp(act, 11f))
            background = round(Color.parseColor("#E62C2C2E"), dp(act, 22f))
            maxWidth = (act.resources.displayMetrics.widthPixels * 0.86f).toInt()
            elevation = dp(act, 6f).toFloat()
            alpha = 0f
        }
        host.addView(
            t,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).apply { bottomMargin = dp(act, 96f) }
        )
        t.animate().alpha(1f).setDuration(160).start()
        t.postDelayed({
            t.animate().alpha(0f).setDuration(220).withEndAction { host.removeView(t) }.start()
        }, if (long) 3500L else 1800L)
    }

    /** Slider iOS: garis tipis, bagian terisi biru, gagang putih bulat. */
    fun styleSeekBar(bar: SeekBar) {
        val c = bar.context
        val track = GradientDrawable().apply {
            setColor(Color.parseColor("#40FFFFFF"))
            cornerRadius = dp(c, 2f).toFloat()
            setSize(-1, dp(c, 4f))
        }
        val fill = GradientDrawable().apply {
            setColor(BLUE)
            cornerRadius = dp(c, 2f).toFloat()
            setSize(-1, dp(c, 4f))
        }
        val layers = LayerDrawable(arrayOf<Drawable>(track, ClipDrawable(fill, Gravity.START, ClipDrawable.HORIZONTAL)))
        layers.setId(0, android.R.id.background)
        layers.setId(1, android.R.id.progress)
        bar.progressTintList = null
        bar.thumbTintList = null
        bar.progressDrawable = layers
        bar.thumb = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.WHITE)
            setSize(dp(c, 26f), dp(c, 26f))
            setStroke(1, Color.parseColor("#22000000"))
        }
        bar.splitTrack = false
        bar.setPadding(dp(c, 13f), 0, dp(c, 13f), 0)
    }
}

private class MaxHeightScroll(ctx: Context, private val maxH: Int) : ScrollView(ctx) {
    override fun onMeasure(w: Int, h: Int) {
        super.onMeasure(w, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
    }
}

/**
 * Dialog gaya iOS. Dua bentuk:
 * - alert (tengah layar): judul, pesan, isi, tombol sebaris (2 tombol) atau bertumpuk.
 * - action sheet (dari bawah): dipakai kalau memanggil [items].
 */
class IosDialog(private val act: Activity) {
    private class Btn(val text: String, val style: Int, val dismiss: Boolean, val onClick: (() -> Unit)?)

    private var title: String? = null
    private var message: String? = null
    private var content: View? = null
    private var cancelable = true
    private val buttons = ArrayList<Btn>()
    private var items: List<String>? = null
    private var onPick: ((Int) -> Unit)? = null
    private var dlg: Dialog? = null
    private var err: TextView? = null

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    fun title(t: String) = apply { title = t }
    fun message(m: String) = apply { message = m }
    fun content(v: View) = apply { content = v }
    fun cancelable(b: Boolean) = apply { cancelable = b }
    fun items(list: List<String>, pick: (Int) -> Unit) = apply { items = list; onPick = pick }
    fun button(text: String, style: Int = IosUi.NORMAL, dismiss: Boolean = true, onClick: (() -> Unit)? = null) =
        apply { buttons.add(Btn(text, style, dismiss, onClick)) }

    fun setError(msg: String?) {
        err?.text = msg ?: ""
        err?.visibility = if (msg.isNullOrEmpty()) View.GONE else View.VISIBLE
    }

    fun dismiss() {
        dlg?.dismiss()
    }

    private fun dp(v: Float) = IosUi.dp(act, v)

    private fun txt(t: String, sp: Float, color: Int, bold: Boolean) = TextView(act).apply {
        text = t
        gravity = Gravity.CENTER
        setTextColor(color)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    }

    private fun lp(w: Int, h: Int, top: Float = 0f) = LinearLayout.LayoutParams(w, h).apply { topMargin = dp(top) }

    private fun divider() = View(act).apply { setBackgroundColor(IosUi.SEP) }

    private fun pressBg() = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), ColorDrawable(Color.parseColor("#33FFFFFF")))
        addState(StateSet.WILD_CARD, ColorDrawable(Color.TRANSPARENT))
    }

    private fun row(text: String, color: Int, bold: Boolean, sp: Float, onClick: () -> Unit) =
        txt(text, sp, color, bold).apply {
            background = pressBg()
            isClickable = true
            setOnClickListener { onClick() }
        }

    private fun btnView(b: Btn, sp: Float) = row(
        b.text,
        if (b.style == IosUi.DESTRUCTIVE) IosUi.RED else IosUi.BLUE,
        b.style == IosUi.BOLD,
        sp
    ) {
        if (b.dismiss) dismiss()
        b.onClick?.invoke()
    }

    private fun card() = LinearLayout(act).apply {
        orientation = LinearLayout.VERTICAL
        background = IosUi.round(IosUi.BG, dp(14f))
        clipToOutline = true
    }

    private fun buildAlert(): View {
        val card = card()
        val top = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16f), dp(20f), dp(16f), dp(16f))
        }
        title?.let { top.addView(txt(it, 17f, Color.WHITE, true), lp(MATCH, WRAP)) }
        message?.let { top.addView(txt(it, 13f, IosUi.SUB, false), lp(MATCH, WRAP, if (title != null) 4f else 0f)) }
        content?.let { top.addView(it, lp(MATCH, WRAP, 14f)) }
        val e = txt("", 12f, IosUi.RED, false).apply {
            gravity = Gravity.START
            visibility = View.GONE
        }
        err = e
        top.addView(e, lp(MATCH, WRAP, 6f))
        val scroll = MaxHeightScroll(act, (act.resources.displayMetrics.heightPixels * 0.55f).toInt()).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(top)
        }
        card.addView(scroll, lp(MATCH, WRAP))
        if (buttons.isNotEmpty()) {
            card.addView(divider(), lp(MATCH, 1))
            if (buttons.size <= 2) {
                val r = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
                buttons.forEachIndexed { i, b ->
                    if (i > 0) r.addView(divider(), LinearLayout.LayoutParams(1, MATCH))
                    r.addView(btnView(b, 17f), LinearLayout.LayoutParams(0, dp(44f), 1f))
                }
                card.addView(r, lp(MATCH, WRAP))
            } else {
                buttons.forEachIndexed { i, b ->
                    if (i > 0) card.addView(divider(), lp(MATCH, 1))
                    card.addView(btnView(b, 17f), lp(MATCH, dp(44f)))
                }
            }
        }
        return card
    }

    private fun buildSheet(): View {
        val root = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        val group = card()
        if (title != null || message != null) {
            val head = LinearLayout(act).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16f), dp(14f), dp(16f), dp(12f))
            }
            title?.let { head.addView(txt(it, 13f, IosUi.SUB, true), lp(MATCH, WRAP)) }
            message?.let { head.addView(txt(it, 13f, IosUi.SUB, false), lp(MATCH, WRAP, 2f)) }
            group.addView(head, lp(MATCH, WRAP))
        }
        fun add(v: View) {
            if (group.childCount > 0) group.addView(divider(), lp(MATCH, 1))
            group.addView(v, lp(MATCH, dp(56f)))
        }
        items?.forEachIndexed { i, s ->
            add(row(s, IosUi.BLUE, false, 19f) {
                dismiss()
                onPick?.invoke(i)
            })
        }
        buttons.filter { it.style != IosUi.CANCEL }.forEach { add(btnView(it, 19f)) }
        root.addView(group, lp(MATCH, WRAP))
        buttons.firstOrNull { it.style == IosUi.CANCEL }?.let { c ->
            val cc = card()
            cc.addView(row(c.text, IosUi.BLUE, true, 19f) {
                if (c.dismiss) dismiss()
                c.onClick?.invoke()
            }, lp(MATCH, dp(56f)))
            root.addView(cc, lp(MATCH, WRAP, 8f))
        }
        return root
    }

    private fun findEdit(v: View): EditText? {
        if (v is EditText) return v
        if (v is ViewGroup) for (i in 0 until v.childCount) findEdit(v.getChildAt(i))?.let { return it }
        return null
    }

    fun show(): IosDialog {
        val sheet = items != null
        val root = if (sheet) buildSheet() else buildAlert()
        val d = Dialog(act)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        d.setContentView(root)
        d.setCancelable(cancelable)
        d.setCanceledOnTouchOutside(cancelable)
        val edit = content?.let { findEdit(it) }
        d.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            setDimAmount(0.45f)
            val sw = act.resources.displayMetrics.widthPixels
            setLayout(
                if (sheet) sw - dp(16f) else minOf(dp(280f), sw - dp(48f)),
                WindowManager.LayoutParams.WRAP_CONTENT
            )
            setGravity(if (sheet) Gravity.BOTTOM else Gravity.CENTER)
            setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or
                    (if (edit != null) WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE else 0)
            )
        }
        dlg = d
        d.show()
        edit?.requestFocus()
        root.alpha = 0f
        if (sheet) root.translationY = dp(60f).toFloat() else {
            root.scaleX = 1.08f
            root.scaleY = 1.08f
        }
        root.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
            .setDuration(180).setInterpolator(DecelerateInterpolator()).start()
        return this
    }
}
