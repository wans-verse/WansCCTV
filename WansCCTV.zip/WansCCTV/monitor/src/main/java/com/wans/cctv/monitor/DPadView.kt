package com.wans.cctv.monitor

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View

/**
 * Tombol arah bulat: lingkaran tipis dengan 4 panah (atas, bawah, kiri, kanan)
 * dan satu titik di tengah untuk tap. Semua digambar langsung, warnanya transparan tipis.
 */
class DPadView(ctx: Context) : View(ctx) {

    /** dir: 0 atas, 1 bawah, 2 kiri, 3 kanan. */
    var onDirDown: ((Int) -> Unit)? = null
    var onDirUp: (() -> Unit)? = null
    var onCenterTap: (() -> Unit)? = null
    var onCenterLong: (() -> Unit)? = null

    private val dens = resources.displayMetrics.density
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x14FFFFFF }
    private val press = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x26FFFFFF }
    private val icon = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = 0x99FFFFFF.toInt()
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x99FFFFFF.toInt() }

    private var active = -1 // -1 tidak ada, 0..3 arah, 4 tengah
    private val h = Handler(Looper.getMainLooper())
    private var longFired = false
    private val longRun = Runnable {
        longFired = true
        onCenterLong?.invoke()
    }

    override fun onMeasure(w: Int, hh: Int) {
        val s = (200 * dens).toInt()
        setMeasuredDimension(s, s)
    }

    private fun zone(x: Float, y: Float): Int {
        val cx = width / 2f
        val cy = height / 2f
        val dx = x - cx
        val dy = y - cy
        val r = Math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
        val R = minOf(width, height) / 2f
        if (r > R) return -1
        if (r < R * 0.28f) return 4
        return if (Math.abs(dx) > Math.abs(dy)) {
            if (dx < 0) 2 else 3
        } else {
            if (dy < 0) 0 else 1
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val z = zone(e.x, e.y)
                if (z < 0) return false
                parent?.requestDisallowInterceptTouchEvent(true)
                active = z
                longFired = false
                if (z == 4) h.postDelayed(longRun, 450) else onDirDown?.invoke(z)
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                // Kalau jari keluar dari zona awal, hentikan.
                if (active in 0..3 && zone(e.x, e.y) != active) release(false)
                if (active == 4 && zone(e.x, e.y) != 4) release(false)
            }
            MotionEvent.ACTION_UP -> release(true)
            MotionEvent.ACTION_CANCEL -> release(false)
        }
        return true
    }

    private fun release(fire: Boolean) {
        h.removeCallbacks(longRun)
        if (active in 0..3) onDirUp?.invoke()
        if (active == 4 && fire && !longFired) onCenterTap?.invoke()
        active = -1
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val R = minOf(width, height) / 2f
        c.drawCircle(cx, cy, R, ring)

        // sorotan saat ditekan
        if (active == 4) c.drawCircle(cx, cy, R * 0.28f, press)
        if (active in 0..3) {
            val ox = if (active == 2) -R * 0.62f else if (active == 3) R * 0.62f else 0f
            val oy = if (active == 0) -R * 0.62f else if (active == 1) R * 0.62f else 0f
            c.drawCircle(cx + ox, cy + oy, R * 0.26f, press)
        }

        icon.strokeWidth = 2.2f * dens
        val a = R * 0.13f // setengah lebar panah
        val d = R * 0.62f // jarak dari tengah
        fun chev(dx: Float, dy: Float, p: Path) {
            c.save(); c.translate(cx + dx, cy + dy); c.drawPath(p, icon); c.restore()
        }
        chev(0f, -d, Path().apply { moveTo(-a, a * 0.5f); lineTo(0f, -a * 0.5f); lineTo(a, a * 0.5f) })
        chev(0f, d, Path().apply { moveTo(-a, -a * 0.5f); lineTo(0f, a * 0.5f); lineTo(a, -a * 0.5f) })
        chev(-d, 0f, Path().apply { moveTo(a * 0.5f, -a); lineTo(-a * 0.5f, 0f); lineTo(a * 0.5f, a) })
        chev(d, 0f, Path().apply { moveTo(-a * 0.5f, -a); lineTo(a * 0.5f, 0f); lineTo(-a * 0.5f, a) })

        // titik tengah
        c.drawCircle(cx, cy, 6f * dens, dot)
    }
}
