package com.wans.cctv.monitor

import android.Manifest
import android.app.AlertDialog
import android.content.ContentValues
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.MediaStore
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import java.io.BufferedInputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Collections
import java.util.Date
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

private val BG = Color.BLACK
private val CARD = Color.parseColor("#1C1C1E")
private val GRAY = Color.parseColor("#8E8E93")
private val WHITE = Color.WHITE
private val BLUE = Color.parseColor("#0A84FF")
private val GREEN = Color.parseColor("#30D158")
private val RED = Color.parseColor("#FF453A")
private val ORANGE = Color.parseColor("#FF9F0A")
private val RED_BG = Color.parseColor("#3A1E1E")
private val SEG_BG = Color.parseColor("#3A3A3C")
private val SEG_SEL = Color.parseColor("#636366")
private val GLASS = Color.parseColor("#CC1C1C1E")
private val YELLOW = Color.parseColor("#FFD60A")
private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
private const val PORT = 8080
private const val TALK_PORT = 8081

class MainActivity : ComponentActivity() {

    private val prefs by lazy { getSharedPreferences("cctv", MODE_PRIVATE) }

    private lateinit var root: FrameLayout
    private lateinit var home: LinearLayout
    private lateinit var viewer: FrameLayout
    private lateinit var top: LinearLayout
    private lateinit var panel: LinearLayout
    private lateinit var statusDot: View
    private lateinit var statusText: TextView
    private lateinit var startBtn: TextView
    private lateinit var video: ImageView
    private lateinit var liveDot: View
    private lateinit var liveText: TextView
    private lateinit var btnFlip: View
    private var camFront = false
    private lateinit var zoomTag: TextView
    private var vZoom = 1f
    private var vPanX = 0f
    private var vPanY = 0f
    private var vBmpW = 0
    private var vBmpH = 0
    private lateinit var scaleDet: android.view.ScaleGestureDetector
    private lateinit var tapDet: android.view.GestureDetector
    private lateinit var btnFlash: LineIcon
    private lateinit var btnMic: LineIcon
    private lateinit var btnApp: LineIcon
    private lateinit var btnScreen: LineIcon
    private lateinit var btnPad: LineIcon
    private lateinit var btnPadTop: LineIcon
    private lateinit var pad: LinearLayout
    private var padScale = 1f
    private var padPlaced = false
    private var padRepeat: Runnable? = null
    private var touchOk = false

    @Volatile private var base: String? = null
    @Volatile private var streaming = false
    @Volatile private var conn: HttpURLConnection? = null
    @Volatile private var lastBitmap: Bitmap? = null
    private var gen = 0
    private var rotIdx = 0
    private var flashOk = false
    private var torchOn = false
    private var appsOk: Set<String> = setOf("wa", "cam", "fb", "tt")
    private var screenMode = false
    private var talkFlag: AtomicBoolean? = null

    private val micPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        toast(if (ok) "Izin mikrofon diberikan. Tahan tombol Bicara untuk bicara." else "Izin mikrofon ditolak")
    }

    private val poller = object : Runnable {
        override fun run() {
            if (viewer.visibility == View.VISIBLE) {
                pollStatus()
                root.postDelayed(this, 3000)
            }
        }
    }

    // ---------- Helper tampilan ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(c: Int, r: Int) = GradientDrawable().apply {
        setColor(c)
        cornerRadius = dp(r).toFloat()
    }

    private fun tv(t: String, sp: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = t
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(color)
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    }

    private fun pill(t: String, fill: Int, fg: Int): TextView = tv(t, 16f, fg, true).apply {
        gravity = Gravity.CENTER
        background = rounded(fill, 16)
        setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_DOWN) v.alpha = 0.6f
            else if (e.action == MotionEvent.ACTION_UP || e.action == MotionEvent.ACTION_CANCEL) v.alpha = 1f
            false
        }
    }

    private fun roundBtn(kind: String): LineIcon = LineIcon(this, kind).apply {
        background = rounded(SEG_BG, 26)
        setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_DOWN) v.alpha = 0.6f
            else if (e.action == MotionEvent.ACTION_UP || e.action == MotionEvent.ACTION_CANCEL) v.alpha = 1f
            false
        }
    }

    /** Tombol bulat + keterangan kecil di bawahnya (gaya Control Center iOS). */
    private fun toolCell(b: View, label: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        addView(b, LinearLayout.LayoutParams(dp(52), dp(52)))
        addView(
            tv(label, 11f, GRAY, false).apply { gravity = Gravity.CENTER },
            lp(WRAP, WRAP, 6)
        )
    }

    private fun lp(w: Int, hh: Int, top: Int = 0) = LinearLayout.LayoutParams(w, hh).apply { topMargin = dp(top) }

    private fun toast(m: String) = runOnUiThread { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() }

    private fun fmt(z: Float) = String.format(Locale.US, "%.1f×", z)

    // ---------- UI ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        root = FrameLayout(this).apply { setBackgroundColor(BG) }
        buildHome()
        buildViewer()
        root.addView(home, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(viewer, FrameLayout.LayoutParams(MATCH, MATCH))
        viewer.visibility = View.GONE
        setContentView(root)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (viewer.visibility == View.VISIBLE) closeViewer() else finish()
            }
        })
    }

    override fun onPause() {
        stopTalk()
        super.onPause()
    }

    override fun onDestroy() {
        streaming = false
        stopTalk()
        super.onDestroy()
    }

    private fun buildHome() {
        home = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(72), dp(24), dp(32))
        }
        home.addView(tv("Monitor", 34f, WHITE, true))
        home.addView(tv("Pantau kamera rumah", 15f, GRAY, false), lp(WRAP, WRAP, 2))
        home.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(CARD, 20)
        }
        statusDot = View(this).apply { background = rounded(GRAY, 6) }
        card.addView(statusDot, LinearLayout.LayoutParams(dp(12), dp(12)))
        statusText = tv("Belum terhubung", 17f, WHITE, false)
        card.addView(statusText, lp(WRAP, WRAP).apply { leftMargin = dp(12) })
        home.addView(card, lp(MATCH, WRAP))

        startBtn = pill("CCTV Aktif", BLUE, WHITE).apply { textSize = 18f }
        startBtn.setOnClickListener { connect() }
        home.addView(startBtn, lp(MATCH, dp(58), 14))

        val manual = tv("Atur IP manual", 15f, BLUE, false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, dp(6))
        }
        manual.setOnClickListener { manualDialog() }
        home.addView(manual, lp(MATCH, WRAP))

        val tip = tv("Pastikan HP kamera dan HP monitor ada di WiFi yang sama.", 13f, GRAY, false).apply {
            gravity = Gravity.CENTER
        }
        home.addView(tip, lp(MATCH, WRAP, 6))
    }

    private fun buildViewer() {
        viewer = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        video = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        viewer.addView(video, FrameLayout.LayoutParams(MATCH, MATCH))

        // Bar atas
        top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(44), dp(16), 0)
        }
        val livePill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(7), dp(14), dp(7))
            background = rounded(GLASS, 20)
        }
        liveDot = View(this).apply { background = rounded(ORANGE, 4) }
        livePill.addView(liveDot, LinearLayout.LayoutParams(dp(8), dp(8)))
        liveText = tv("Menyambung…", 13f, WHITE, true)
        livePill.addView(liveText, lp(WRAP, WRAP).apply { leftMargin = dp(8) })
        btnPadTop = LineIcon(this, "pad", sizeFrac = 0.55f).apply {
            background = rounded(GLASS, 18)
        }
        btnPadTop.setOnClickListener { togglePad() }
        top.addView(btnPadTop, LinearLayout.LayoutParams(dp(36), dp(36)).apply { rightMargin = dp(10) })
        top.addView(livePill, LinearLayout.LayoutParams(WRAP, WRAP))
        btnFlash = roundBtn("flash")
        btnMic = roundBtn("mic")
        btnApp = roundBtn("apps")
        btnScreen = roundBtn("screen")
        btnPad = roundBtn("pad")
        btnFlash.setOnClickListener {
            if (flashOk) cmd("torch=" + (if (torchOn) "off" else "on"))
            else toast("Flash tidak tersedia (kamera depan atau HP tanpa flash)")
        }
        btnApp.setOnClickListener { showAppPicker() }
        btnPad.setOnClickListener { togglePad() }
        btnScreen.setOnClickListener { toggleScreen() }
        btnMic.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                    startTalk()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> stopTalk()
            }
            true
        }
        top.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        btnFlip = LineIcon(this, "flip", sizeFrac = 0.55f).apply {
            background = rounded(GLASS, 18)
            setOnClickListener { cmd("cam=" + if (camFront) "back" else "front") }
        }
        top.addView(btnFlip, LinearLayout.LayoutParams(dp(36), dp(36)).apply { rightMargin = dp(10) })
        val close = LineIcon(this, "close", sizeFrac = 0.5f).apply {
            background = rounded(GLASS, 18)
        }
        close.setOnClickListener { closeViewer() }
        top.addView(close, LinearLayout.LayoutParams(dp(36), dp(36)))
        viewer.addView(top, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP))
        zoomTag = tv("1.0×", 13f, WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(6), dp(12), dp(6))
            background = rounded(GLASS, 16)
            visibility = View.GONE
        }
        viewer.addView(zoomTag, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.START).apply {
            setMargins(dp(16), dp(96), 0, 0)
        })

        // Panel bawah
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(GLASS, 28)
        }
        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val cells = listOf(
            toolCell(btnFlash, "Senter"),
            toolCell(btnMic, "Bicara"),
            toolCell(btnApp, "Aplikasi"),
            toolCell(btnScreen, "Layar"),
            toolCell(btnPad, "Kontrol")
        )
        for (c in cells) tools.addView(c, LinearLayout.LayoutParams(0, WRAP, 1f))
        panel.addView(tools, lp(MATCH, WRAP))




        val ar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val bFoto = pill("Foto", BLUE, WHITE)
        val bRot = pill("Putar", SEG_BG, WHITE)
        val bStop = pill("Putus", RED_BG, RED)
        bFoto.setOnClickListener { snap() }
        bRot.setOnClickListener { cmd("rot=${(rotIdx + 1) % 4}") }
        bStop.setOnClickListener { closeViewer() }
        ar.addView(bFoto, LinearLayout.LayoutParams(0, dp(48), 1f))
        ar.addView(bRot, LinearLayout.LayoutParams(0, dp(48), 1f).apply { leftMargin = dp(8) })
        ar.addView(bStop, LinearLayout.LayoutParams(0, dp(48), 1f).apply { leftMargin = dp(8) })
        panel.addView(ar, lp(MATCH, WRAP, 16))

        viewer.addView(
            panel,
            FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM).apply { setMargins(dp(12), 0, dp(12), dp(24)) }
        )

        buildPad()
        setupRemoteTouch()
        setupPinchZoom()
    }

    // ---------- Zoom digital (cubit, geser, ketuk dua kali) ----------

    private val MAX_ZOOM = 6f

    private fun resetZoom() {
        vZoom = 1f; vPanX = 0f; vPanY = 0f
        applyVideoMatrix()
    }

    /** Hitung matrix tampilan: gambar muat di layar, lalu diperbesar [vZoom] dan digeser. */
    private fun applyVideoMatrix() {
        val bmp = lastBitmap
        val w = video.width.toFloat()
        val h = video.height.toFloat()
        if (bmp == null || w <= 0f || h <= 0f) return
        if (bmp.width != vBmpW || bmp.height != vBmpH) {
            vBmpW = bmp.width; vBmpH = bmp.height
            vZoom = 1f; vPanX = 0f; vPanY = 0f
        }
        val base = minOf(w / bmp.width, h / bmp.height)
        val sc = base * vZoom
        val cw = bmp.width * sc
        val ch = bmp.height * sc
        val maxX = maxOf(0f, (cw - w) / 2f)
        val maxY = maxOf(0f, (ch - h) / 2f)
        vPanX = vPanX.coerceIn(-maxX, maxX)
        vPanY = vPanY.coerceIn(-maxY, maxY)
        val m = android.graphics.Matrix()
        m.setScale(sc, sc)
        m.postTranslate((w - cw) / 2f + vPanX, (h - ch) / 2f + vPanY)
        video.imageMatrix = m
        zoomTag.visibility = if (vZoom > 1.02f) View.VISIBLE else View.GONE
        zoomTag.text = fmt(vZoom)
    }

    private fun zoomAt(newZoom: Float, fx: Float, fy: Float) {
        val bmp = lastBitmap ?: return
        val w = video.width.toFloat()
        val h = video.height.toFloat()
        val base = minOf(w / bmp.width, h / bmp.height)
        val z = newZoom.coerceIn(1f, MAX_ZOOM)
        val s0 = base * vZoom
        val s1 = base * z
        // Titik gambar di bawah jari tetap di tempatnya.
        val ox = (w - bmp.width * s0) / 2f + vPanX
        val oy = (h - bmp.height * s0) / 2f + vPanY
        val px = (fx - ox) / s0
        val py = (fy - oy) / s0
        val nx = fx - px * s1
        val ny = fy - py * s1
        vZoom = z
        vPanX = nx - (w - bmp.width * s1) / 2f
        vPanY = ny - (h - bmp.height * s1) / 2f
        applyVideoMatrix()
    }

    private fun setupPinchZoom() {
        video.scaleType = ImageView.ScaleType.MATRIX
        video.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> applyVideoMatrix() }
        zoomTag.setOnClickListener { resetZoom() }

        scaleDet = android.view.ScaleGestureDetector(this, object : android.view.ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: android.view.ScaleGestureDetector): Boolean {
                zoomAt(vZoom * d.scaleFactor, d.focusX, d.focusY)
                return true
            }
        })
        tapDet = android.view.GestureDetector(this, object : android.view.GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (vZoom > 1.02f) {
                    vPanX -= dx
                    vPanY -= dy
                    applyVideoMatrix()
                }
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (vZoom > 1.02f) resetZoom() else zoomAt(2.5f, e.x, e.y)
                return true
            }

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                val v = if (panel.visibility == View.VISIBLE) View.INVISIBLE else View.VISIBLE
                panel.visibility = v
                top.visibility = v
                return true
            }
        })
    }


    private fun selectSeg(front: Boolean) {
        camFront = front
        btnFlip.background = rounded(if (front) BLUE else GLASS, 18)
    }

    private fun setStatus(t: String, c: Int) {
        statusText.text = t
        statusDot.background = rounded(c, 6)
    }

    private fun liveOn(on: Boolean) {
        liveText.text = if (on) "LIVE" else "Menyambung…"
        liveDot.background = rounded(if (on) RED else ORANGE, 4)
    }

    private fun manualDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(16), dp(24), dp(8)) }
        val et = EditText(this).apply {
            hint = "IP kamera, mis. 192.168.1.20"
            inputType = InputType.TYPE_CLASS_TEXT
            setText(prefs.getString("base", null)?.removePrefix("http://")?.removeSuffix(":$PORT") ?: "")
        }
        val ek = EditText(this).apply {
            hint = "Kunci akses (dari pemilik kamera)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(key())
        }
        box.addView(et)
        box.addView(ek)
        AlertDialog.Builder(this)
            .setTitle("Sambung ke kamera")
            .setMessage("Dari luar rumah (data seluler) pakai alamat VPN, mis. Tailscale 100.x.x.x.")
            .setView(box)
            .setPositiveButton("Sambung") { _, _ ->
                val ip = et.text.toString().trim()
                prefs.edit().putString("key", ek.text.toString().trim()).apply()
                if (ip.isNotEmpty()) {
                    prefs.edit().putString("base", "http://$ip:$PORT").apply()
                    connect()
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---------- Koneksi & pencarian kamera ----------

    private fun connect() {
        if (key().isEmpty()) { manualDialog(); return }
        startBtn.isEnabled = false
        setStatus("Mencari kamera…", ORANGE)
        Thread {
            var found: String? = null
            val saved = prefs.getString("base", null)
            if (saved != null && probe(saved, 4000)) found = saved
            if (found == null) found = scan()
            val result = found
            runOnUiThread {
                if (result == null) {
                    setStatus("Kamera tidak ditemukan", RED)
                    startBtn.isEnabled = true
                } else {
                    prefs.edit().putString("base", result).apply()
                    base = result
                    setStatus("Terhubung", GREEN)
                    showViewer()
                }
            }
        }.start()
    }

    private fun key(): String = prefs.getString("key", "") ?: ""

    private fun withKey(url: String): String =
        if (key().isEmpty()) url else url + (if ('?' in url) "&" else "?") + "k=" + key()

    private fun httpGet(url: String, timeout: Int): String {
        val c = URL(withKey(url)).openConnection() as HttpURLConnection
        c.connectTimeout = timeout
        c.readTimeout = timeout + 1000
        try {
            return c.inputStream.bufferedReader().readText()
        } finally {
            c.disconnect()
        }
    }

    private fun probe(b: String, timeout: Int = 800): Boolean = try {
        httpGet("$b/status", timeout).contains("cam=")
    } catch (e: Exception) {
        false
    }

    private fun localPrefixes(): List<String> {
        val list = ArrayList<String>()
        try {
            val all = NetworkInterface.getNetworkInterfaces() ?: return list
            for (ni in Collections.list(all)) {
                if (!ni.isUp || ni.isLoopback) continue
                for (a in Collections.list(ni.inetAddresses)) {
                    if (a is Inet4Address && a.isSiteLocalAddress) {
                        val s = a.hostAddress ?: continue
                        list.add(s.substringBeforeLast('.'))
                    }
                }
            }
        } catch (e: Exception) {
        }
        return list.distinct()
    }

    private fun portOpen(ip: String): Boolean = try {
        Socket().use { it.connect(InetSocketAddress(ip, PORT), 400) }
        true
    } catch (e: Exception) {
        false
    }

    private fun scan(): String? {
        val prefixes = localPrefixes()
        if (prefixes.isEmpty()) return null
        val pool = Executors.newFixedThreadPool(64)
        val found = AtomicReference<String?>(null)
        val latch = CountDownLatch(prefixes.size * 254)
        for (p in prefixes) {
            for (i in 1..254) {
                pool.execute {
                    try {
                        if (found.get() == null) {
                            val ip = "$p.$i"
                            if (portOpen(ip)) {
                                val b = "http://$ip:$PORT"
                                if (probe(b)) found.compareAndSet(null, b)
                            }
                        }
                    } catch (e: Exception) {
                    } finally {
                        latch.countDown()
                    }
                }
            }
        }
        latch.await(15, TimeUnit.SECONDS)
        pool.shutdownNow()
        return found.get()
    }

    // ---------- Viewer ----------

    private fun showViewer() {
        home.visibility = View.GONE
        viewer.visibility = View.VISIBLE
        panel.visibility = View.VISIBLE
        top.visibility = View.VISIBLE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        liveOn(false)
        screenMode = false
        refreshButtons()
        startStream()
        cmd("")
        root.removeCallbacks(poller)
        root.postDelayed(poller, 3000)
    }

    private fun closeViewer() {
        stopTalk()
        padRepeat?.let { root.removeCallbacks(it) }
        pad.visibility = View.GONE
        root.removeCallbacks(poller)
        screenMode = false
        refreshButtons()
        streaming = false
        gen++
        val c = conn
        Thread {
            try { c?.disconnect() } catch (e: Exception) { }
        }.start()
        viewer.visibility = View.GONE
        home.visibility = View.VISIBLE
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        video.setImageDrawable(null)
        vZoom = 1f; vPanX = 0f; vPanY = 0f; vBmpW = 0; vBmpH = 0
        zoomTag.visibility = View.GONE
        startBtn.isEnabled = true
        setStatus("Belum terhubung", GRAY)
    }

    private fun readHeaderLine(i: InputStream): String? {
        val sb = StringBuilder()
        while (true) {
            val c = i.read()
            if (c < 0) return if (sb.isEmpty()) null else sb.toString()
            if (c == '\n'.code) break
            if (c != '\r'.code) sb.append(c.toChar())
        }
        return sb.toString()
    }

    private fun startStream(path: String = "/stream") {
        val b = base ?: return
        streaming = true
        val my = ++gen
        Thread {
            var first = true
            while (streaming && my == gen) {
                try {
                    val c = URL(withKey("$b$path")).openConnection() as HttpURLConnection
                    c.connectTimeout = 3000
                    c.readTimeout = 6000
                    conn = c
                    val inp = BufferedInputStream(c.inputStream, 65536)
                    while (streaming && my == gen) {
                        var len = -1
                        while (true) {
                            val line = readHeaderLine(inp) ?: throw IOException("eof")
                            if (line.isEmpty()) {
                                if (len > 0) break else continue
                            }
                            if (line.startsWith("Content-Length:", true)) {
                                len = line.substring(15).trim().toInt()
                            }
                        }
                        val buf = ByteArray(len)
                        var off = 0
                        while (off < len) {
                            val n = inp.read(buf, off, len - off)
                            if (n < 0) throw IOException("eof")
                            off += n
                        }
                        val bmp = BitmapFactory.decodeByteArray(buf, 0, len)
                        if (bmp != null) {
                            lastBitmap = bmp
                            val firstNow = first
                            first = false
                            runOnUiThread {
                                video.setImageBitmap(bmp)
                                applyVideoMatrix()
                                if (firstNow) liveOn(true)
                            }
                        }
                    }
                    c.disconnect()
                } catch (e: Exception) {
                    first = true
                    runOnUiThread { if (my == gen) liveOn(false) }
                    if (!(streaming && my == gen)) break
                    try { Thread.sleep(1500) } catch (x: InterruptedException) { }
                }
            }
        }.start()
    }

    // ---------- Kontrol kamera ----------

    private fun cmd(q: String) {
        val b = base ?: return
        Thread {
            try {
                val s = httpGet("$b/cmd?$q", 2000)
                runOnUiThread { applyStatus(s) }
            } catch (e: Exception) {
            }
        }.start()
    }

    private fun applyStatus(s: String) {
        val m = HashMap<String, String>()
        s.trim().split(';').forEach {
            val kv = it.split('=')
            if (kv.size == 2) m[kv[0]] = kv[1]
        }
        selectSeg(m["cam"] == "front")
        rotIdx = m["rot"]?.toIntOrNull() ?: 0
        flashOk = m["flash"] == "1"
        torchOn = m["torch"] == "1"
        appsOk = m["apps"]?.split(',')?.filter { it.isNotEmpty() }?.toSet()
            ?: if ((m["wa"] ?: "1") == "1") setOf("wa", "cam", "fb", "tt") else setOf("cam", "fb", "tt")
        touchOk = m["touch"] == "1"
        refreshButtons()
    }

    private fun refreshButtons() {
        btnFlash.background = rounded(if (torchOn) YELLOW else SEG_BG, 26)
        btnFlash.setColor(if (torchOn) Color.BLACK else Color.WHITE)
        btnFlash.alpha = if (flashOk) 1f else 0.35f
        btnScreen.background = rounded(if (screenMode) BLUE else SEG_BG, 26)
        val padOn = pad.visibility == View.VISIBLE
        btnPad.background = rounded(if (padOn) BLUE else SEG_BG, 26)
        btnPadTop.background = rounded(if (padOn) BLUE else GLASS, 18)
    }

    private fun pollStatus() {
        val b = base ?: return
        Thread {
            try {
                val s = httpGet("$b/status", 1500)
                runOnUiThread { if (viewer.visibility == View.VISIBLE) applyStatus(s) }
            } catch (e: Exception) {
            }
        }.start()
    }

    // ---------- Cermin layar ----------

    private fun toggleScreen() {
        val b = base ?: return
        if (screenMode) {
            setScreenMode(false)
            return
        }
        Thread {
            val ok = try {
                httpGet("$b/status", 1500).contains("scr=1")
            } catch (e: Exception) {
                false
            }
            runOnUiThread {
                if (ok) setScreenMode(true)
                else toast("Di HP kamera, tekan \"Izinkan bagikan layar\" dulu")
            }
        }.start()
    }

    private fun setScreenMode(on: Boolean) {
        screenMode = on
        vZoom = 1f; vPanX = 0f; vPanY = 0f
        refreshButtons()
        liveOn(false)
        val c = conn
        Thread {
            try { c?.disconnect() } catch (e: Exception) { }
        }.start()
        startStream(if (on) "/screen" else "/stream")
    }

    // ---------- Sentuh jarak jauh (saat mode layar) ----------

    private var tx = 0f
    private var ty = 0f
    private var tt = 0L
    private var tMoved = false

    /** Ubah titik sentuh di ImageView jadi koordinat 0..1 pada layar HP kamera. */
    private fun toNorm(px: Float, py: Float): FloatArray? {
        val bmp = lastBitmap ?: return null
        val inv = android.graphics.Matrix()
        if (!video.imageMatrix.invert(inv)) return null
        val pts = floatArrayOf(px, py)
        inv.mapPoints(pts)
        val nx = pts[0] / bmp.width
        val ny = pts[1] / bmp.height
        if (nx < 0f || nx > 1f || ny < 0f || ny > 1f) return null
        return floatArrayOf(nx, ny)
    }

    private fun f(v: Float) = String.format(Locale.US, "%.4f", v)

    private fun setupRemoteTouch() {
        video.setOnTouchListener { v, e ->
            if (!screenMode) {
                scaleDet.onTouchEvent(e)
                tapDet.onTouchEvent(e)
                return@setOnTouchListener true
            }
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    tx = e.x; ty = e.y; tt = SystemClock.elapsedRealtime(); tMoved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.hypot((e.x - tx).toDouble(), (e.y - ty).toDouble()) > dp(10)) tMoved = true
                }
                MotionEvent.ACTION_UP -> {
                    val a = toNorm(tx, ty)
                    val b = toNorm(e.x, e.y)
                    if (a != null) {
                        if (!touchOk) {
                            toast("Aktifkan \"kontrol sentuh jarak jauh\" di HP kamera dulu")
                        } else if (tMoved && b != null) {
                            val dur = (SystemClock.elapsedRealtime() - tt).coerceIn(120L, 800L)
                            cmd("x=${f(a[0])}&y=${f(a[1])}&x2=${f(b[0])}&y2=${f(b[1])}&d=$dur")
                        } else {
                            val held = SystemClock.elapsedRealtime() - tt
                            val dur = if (held > 500) 700L else 60L
                            cmd("x=${f(a[0])}&y=${f(a[1])}&d=$dur")
                        }
                    }
                }
            }
            true
        }
    }

    // ---------- Panel kontrol melayang ----------

    private fun needTouch() = toast("Aktifkan \"kontrol sentuh jarak jauh\" di HP kamera dulu")

    private fun togglePad() {
        if (pad.visibility == View.VISIBLE) {
            pad.visibility = View.GONE
            padRepeat?.let { root.removeCallbacks(it) }
            padRepeat = null
        } else {
            pad.visibility = View.VISIBLE
            placePad()
            if (!touchOk) needTouch()
            if (!screenMode) toggleScreen()
        }
        refreshButtons()
    }

    private fun placePad() {
        pad.post {
            pad.scaleX = padScale
            pad.scaleY = padScale
            if (!padPlaced) {
                padPlaced = true
                val sx = prefs.getFloat("pad_x", -1f)
                val sy = prefs.getFloat("pad_y", -1f)
                if (sx >= 0f && sy >= 0f) {
                    pad.x = sx
                    pad.y = sy
                } else {
                    pad.x = viewer.width - pad.width * padScale - dp(12)
                    pad.y = dp(110).toFloat()
                }
            }
            clampPad()
        }
    }

    private fun clampPad() {
        val maxX = (viewer.width - pad.width * padScale).coerceAtLeast(0f)
        val maxY = (viewer.height - pad.height * padScale).coerceAtLeast(0f)
        pad.x = pad.x.coerceIn(0f, maxX)
        pad.y = pad.y.coerceIn(0f, maxY)
    }

    private fun savePad() {
        prefs.edit()
            .putFloat("pad_x", pad.x)
            .putFloat("pad_y", pad.y)
            .putFloat("pad_scale", padScale)
            .apply()
    }

    private fun setPadScale(v: Float) {
        padScale = v.coerceIn(0.6f, 1.4f)
        pad.scaleX = padScale
        pad.scaleY = padScale
        clampPad()
        savePad()
    }

    private fun padSwipe(x1: Float, y1: Float, x2: Float, y2: Float) {
        cmd("x=${f(x1)}&y=${f(y1)}&x2=${f(x2)}&y2=${f(y2)}&d=250")
    }

    private fun padTap(dur: Long) {
        if (!touchOk) {
            needTouch()
            return
        }
        cmd("x=0.5000&y=0.5000&d=$dur")
    }

    /** Tombol panah: sekali tekan = sekali geser, ditahan = geser berulang. */
    private fun arrowKey(label: String, x1: Float, y1: Float, x2: Float, y2: Float): TextView =
        tv(label, 24f, WHITE, true).apply {
            gravity = Gravity.CENTER
            background = rounded(SEG_BG, 16)
            setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        v.alpha = 0.6f
                        v.parent?.requestDisallowInterceptTouchEvent(true)
                        if (!touchOk) {
                            needTouch()
                        } else {
                            val r = object : Runnable {
                                override fun run() {
                                    padSwipe(x1, y1, x2, y2)
                                    root.postDelayed(this, 450)
                                }
                            }
                            padRepeat = r
                            r.run()
                        }
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        v.alpha = 1f
                        padRepeat?.let { root.removeCallbacks(it) }
                        padRepeat = null
                    }
                }
                true
            }
        }

    private fun buildPad() {
        padScale = prefs.getFloat("pad_scale", 1f).coerceIn(0.6f, 1.4f)
        pad = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(14))
            background = rounded(GLASS, 26)
            visibility = View.GONE
            pivotX = 0f
            pivotY = 0f
            elevation = dp(8).toFloat()
        }

        // Kepala: gagang untuk menggeser panel + tombol ubah ukuran
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val handle = tv("TAHAN UNTUK GESER", 11f, GRAY, true).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.08f
            setPadding(dp(6), dp(12), dp(6), dp(12))
        }
        var offX = 0f
        var offY = 0f
        handle.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    offX = pad.x - e.rawX
                    offY = pad.y - e.rawY
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                }
                MotionEvent.ACTION_MOVE -> {
                    pad.x = e.rawX + offX
                    pad.y = e.rawY + offY
                    clampPad()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> savePad()
            }
            true
        }
        val minus = tv("−", 20f, WHITE, true).apply {
            gravity = Gravity.CENTER
            background = rounded(SEG_BG, 17)
        }
        val plus = tv("+", 20f, WHITE, true).apply {
            gravity = Gravity.CENTER
            background = rounded(SEG_BG, 17)
        }
        minus.setOnClickListener { setPadScale(padScale - 0.1f) }
        plus.setOnClickListener { setPadScale(padScale + 0.1f) }
        head.addView(handle, LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(minus, LinearLayout.LayoutParams(dp(34), dp(34)).apply { leftMargin = dp(6) })
        head.addView(plus, LinearLayout.LayoutParams(dp(34), dp(34)).apply { leftMargin = dp(6) })
        pad.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))

        // Tombol arah + TAP
        val cs = dp(58)
        fun cellLp() = LinearLayout.LayoutParams(cs, cs).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
        fun gridRow(a: View, b: View, c: View) = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(a, cellLp())
            addView(b, cellLp())
            addView(c, cellLp())
        }
        val up = arrowKey("↑", 0.5f, 0.72f, 0.5f, 0.28f)
        val down = arrowKey("↓", 0.5f, 0.28f, 0.5f, 0.72f)
        val left = arrowKey("←", 0.8f, 0.5f, 0.2f, 0.5f)
        val right = arrowKey("→", 0.2f, 0.5f, 0.8f, 0.5f)
        val tap = tv("TAP", 16f, WHITE, true).apply {
            gravity = Gravity.CENTER
            background = rounded(BLUE, 29)
        }
        tap.setOnClickListener { padTap(60L) }
        tap.setOnLongClickListener {
            padTap(700L)
            true
        }
        pad.addView(gridRow(View(this), up, View(this)), lp(WRAP, WRAP, 4).apply { gravity = Gravity.CENTER_HORIZONTAL })
        pad.addView(gridRow(left, tap, right), lp(WRAP, WRAP).apply { gravity = Gravity.CENTER_HORIZONTAL })
        pad.addView(gridRow(View(this), down, View(this)), lp(WRAP, WRAP).apply { gravity = Gravity.CENTER_HORIZONTAL })

        // Tombol navigasi: Back / Home / Recent / Notifikasi
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(SEG_BG, 14)
        }
        for ((label, key) in listOf("back" to "back", "home" to "home", "recents" to "recents", "bell" to "notif")) {
            val b = LineIcon(this, label, sizeFrac = 0.42f).apply {
                setOnTouchListener { v, e ->
                    if (e.action == MotionEvent.ACTION_DOWN) v.alpha = 0.5f
                    else if (e.action == MotionEvent.ACTION_UP || e.action == MotionEvent.ACTION_CANCEL) v.alpha = 1f
                    false
                }
            }
            b.setOnClickListener {
                if (touchOk) cmd("key=$key") else needTouch()
            }
            nav.addView(b, LinearLayout.LayoutParams(0, dp(46), 1f))
        }
        pad.addView(nav, lp(MATCH, WRAP, 10))

        viewer.addView(pad, FrameLayout.LayoutParams(WRAP, WRAP))
    }

    // ---------- Pilihan aplikasi di HP kamera ----------

    private fun showAppPicker() {
        val items = listOf(
            Triple("wa", "WA", "WhatsApp"),
            Triple("cam", "CAM", "Kamera HP"),
            Triple("fb", "FB", "Facebook"),
            Triple("tt", "TT", "TikTok")
        )
        val d = android.app.Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(14))
            background = rounded(CARD, 24)
        }
        card.addView(tv("Buka aplikasi di HP kamera", 17f, WHITE, true))
        for ((key, icon, name) in items) {
            val ok = key in appsOk
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(6), dp(8), dp(6), dp(8))
                alpha = if (ok) 1f else 0.35f
            }
            row.addView(
                tv(icon, 13f, WHITE, true).apply {
                    gravity = Gravity.CENTER
                    background = rounded(SEG_BG, 24)
                },
                LinearLayout.LayoutParams(dp(48), dp(48))
            )
            row.addView(tv(name, 16f, WHITE, true), lp(WRAP, WRAP).apply { leftMargin = dp(14) })
            row.setOnClickListener {
                d.dismiss()
                if (ok) openRemoteApp(key, name) else toast("$name tidak ditemukan di HP kamera")
            }
            card.addView(row, lp(MATCH, WRAP, 6))
        }
        d.setContentView(card)
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        d.window?.setLayout((resources.displayMetrics.widthPixels * 0.86f).toInt(), WindowManager.LayoutParams.WRAP_CONTENT)
        d.show()
    }

    private fun openRemoteApp(key: String, name: String) {
        cmd("app=$key")
        toast("Membuka $name di HP kamera…")
        if (!screenMode) toggleScreen()
    }

    // ---------- Bicara ke HP kamera ----------

    private fun startTalk() {
        val b = base ?: return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            micPerm.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        talkFlag?.set(false)
        val flag = AtomicBoolean(true)
        talkFlag = flag
        btnMic.background = rounded(RED, 26)
        Thread {
            var rec: AudioRecord? = null
            var sock: Socket? = null
            try {
                val host = URL(b).host
                val s = Socket()
                s.tcpNoDelay = true
                s.connect(InetSocketAddress(host, TALK_PORT), 2000)
                sock = s
                val out = s.getOutputStream()
                out.write((key() + "\n").toByteArray())
                val rate = 16000
                val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                val r = AudioRecord(
                    MediaRecorder.AudioSource.MIC, rate,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    maxOf(minBuf, 4096)
                )
                rec = r
                if (r.state != AudioRecord.STATE_INITIALIZED) throw IOException("mic")
                r.startRecording()
                val buf = ByteArray(2048)
                while (flag.get()) {
                    val n = r.read(buf, 0, buf.size)
                    if (n > 0) out.write(buf, 0, n) else if (n < 0) break
                }
                out.flush()
            } catch (e: Exception) {
                if (flag.get()) toast("Gagal mengirim suara")
            } finally {
                try { rec?.stop() } catch (e: Exception) { }
                try { rec?.release() } catch (e: Exception) { }
                try { sock?.close() } catch (e: Exception) { }
                flag.set(false)
                runOnUiThread { if (talkFlag === flag || talkFlag == null) btnMic.background = rounded(SEG_BG, 26) }
            }
        }.start()
    }

    private fun stopTalk() {
        talkFlag?.set(false)
        btnMic.background = rounded(SEG_BG, 26)
    }

    // ---------- Ambil gambar ----------

    private fun snap() {
        val bmp = lastBitmap
        if (bmp == null) {
            toast("Belum ada gambar")
            return
        }
        Thread {
            try {
                val name = "CCTV_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"
                val v = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/WansCCTV")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)
                if (uri == null) {
                    toast("Gagal menyimpan foto")
                    return@Thread
                }
                contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                v.clear()
                v.put(MediaStore.Images.Media.IS_PENDING, 0)
                contentResolver.update(uri, v, null, null)
                toast("Foto disimpan di Pictures/WansCCTV")
            } catch (e: Exception) {
                toast("Gagal menyimpan foto")
            }
        }.start()
    }
}
