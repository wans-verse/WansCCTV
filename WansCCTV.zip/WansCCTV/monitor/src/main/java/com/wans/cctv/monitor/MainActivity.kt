package com.wans.cctv.monitor

import android.Manifest
import android.app.DownloadManager
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.webkit.URLUtil
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.content.ContentValues
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.MediaStore
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.ScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import java.io.BufferedInputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Collections
import java.util.Date
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

private val BG = Color.BLACK
private val CARD = Color.parseColor("#1C1C1E")
private val GRAY = Color.parseColor("#8E8E93")
private val WHITE = Color.WHITE
private val BLUE = Color.parseColor("#0A84FF")
private val GREEN = Color.parseColor("#30D158")
private val RED = Color.parseColor("#FF453A")
private val ORANGE = Color.parseColor("#FF9F0A")
private val RED_BG = Color.parseColor("#3A1E1E")
private val SEG_BG = Color.parseColor("#3A3A3C")
private val SEG_SEL = Color.parseColor("#636366")
private val GLASS = Color.parseColor("#CC1C1C1E")
private val YELLOW = Color.parseColor("#FFD60A")
private val PAD_THIN = Color.parseColor("#2A141418")
private val PAD_RING = Color.parseColor("#14FFFFFF")
private val PAD_ICON = Color.parseColor("#99FFFFFF")
private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
private const val PORT = 8080
private const val TALK_PORT = 8081

class MainActivity : ComponentActivity() {

    private val prefs by lazy { getSharedPreferences("cctv", MODE_PRIVATE) }

    private lateinit var root: FrameLayout
    private lateinit var home: LinearLayout
    private lateinit var viewer: FrameLayout
    private lateinit var top: LinearLayout
    private lateinit var panel: LinearLayout
    private lateinit var btnExpand: LineIcon
    private lateinit var sayCell: LinearLayout
    private lateinit var btnRot: LineIcon
    private lateinit var grip: LineIcon
    private var panelCollapsed = false
    private var padResizing = false
    private lateinit var statusDot: View
    private lateinit var statusText: TextView
    private lateinit var startBtn: TextView
    private lateinit var recBtn: TextView
    private var recView: FrameLayout? = null
    private var web: WebView? = null
    private lateinit var video: ImageView
    private lateinit var liveDot: View
    private lateinit var liveText: TextView
    private lateinit var btnFlip: View
    private var camFront = false
    private lateinit var zoomTag: TextView
    private var vZoom = 1f
    private var vPanX = 0f
    private var vPanY = 0f
    private var vBmpW = 0
    private var vBmpH = 0
    private lateinit var scaleDet: android.view.ScaleGestureDetector
    private lateinit var tapDet: android.view.GestureDetector
    private lateinit var btnFlash: LineIcon
    private lateinit var btnMic: LineIcon
    private lateinit var btnApp: LineIcon
    private lateinit var btnScreen: LineIcon
    private lateinit var btnPad: LineIcon
    private lateinit var btnCfg: LineIcon
    private lateinit var cfgView: FrameLayout
    private var isAdmin = false
    private lateinit var pad: LinearLayout
    private var padScale = 1f
    private var padPlaced = false
    private var padRepeat: Runnable? = null
    private var touchOk = false

    @Volatile private var base: String? = null
    @Volatile private var streaming = false
    @Volatile private var conn: HttpURLConnection? = null
    @Volatile private var lastBitmap: Bitmap? = null
    private var gen = 0
    private var rotIdx = 0
    private var flashOk = false
    private var torchOn = false
    private var appsOk: Set<String> = setOf("wa", "cam", "fb", "tt")
    private var screenMode = false
    private var filterMode = 0
    @Volatile private var camName = "CAM 1"
    @Volatile private var stampOn = true
    private lateinit var filterBtn: LineIcon
    @Volatile private var stampSz = 0
    private var fullMode = false
    private var padWasOn = false
    private lateinit var btnFull: LineIcon
    private lateinit var btnExitFull: LineIcon
    private lateinit var batChip: LinearLayout
    private lateinit var batIcon: LineIcon
    private lateinit var batText: TextView
    private lateinit var chgWarn: TextView
    private var warnText: String? = null
    private var warnColor = 0
    private var talkFlag: AtomicBoolean? = null

    private val micPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        toast(if (ok) "Izin mikrofon diberikan. Tahan tombol Bicara untuk bicara." else "Izin mikrofon ditolak")
    }

    private val poller = object : Runnable {
        override fun run() {
            if (viewer.visibility == View.VISIBLE) {
                pollStatus()
                root.postDelayed(this, 3000)
            }
        }
    }

    // ---------- Helper tampilan ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(c: Int, r: Int) = GradientDrawable().apply {
        setColor(c)
        cornerRadius = dp(r).toFloat()
    }

    private fun tv(t: String, sp: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = t
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(color)
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    }

    private fun pill(t: String, fill: Int, fg: Int): TextView = tv(t, 16f, fg, true).apply {
        gravity = Gravity.CENTER
        background = rounded(fill, 16)
        setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_DOWN) v.alpha = 0.6f
            else if (e.action == MotionEvent.ACTION_UP || e.action == MotionEvent.ACTION_CANCEL) v.alpha = 1f
            false
        }
    }

    private fun roundBtn(kind: String): LineIcon = LineIcon(this, kind).apply {
        background = rounded(SEG_BG, 26)
        setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_DOWN) v.alpha = 0.6f
            else if (e.action == MotionEvent.ACTION_UP || e.action == MotionEvent.ACTION_CANCEL) v.alpha = 1f
            false
        }
    }

    /** Tombol bulat + keterangan kecil di bawahnya (gaya Control Center iOS). */
    private fun toolCell(b: View, label: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        addView(b, LinearLayout.LayoutParams(dp(48), dp(48)))
        addView(
            tv(label, 11f, GRAY, false).apply { gravity = Gravity.CENTER },
            lp(WRAP, WRAP, 6)
        )
    }

    private fun lp(w: Int, hh: Int, top: Int = 0) = LinearLayout.LayoutParams(w, hh).apply { topMargin = dp(top) }

    private fun toast(m: String) = runOnUiThread { IosUi.toast(this, m) }

    private fun fmt(z: Float) = String.format(Locale.US, "%.1f×", z)

    // ---------- UI ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        root = FrameLayout(this).apply { setBackgroundColor(BG) }
        buildHome()
        buildViewer()
        root.addView(home, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(viewer, FrameLayout.LayoutParams(MATCH, MATCH))
        viewer.visibility = View.GONE
        setContentView(root)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (recView?.visibility == View.VISIBLE) { backFromPlayback(); return }
                if (viewer.visibility == View.VISIBLE) {
                    if (cfgView.visibility == View.VISIBLE) closeCfg()
                    else if (fullMode) setFull(false)
                    else closeViewer()
                } else finish()
            }
        })
    }

    override fun onPause() {
        stopTalk()
        super.onPause()
    }

    override fun onDestroy() {
        web?.let { w ->
            (w.parent as? ViewGroup)?.removeView(w)
            w.destroy()
        }
        web = null
        streaming = false
        stopTalk()
        super.onDestroy()
    }

    private fun buildHome() {
        home = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(72), dp(24), dp(32))
        }
        home.addView(tv("Monitor", 34f, WHITE, true))
        home.addView(tv("Pantau kamera rumah", 15f, GRAY, false), lp(WRAP, WRAP, 2))
        home.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(CARD, 20)
        }
        statusDot = View(this).apply { background = rounded(GRAY, 6) }
        card.addView(statusDot, LinearLayout.LayoutParams(dp(12), dp(12)))
        statusText = tv("Belum terhubung", 17f, WHITE, false)
        card.addView(statusText, lp(WRAP, WRAP).apply { leftMargin = dp(12) })
        home.addView(card, lp(MATCH, WRAP))

        startBtn = pill("CCTV Aktif", BLUE, WHITE).apply { textSize = 18f }
        startBtn.setOnClickListener { connect() }
        home.addView(startBtn, lp(MATCH, dp(58), 14))

        recBtn = pill("Rekaman", SEG_BG, WHITE).apply { textSize = 18f }
        recBtn.setOnClickListener { openPlayback() }
        home.addView(recBtn, lp(MATCH, dp(58), 10))

        val manual = tv("Atur IP manual", 15f, BLUE, false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, dp(6))
        }
        manual.setOnClickListener { manualDialog() }
        home.addView(manual, lp(MATCH, WRAP))

        val tip = tv("Pastikan HP kamera dan HP monitor ada di WiFi yang sama.", 13f, GRAY, false).apply {
            gravity = Gravity.CENTER
        }
        home.addView(tip, lp(MATCH, WRAP, 6))
    }

    private fun buildViewer() {
        viewer = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        video = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        viewer.addView(video, FrameLayout.LayoutParams(MATCH, MATCH))

        // Bar atas
        top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(44), dp(16), 0)
        }
        val livePill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(7), dp(14), dp(7))
            background = rounded(GLASS, 20)
        }
        liveDot = View(this).apply { background = rounded(ORANGE, 4) }
        livePill.addView(liveDot, LinearLayout.LayoutParams(dp(8), dp(8)))
        liveText = tv("Menyambung…", 13f, WHITE, true)
        livePill.addView(liveText, lp(WRAP, WRAP).apply { leftMargin = dp(8) })
        btnCfg = LineIcon(this, "gear", sizeFrac = 0.55f).apply {
            background = rounded(GLASS, 18)
            visibility = View.GONE
        }
        btnCfg.setOnClickListener { showCfg() }
        top.addView(btnCfg, LinearLayout.LayoutParams(dp(34), dp(34)).apply { rightMargin = dp(8) })
        top.addView(livePill, LinearLayout.LayoutParams(WRAP, WRAP))
        batIcon = LineIcon(this, "battery", sizeFrac = 1f)
        batText = tv("", 13f, WHITE, true)
        batChip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), 0, dp(12), 0)
            background = rounded(GLASS, 18)
            visibility = View.GONE
        }
        batChip.addView(batIcon, LinearLayout.LayoutParams(dp(20), dp(20)))
        batChip.addView(batText, lp(WRAP, WRAP).apply { leftMargin = dp(4) })
        top.addView(batChip, LinearLayout.LayoutParams(WRAP, dp(36)).apply { leftMargin = dp(8) })
        // Filter tampilan (Normal / Terang / Malam): satu ikon di bar atas, warnanya menandakan mode.
        filterBtn = LineIcon(this, "sun", sizeFrac = 0.55f).apply {
            background = rounded(GLASS, 18)
            setOnClickListener {
                filterMode = (filterMode + 1) % 3
                applyFilter(true)
            }
        }
        top.addView(filterBtn, LinearLayout.LayoutParams(dp(34), dp(34)).apply { leftMargin = dp(8) })
        btnFlash = roundBtn("flash")
        btnMic = roundBtn("mic")
        btnApp = roundBtn("apps")
        btnScreen = roundBtn("screen")
        btnPad = roundBtn("pad")
        btnFlash.setOnClickListener {
            if (flashOk) cmd("torch=" + (if (torchOn) "off" else "on"))
            else toast("Flash tidak tersedia (kamera depan atau HP tanpa flash)")
        }
        btnApp.setOnClickListener { showAppPicker() }
        btnPad.setOnClickListener { togglePad() }
        btnScreen.setOnClickListener { toggleScreen() }
        btnMic.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                    startTalk()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> stopTalk()
            }
            true
        }
        top.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        btnFlip = LineIcon(this, "flip", sizeFrac = 0.55f).apply {
            background = rounded(GLASS, 18)
            setOnClickListener { cmd("cam=" + if (camFront) "back" else "front") }
        }
        top.addView(btnFlip, LinearLayout.LayoutParams(dp(34), dp(34)).apply { rightMargin = dp(8) })
        btnRot = LineIcon(this, "rotate", sizeFrac = 0.55f).apply {
            background = rounded(GLASS, 18)
            setOnClickListener { cmd("rot=${(rotIdx + 1) % 4}") }
        }
        top.addView(btnRot, LinearLayout.LayoutParams(dp(34), dp(34)).apply { rightMargin = dp(8) })
        btnFull = LineIcon(this, "full", sizeFrac = 0.55f).apply {
            background = rounded(GLASS, 18)
            setOnClickListener { setFull(true) }
        }
        top.addView(btnFull, LinearLayout.LayoutParams(dp(34), dp(34)).apply { rightMargin = dp(8) })
        val close = LineIcon(this, "close", sizeFrac = 0.5f).apply {
            background = rounded(GLASS, 18)
        }
        close.setOnClickListener { closeViewer() }
        top.addView(close, LinearLayout.LayoutParams(dp(34), dp(34)))
        viewer.addView(top, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP))
        zoomTag = tv("1.0×", 13f, WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(6), dp(12), dp(6))
            background = rounded(GLASS, 16)
            visibility = View.GONE
        }
        viewer.addView(zoomTag, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.START).apply {
            setMargins(dp(16), dp(96), 0, 0)
        })
        chgWarn = tv("", 13f, WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(6), dp(12), dp(6))
            visibility = View.GONE
        }
        viewer.addView(chgWarn, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            setMargins(0, dp(96), 0, 0)
        })

        // Panel bawah
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(6), dp(18), dp(18))
            background = rounded(GLASS, 28)
        }
        val bCollapse = LineIcon(this, "chevdown", sizeFrac = 0.6f).apply {
            setOnClickListener { collapsePanel() }
        }
        panel.addView(bCollapse, LinearLayout.LayoutParams(dp(64), dp(28)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            bottomMargin = dp(4)
        })
        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val btnSay = roundBtn("say")
        btnSay.setOnClickListener { sayDialog() }
        sayCell = toolCell(btnSay, "Ucap").apply { visibility = View.GONE }
        val cells = listOf(
            toolCell(btnFlash, "Senter"),
            toolCell(btnMic, "Bicara"),
            toolCell(btnApp, "Aplikasi"),
            toolCell(btnScreen, "Layar"),
            toolCell(btnPad, "Kontrol"),
            sayCell
        )
        for (c in cells) tools.addView(c, LinearLayout.LayoutParams(0, WRAP, 1f))
        panel.addView(tools, lp(MATCH, WRAP))





        viewer.addView(
            panel,
            FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM).apply { setMargins(dp(12), 0, dp(12), dp(24)) }
        )
        btnExpand = LineIcon(this, "chevup", sizeFrac = 0.6f).apply {
            background = rounded(GLASS, 16)
            visibility = View.INVISIBLE
            setOnClickListener { expandPanel() }
        }
        viewer.addView(
            btnExpand,
            FrameLayout.LayoutParams(dp(64), dp(32), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { setMargins(0, 0, 0, dp(24)) }
        )

        buildPad()

        // Tombol keluar layar penuh: kecil, transparan tipis, hanya muncul saat layar penuh.
        btnExitFull = LineIcon(this, "exitfull", tint0 = PAD_ICON, sizeFrac = 0.55f).apply {
            background = rounded(Color.parseColor("#33000000"), 20)
            visibility = View.GONE
            setOnClickListener { setFull(false) }
        }
        viewer.addView(
            btnExitFull,
            FrameLayout.LayoutParams(dp(40), dp(40), Gravity.TOP or Gravity.END).apply { setMargins(0, dp(14), dp(14), 0) }
        )
        setupRemoteTouch()
        setupPinchZoom()
        cfgView = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#F2000000"))
            visibility = View.GONE
            isClickable = true
        }
        viewer.addView(cfgView, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    /** Atur panel bawah dan panah naik sesuai: antarmuka tampil atau tidak, dan panel diciutkan atau tidak. */
    private fun syncPanel(uiVisible: Boolean) {
        panel.animate().cancel()
        btnExpand.animate().cancel()
        panel.translationY = 0f
        panel.alpha = 1f
        btnExpand.alpha = 1f
        panel.visibility = if (uiVisible && !panelCollapsed) View.VISIBLE else View.INVISIBLE
        btnExpand.visibility = if (uiVisible && panelCollapsed) View.VISIBLE else View.INVISIBLE
    }

    private fun collapsePanel() {
        if (panelCollapsed) return
        panelCollapsed = true
        btnExpand.animate().cancel()
        btnExpand.alpha = 0f
        btnExpand.visibility = View.VISIBLE
        btnExpand.animate().alpha(1f).setDuration(180).start()
        panel.animate().cancel()
        panel.animate()
            .translationY(panel.height.toFloat() + dp(24))
            .alpha(0f)
            .setDuration(180)
            .withEndAction {
                if (panelCollapsed) panel.visibility = View.INVISIBLE
                panel.translationY = 0f
                panel.alpha = 1f
            }
            .start()
    }

    private fun expandPanel() {
        if (!panelCollapsed) return
        panelCollapsed = false
        btnExpand.animate().cancel()
        btnExpand.animate().alpha(0f).setDuration(120).withEndAction {
            btnExpand.visibility = View.INVISIBLE
            btnExpand.alpha = 1f
        }.start()
        panel.animate().cancel()
        panel.translationY = panel.height.toFloat() + dp(24)
        panel.alpha = 0f
        panel.visibility = View.VISIBLE
        panel.animate().translationY(0f).alpha(1f).setDuration(180).start()
    }

    /** Filter tampilan kamera di Monitor saja (gambar asli dan rekaman tidak berubah). */
    private fun applyFilter(announce: Boolean = false) {
        val m = android.graphics.ColorMatrix()
        val label: String
        val mode = if (screenMode) 0 else filterMode
        when (mode) {
            1 -> { // Terang: naikkan kecerahan, warna tetap
                label = "Filter: Terang"
                m.set(floatArrayOf(
                    1.7f, 0f, 0f, 0f, 25f,
                    0f, 1.7f, 0f, 0f, 25f,
                    0f, 0f, 1.7f, 0f, 25f,
                    0f, 0f, 0f, 1f, 0f
                ))
            }
            2 -> { // Malam: hitam-putih, lebih terang dan kontras
                label = "Filter: Malam"
                val g = android.graphics.ColorMatrix().apply { setSaturation(0f) }
                val b = android.graphics.ColorMatrix(floatArrayOf(
                    2.4f, 0f, 0f, 0f, 40f,
                    0f, 2.4f, 0f, 0f, 40f,
                    0f, 0f, 2.4f, 0f, 40f,
                    0f, 0f, 0f, 1f, 0f
                ))
                m.setConcat(b, g)
            }
            else -> label = "Filter: Normal"
        }
        filterBtn.setColor(when (mode) { 1 -> YELLOW; 2 -> BLUE; else -> WHITE })
        if (announce) toast(label)
        video.colorFilter = if (mode == 0) null else android.graphics.ColorMatrixColorFilter(m)
    }

    /** Peringatan memori penuh ikut tampil/hilang bersama bar atas. */
    private fun refreshWarn() {
        filterBtn.visibility = if (top.visibility == View.VISIBLE && !screenMode) View.VISIBLE else View.GONE
        val t = warnText
        if (t == null || top.visibility != View.VISIBLE) {
            chgWarn.visibility = View.GONE
            return
        }
        chgWarn.text = t
        chgWarn.setTextColor(warnColor)
        chgWarn.background = rounded(GLASS, 16)
        chgWarn.visibility = View.VISIBLE
    }

    /** Mode layar penuh: semua tombol hilang kecuali tombol keluar kecil di pojok kanan atas. Tombol Kembali juga bisa dipakai. */
    private fun setFull(on: Boolean) {
        if (on == fullMode) return
        fullMode = on
        if (on) {
            padWasOn = pad.visibility == View.VISIBLE
            syncPanel(false)
            top.visibility = View.INVISIBLE
            refreshWarn()
            pad.visibility = View.INVISIBLE
            btnExitFull.visibility = View.VISIBLE
            applyImmersive(true)
            toast("Layar penuh. Tekan tombol di pojok kanan atas untuk keluar")
        } else {
            syncPanel(true)
            top.visibility = View.VISIBLE
            refreshWarn()
            if (padWasOn) pad.visibility = View.VISIBLE
            btnExitFull.visibility = View.GONE
            applyImmersive(false)
        }
    }

    /** Layar penuh: sembunyikan bar status dan navigasi sistem (geser dari tepi untuk memunculkan sebentar). */
    private fun applyImmersive(on: Boolean) {
        val c = androidx.core.view.WindowInsetsControllerCompat(window, window.decorView)
        if (on) {
            c.systemBarsBehavior = androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
        } else {
            c.show(androidx.core.view.WindowInsetsCompat.Type.systemBars())
        }
    }

    // ---------- Pengaturan kamera jarak jauh (khusus admin) ----------

    private val CFG_RES = intArrayOf(240, 360, 480)
    private val CFG_FPS = intArrayOf(5, 10, 15)
    private val CFG_Q = intArrayOf(45, 55, 65)
    private val CFG_DAYS = intArrayOf(1, 3, 7)
    private val CFG_COLORS = intArrayOf(0xFFFF453A.toInt(), 0xFFFFD60A.toInt(), 0xFF30D158.toInt(), 0xFF0A84FF.toInt(), 0xFFFFFFFF.toInt())

    private fun parseKv(s: String): HashMap<String, String> {
        val m = HashMap<String, String>()
        s.trim().split(';').forEach {
            val kv = it.split('=')
            if (kv.size == 2) m[kv[0]] = kv[1]
        }
        return m
    }

    private fun closeCfg() {
        cfgView.visibility = View.GONE
    }

    private fun showCfg() {
        val b = base ?: return
        cfgView.removeAllViews()
        cfgView.visibility = View.VISIBLE
        cfgView.addView(tv("Memuat…", 15f, GRAY, false).apply { gravity = Gravity.CENTER }, FrameLayout.LayoutParams(MATCH, MATCH))
        Thread {
            try {
                val m = parseKv(httpGet("$b/cfg", 2500))
                runOnUiThread { renderCfg(m) }
            } catch (e: Exception) {
                runOnUiThread { closeCfg(); toast("Gagal memuat pengaturan") }
            }
        }.start()
    }

    private fun setCfg(k: String, v: Int) {
        val b = base ?: return
        Thread {
            try {
                httpGet("$b/cfg?$k=$v", 2500)
            } catch (e: Exception) {
                toast("Gagal menyimpan")
            }
        }.start()
    }

    private fun setCfgStr(k: String, v: String) {
        val b = base ?: return
        Thread {
            try {
                httpGet("$b/cfg?$k=" + java.net.URLEncoder.encode(v, "UTF-8"), 2500)
            } catch (e: Exception) {
                toast("Gagal menyimpan")
            }
        }.start()
    }

    private fun nameDialog(cur: String, onSaved: (String) -> Unit) {
        lateinit var dlg: IosDialog
        val et = IosUi.field(this, "Nama kamera, mis. CAM 1", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS, cur)
        et.filters = arrayOf(android.text.InputFilter.LengthFilter(20))
        dlg = IosDialog(this)
            .title("Nama kamera")
            .message("Tampil di pojok kiri atas video.")
            .content(et)
            .button("Batal", IosUi.CANCEL)
            .button("Simpan", IosUi.BOLD, false) {
                val n = et.text.toString().replace(Regex("[\\r\\n;=]"), " ").trim()
                if (n.isEmpty()) {
                    dlg.setError("Nama tidak boleh kosong")
                    return@button
                }
                dlg.dismiss()
                camName = n
                setCfgStr("cn", n)
                onSaved(n)
            }
            .show()
    }

    private fun cfgCard(title: String, sub: String? = null): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(18), dp(18), dp(18))
        background = rounded(CARD, 20)
        addView(tv(title, 17f, WHITE, true))
        if (sub != null) addView(tv(sub, 13f, GRAY, false), lp(WRAP, WRAP, 2))
    }

    private fun cfgSeg(title: String, labels: List<String>, selected: Int, top: Int, onPick: (Int) -> Unit): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(tv(title, 14f, GRAY, false))
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(SEG_BG, 12)
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }
        val items = mutableListOf<TextView>()
        fun paint(sel: Int) = items.forEachIndexed { i, t -> t.background = rounded(if (i == sel) BLUE else Color.TRANSPARENT, 10) }
        labels.forEachIndexed { i, label ->
            val t = tv(label, 15f, WHITE, true).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(10), 0, dp(10))
                setOnClickListener { paint(i); onPick(i) }
            }
            items.add(t)
            row.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        paint(selected)
        box.addView(row, lp(MATCH, WRAP, 6))
        return box.also { it.layoutParams = lp(MATCH, WRAP, top) }
    }

    private fun renderCfg(m: HashMap<String, String>) {
        fun iv(k: String, d: Int) = m[k]?.toIntOrNull() ?: d
        cfgView.removeAllViews()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(52), dp(18), dp(40))
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(tv("Pengaturan kamera", 24f, WHITE, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        val x = LineIcon(this, "close", sizeFrac = 0.5f).apply { background = rounded(SEG_BG, 18) }
        x.setOnClickListener { closeCfg() }
        head.addView(x, LinearLayout.LayoutParams(dp(36), dp(36)))
        col.addView(head)
        col.addView(tv("Perubahan langsung berlaku di HP kamera.", 13f, GRAY, false), lp(WRAP, WRAP, 4))

        // Kualitas video
        val vq = cfgCard("Kualitas video", "Makin rendah, makin hemat data dan ringan.")
        vq.addView(cfgSeg("Resolusi", CFG_RES.map { "${it}p" }, CFG_RES.indexOf(iv("res", 360)).coerceAtLeast(0), 16) { setCfg("res", CFG_RES[it]) })
        vq.addView(cfgSeg("Kecepatan gambar", CFG_FPS.map { "$it fps" }, CFG_FPS.indexOf(iv("fps", 10)).coerceAtLeast(0), 14) { setCfg("fps", CFG_FPS[it]) })
        vq.addView(cfgSeg("Kualitas gambar", listOf("Hemat", "Sedang", "Tinggi"), CFG_Q.indexOf(iv("q", 45)).coerceAtLeast(0), 14) { setCfg("q", CFG_Q[it]) })
        col.addView(vq, lp(MATCH, WRAP, 18))

        // Rekaman
        val used = iv("used", 0)
        val freeMb = iv("free", -1)
        val rc = cfgCard("Rekaman", (if (iv("sd", 0) == 1) "Kartu SD" else "Memori internal") + " • terpakai $used MB" + (if (freeMb >= 0) " • sisa $freeMb MB" else ""))
        rc.addView(cfgSeg("Mode rekam", listOf("Mati", "Gerak", "24 jam"), iv("rec", 1).coerceIn(0, 2), 14) { setCfg("rec", it) })
        rc.addView(cfgSeg("Lama riwayat (yang lama otomatis dihapus)", listOf("1 hari", "3 hari", "7 hari"), CFG_DAYS.indexOf(iv("days", 7)).coerceAtLeast(0), 14) { setCfg("days", CFG_DAYS[it]) })
        rc.addView(cfgSeg("Deteksi gerakan", listOf("Aktif", "Nonaktif"), if (iv("detect", 1) == 1) 0 else 1, 14) { setCfg("detect", if (it == 0) 1 else 0) })
        rc.addView(cfgSeg("Kepekaan gerak", listOf("Rendah", "Sedang", "Tinggi"), iv("sens", 1).coerceIn(0, 2), 14) { setCfg("sens", it) })
        col.addView(rc, lp(MATCH, WRAP, 16))

        // Teks pada video
        val tc = cfgCard("Teks pada video", "Nama kamera, tanggal, dan jam. Rekaman memakai teks permanen.")
        tc.addView(cfgSeg("Teks", listOf("Aktif", "Nonaktif"), if (iv("stamp", 1) == 1) 0 else 1, 14) {
            stampOn = it == 0
            setCfg("stamp", if (it == 0) 1 else 0)
        })
        tc.addView(cfgSeg("Ukuran teks", listOf("Kecil", "Sedang", "Besar"), iv("ss", 0).coerceIn(0, 2), 14) {
            stampSz = it
            setCfg("ss", it)
        })
        val curName = try { java.net.URLDecoder.decode(m["cn"] ?: "CAM+1", "UTF-8") } catch (e: Exception) { "CAM 1" }
        val nameRow = tv("Nama kamera: $curName  (ketuk untuk ubah)", 14f, BLUE, false).apply { setPadding(0, dp(12), 0, dp(4)) }
        nameRow.setOnClickListener { nameDialog(curName) { n -> nameRow.text = "Nama kamera: $n  (ketuk untuk ubah)" } }
        tc.addView(nameRow, lp(MATCH, WRAP, 6))
        col.addView(tc, lp(MATCH, WRAP, 16))

        // Kotak penanda
        val bc = cfgCard("Kotak penanda gerak", "Hanya di layar live, rekaman tetap bersih.")
        bc.addView(cfgSeg("Kotak penanda", listOf("Aktif", "Nonaktif"), if (iv("box", 1) == 1) 0 else 1, 14) { setCfg("box", if (it == 0) 1 else 0) })
        var color = iv("boxc", 0).coerceIn(0, CFG_COLORS.size - 1)
        var width = iv("boxw", 2).coerceIn(1, 5)
        val preview = object : View(this) {
            override fun onDraw(c: android.graphics.Canvas) {
                val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                    style = android.graphics.Paint.Style.STROKE
                    this.color = CFG_COLORS[color]
                    strokeWidth = width * resources.displayMetrics.density * 0.75f
                }
                val mg = p.strokeWidth
                c.drawRect(mg + dp(16), mg + dp(10), this.width - mg - dp(16), this.height - mg - dp(10), p)
            }
        }.apply { background = rounded(Color.parseColor("#2C2C2E"), 12) }
        bc.addView(tv("Warna", 14f, GRAY, false), lp(WRAP, WRAP, 14))
        val sw = mutableListOf<View>()
        fun paintSw() = sw.forEachIndexed { i, v ->
            v.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(CFG_COLORS[i])
                if (i == color) setStroke(dp(2), BLUE) else setStroke(dp(1), Color.parseColor("#48484A"))
            }
        }
        val swRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in CFG_COLORS.indices) {
            val v = View(this)
            v.setOnClickListener { color = i; setCfg("boxc", i); paintSw(); preview.invalidate() }
            sw.add(v)
            swRow.addView(v, LinearLayout.LayoutParams(dp(34), dp(34)).apply { rightMargin = dp(12) })
        }
        paintSw()
        bc.addView(swRow, lp(WRAP, WRAP, 8))
        val wl = tv("Tebal garis: $width px", 14f, GRAY, false)
        bc.addView(wl, lp(WRAP, WRAP, 14))
        val bar = SeekBar(this).apply {
            max = 4
            progress = width - 1
            IosUi.styleSeekBar(this)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    width = p + 1
                    wl.text = "Tebal garis: $width px"
                    preview.invalidate()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { setCfg("boxw", width) }
            })
        }
        bc.addView(bar, lp(MATCH, WRAP, 2))
        bc.addView(preview, lp(MATCH, dp(64), 10))
        col.addView(bc, lp(MATCH, WRAP, 16))

        val sv = ScrollView(this).apply { addView(col) }
        cfgView.addView(sv, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    // ---------- Zoom digital (cubit, geser, ketuk dua kali) ----------

    private val MAX_ZOOM = 6f

    private fun resetZoom() {
        vZoom = 1f; vPanX = 0f; vPanY = 0f
        applyVideoMatrix()
    }

    /** Hitung matrix tampilan: gambar muat di layar, lalu diperbesar [vZoom] dan digeser. */
    private fun applyVideoMatrix() {
        val bmp = lastBitmap
        val w = video.width.toFloat()
        val h = video.height.toFloat()
        if (bmp == null || w <= 0f || h <= 0f) return
        if (bmp.width != vBmpW || bmp.height != vBmpH) {
            vBmpW = bmp.width; vBmpH = bmp.height
            vZoom = 1f; vPanX = 0f; vPanY = 0f
        }
        val base = minOf(w / bmp.width, h / bmp.height)
        val sc = base * vZoom
        val cw = bmp.width * sc
        val ch = bmp.height * sc
        val maxX = maxOf(0f, (cw - w) / 2f)
        val maxY = maxOf(0f, (ch - h) / 2f)
        vPanX = vPanX.coerceIn(-maxX, maxX)
        vPanY = vPanY.coerceIn(-maxY, maxY)
        val m = android.graphics.Matrix()
        m.setScale(sc, sc)
        m.postTranslate((w - cw) / 2f + vPanX, (h - ch) / 2f + vPanY)
        video.imageMatrix = m
        zoomTag.visibility = if (vZoom > 1.02f) View.VISIBLE else View.GONE
        zoomTag.text = fmt(vZoom)
    }

    private fun zoomAt(newZoom: Float, fx: Float, fy: Float) {
        val bmp = lastBitmap ?: return
        val w = video.width.toFloat()
        val h = video.height.toFloat()
        val base = minOf(w / bmp.width, h / bmp.height)
        val z = newZoom.coerceIn(1f, MAX_ZOOM)
        val s0 = base * vZoom
        val s1 = base * z
        // Titik gambar di bawah jari tetap di tempatnya.
        val ox = (w - bmp.width * s0) / 2f + vPanX
        val oy = (h - bmp.height * s0) / 2f + vPanY
        val px = (fx - ox) / s0
        val py = (fy - oy) / s0
        val nx = fx - px * s1
        val ny = fy - py * s1
        vZoom = z
        vPanX = nx - (w - bmp.width * s1) / 2f
        vPanY = ny - (h - bmp.height * s1) / 2f
        applyVideoMatrix()
    }

    private fun setupPinchZoom() {
        video.scaleType = ImageView.ScaleType.MATRIX
        video.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> applyVideoMatrix() }
        zoomTag.setOnClickListener { resetZoom() }

        scaleDet = android.view.ScaleGestureDetector(this, object : android.view.ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: android.view.ScaleGestureDetector): Boolean {
                zoomAt(vZoom * d.scaleFactor, d.focusX, d.focusY)
                return true
            }
        })
        tapDet = android.view.GestureDetector(this, object : android.view.GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (vZoom > 1.02f) {
                    vPanX -= dx
                    vPanY -= dy
                    applyVideoMatrix()
                }
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (vZoom > 1.02f) resetZoom() else zoomAt(2.5f, e.x, e.y)
                return true
            }

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (fullMode) return true
                val v = if (top.visibility == View.VISIBLE) View.INVISIBLE else View.VISIBLE
                syncPanel(v == View.VISIBLE)
                top.visibility = v
                refreshWarn()
                applyImmersive(v != View.VISIBLE)
                return true
            }
        })
    }


    private fun selectSeg(front: Boolean) {
        camFront = front
        btnFlip.background = rounded(if (front) BLUE else GLASS, 18)
    }

    private fun setStatus(t: String, c: Int) {
        statusText.text = t
        statusDot.background = rounded(c, 6)
    }

    private fun liveOn(on: Boolean, retry: Boolean = false) {
        liveText.text = if (on) "LIVE" else if (retry) "Menyambung ulang…" else "Menyambung…"
        liveDot.background = rounded(if (on) RED else ORANGE, 4)
    }

    // ---------- Ucapkan pesan lewat HP kamera (khusus admin) ----------

    private fun sayTemplates(): MutableList<String> =
        (prefs.getString("say_tpl", "") ?: "").split("\n").filter { it.isNotBlank() }.toMutableList()

    private fun saveSayTemplates(l: List<String>) {
        prefs.edit().putString("say_tpl", l.joinToString("\n")).apply()
    }

    private fun saySend(t: String) {
        val b = base ?: return
        val q = "say=" + java.net.URLEncoder.encode(t.take(200), "UTF-8")
        Thread {
            try {
                val s = httpGet("$b/cmd?$q", 3000)
                runOnUiThread { applyStatus(s) }
                val m = HashMap<String, String>()
                s.trim().split(';').forEach {
                    val kv = it.split('=')
                    if (kv.size == 2) m[kv[0]] = kv[1]
                }
                val last = m["ttsl"] ?: ""
                toast(
                    when {
                        !s.contains("tts=") -> "Tidak terkirim"
                        m["tts"] != "1" -> "Tidak terkirim"
                        Regex("speak-?\\d+").matches(last) || last.startsWith("err") -> "Tidak terkirim"
                        else -> "Terkirim"
                    }
                )
            } catch (e: Exception) {
                toast("Tidak terkirim")
            }
        }.start()
    }

    private fun sayDialog() {
        if (!isAdmin) return
        lateinit var dlg: IosDialog
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val et = IosUi.field(this, "Ketik pesan untuk diucapkan…", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
        et.filters = arrayOf(android.text.InputFilter.LengthFilter(200))
        box.addView(et, lp(MATCH, WRAP))
        val save = tv("+ Simpan sebagai template", 14f, BLUE, false).apply { setPadding(0, dp(10), 0, dp(4)) }
        box.addView(save, lp(MATCH, WRAP))
        val listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(listBox, lp(MATCH, WRAP, 6))

        fun render() {
            listBox.removeAllViews()
            val l = sayTemplates()
            if (l.isEmpty()) {
                listBox.addView(tv("Belum ada template tersimpan.", 13f, GRAY, false))
                return
            }
            listBox.addView(tv("Template (ketuk untuk dipakai)", 13f, GRAY, false))
            for (t in l) {
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    background = rounded(SEG_BG, 10)
                    setPadding(dp(12), 0, 0, 0)
                }
                val label = tv(t, 15f, WHITE, false).apply {
                    setPadding(0, dp(11), 0, dp(11))
                    maxLines = 2
                    ellipsize = android.text.TextUtils.TruncateAt.END
                }
                label.setOnClickListener {
                    et.setText(t)
                    et.setSelection(et.text.length)
                }
                val del = tv("×", 20f, GRAY, false).apply {
                    gravity = Gravity.CENTER
                    setPadding(dp(14), dp(7), dp(14), dp(7))
                }
                del.setOnClickListener {
                    val x = sayTemplates()
                    x.remove(t)
                    saveSayTemplates(x)
                    render()
                }
                row.addView(label, LinearLayout.LayoutParams(0, WRAP, 1f))
                row.addView(del, LinearLayout.LayoutParams(WRAP, WRAP))
                listBox.addView(row, lp(MATCH, WRAP, 6))
            }
        }
        render()

        save.setOnClickListener {
            val t = et.text.toString().trim().replace("\n", " ")
            if (t.isEmpty()) {
                dlg.setError("Tulis pesan dulu")
                return@setOnClickListener
            }
            val l = sayTemplates()
            l.remove(t)
            l.add(0, t)
            saveSayTemplates(l.take(12))
            dlg.setError(null)
            render()
            toast("Template disimpan")
        }

        dlg = IosDialog(this)
            .title("Ucapkan lewat HP kamera")
            .message("Pesan dibacakan oleh suara sistem di HP kamera.")
            .content(box)
            .button("Batal", IosUi.CANCEL)
            .button("OK", IosUi.BOLD, false) {
                val t = et.text.toString().trim()
                if (t.isEmpty()) {
                    dlg.setError("Tulis pesan dulu")
                    return@button
                }
                dlg.dismiss()
                saySend(t)
            }
            .show()
    }

    private fun manualDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val et = IosUi.field(
            this, "IP kamera, mis. 192.168.1.20", InputType.TYPE_CLASS_TEXT,
            prefs.getString("base", null)?.removePrefix("http://")?.removeSuffix(":$PORT") ?: ""
        )
        val ek = IosUi.field(
            this, "Kunci akses (dari pemilik kamera)",
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD, key()
        )
        box.addView(et, lp(MATCH, WRAP))
        box.addView(ek, lp(MATCH, WRAP, 8))
        IosDialog(this)
            .title("Sambung ke kamera")
            .message("Dari luar rumah (data seluler) pakai alamat VPN, mis. Tailscale 100.x.x.x.")
            .content(box)
            .button("Batal", IosUi.CANCEL)
            .button("Sambung", IosUi.BOLD) {
                val ip = et.text.toString().trim()
                prefs.edit().putString("key", ek.text.toString().trim()).apply()
                if (ip.isNotEmpty()) {
                    prefs.edit().putString("base", "http://$ip:$PORT").apply()
                    connect()
                }
            }
            .show()
    }

    // ---------- Koneksi & pencarian kamera ----------

    private fun connect() {
        if (key().isEmpty()) { manualDialog(); return }
        startBtn.isEnabled = false
        setStatus("Mencari kamera…", ORANGE)
        Thread {
            var found: String? = null
            val saved = prefs.getString("base", null)
            if (saved != null && probe(saved, 4000)) found = saved
            if (found == null) found = scan()
            val result = found
            runOnUiThread {
                if (result == null) {
                    setStatus("Kamera tidak ditemukan", RED)
                    startBtn.isEnabled = true
                } else {
                    prefs.edit().putString("base", result).apply()
                    base = result
                    setStatus("Terhubung", GREEN)
                    showViewer()
                }
            }
        }.start()
    }

    // ---------- Playback di dalam aplikasi ----------

    /** Cari kamera (alamat tersimpan dulu, lalu pindai WiFi), lalu buka halaman Rekaman langsung di aplikasi. */
    private fun openPlayback() {
        if (key().isEmpty()) { manualDialog(); return }
        startBtn.isEnabled = false
        recBtn.isEnabled = false
        setStatus("Mencari kamera…", ORANGE)
        Thread {
            var found: String? = null
            val saved = prefs.getString("base", null)
            if (saved != null && probe(saved, 4000)) found = saved
            if (found == null) found = scan()
            val result = found
            runOnUiThread {
                startBtn.isEnabled = true
                recBtn.isEnabled = true
                if (result == null) {
                    setStatus("Kamera tidak ditemukan", RED)
                } else {
                    prefs.edit().putString("base", result).apply()
                    base = result
                    showPlayback(result)
                }
            }
        }.start()
    }

    private fun showPlayback(b: String) {
        var rv = recView
        if (rv == null) {
            rv = buildPlayback()
            recView = rv
            root.addView(rv, FrameLayout.LayoutParams(MATCH, MATCH))
        }
        rv.visibility = View.VISIBLE
        home.visibility = View.GONE
        setStatus("Belum terhubung", GRAY)
        web?.loadUrl(withKey("$b/playback"))
    }

    private fun buildPlayback(): FrameLayout {
        val box = FrameLayout(this).apply { setBackgroundColor(BG) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), 0, dp(16), 0)
        }
        val back = tv("‹ Kembali", 17f, BLUE, false).apply { setPadding(0, dp(10), dp(16), dp(10)) }
        back.setOnClickListener { backFromPlayback() }
        bar.addView(back, LinearLayout.LayoutParams(WRAP, WRAP))
        col.addView(bar, LinearLayout.LayoutParams(MATCH, dp(48)))
        val w = WebView(this).apply {
            setBackgroundColor(BG)
            settings.javaScriptEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.setSupportZoom(false)
            webViewClient = object : WebViewClient() {
                // Hanya boleh membuka halaman kamera sendiri.
                override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                    val b = base
                    return b == null || !r.url.toString().startsWith(b)
                }
            }
            setDownloadListener { url, _, cd, mime, _ -> downloadFile(url, cd, mime) }
        }
        web = w
        col.addView(w, LinearLayout.LayoutParams(MATCH, 0, 1f))
        box.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        return box
    }

    /** Tombol Kembali: tutup dialog / layar penuh di halaman dulu, baru keluar dari Rekaman. */
    private fun backFromPlayback() {
        val w = web
        if (w == null) { closePlayback(); return }
        w.evaluateJavascript(
            "(function(){var o=document.getElementById('ov2');" +
                "if(o&&o.style.display=='flex'){document.getElementById('dc').click();return 1}" +
                "o=document.getElementById('ov');" +
                "if(o&&o.style.display=='flex'){document.getElementById('dn').click();return 1}" +
                "var p=document.getElementById('pl');" +
                "if(p&&p.classList.contains('fs')){document.getElementById('fsb').click();return 1}" +
                "return 0})()"
        ) { r -> if (r != "1") closePlayback() }
    }

    private fun closePlayback() {
        val w = web
        // Batalkan konversi MP4 yang masih berjalan di HP kamera, lalu kosongkan halaman.
        w?.evaluateJavascript("try{dlStop(true)}catch(e){}", null)
        root.postDelayed({ w?.loadUrl("about:blank") }, 400)
        recView?.visibility = View.GONE
        home.visibility = View.VISIBLE
        setStatus("Belum terhubung", GRAY)
    }

    /** Unduhan dari halaman Rekaman: lewat pengelola unduhan sistem (ada notifikasi), nama file dari server. */
    private fun downloadFile(url: String, cd: String?, mime: String?) {
        try {
            val name = URLUtil.guessFileName(url, cd, mime)
            val req = DownloadManager.Request(Uri.parse(url))
                .setTitle(name)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            if (!mime.isNullOrEmpty()) req.setMimeType(mime)
            getSystemService(DownloadManager::class.java).enqueue(req)
            toast("Mengunduh $name, lihat notifikasi unduhan")
        } catch (e: Exception) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            } catch (x: Exception) {
                toast("Gagal memulai unduhan")
            }
        }
    }

    private fun key(): String = prefs.getString("key", "") ?: ""

    private fun withKey(url: String): String =
        if (key().isEmpty()) url else url + (if ('?' in url) "&" else "?") + "k=" + key()

    private fun httpGet(url: String, timeout: Int): String {
        val c = URL(withKey(url)).openConnection() as HttpURLConnection
        c.connectTimeout = timeout
        c.readTimeout = timeout + 1000
        try {
            return c.inputStream.bufferedReader().readText()
        } finally {
            c.disconnect()
        }
    }

    private fun probe(b: String, timeout: Int = 800): Boolean = try {
        httpGet("$b/status", timeout).contains("cam=")
    } catch (e: Exception) {
        false
    }

    private fun localPrefixes(): List<String> {
        val list = ArrayList<String>()
        try {
            val all = NetworkInterface.getNetworkInterfaces() ?: return list
            for (ni in Collections.list(all)) {
                if (!ni.isUp || ni.isLoopback) continue
                for (a in Collections.list(ni.inetAddresses)) {
                    if (a is Inet4Address && a.isSiteLocalAddress) {
                        val s = a.hostAddress ?: continue
                        list.add(s.substringBeforeLast('.'))
                    }
                }
            }
        } catch (e: Exception) {
        }
        return list.distinct()
    }

    private fun portOpen(ip: String): Boolean = try {
        Socket().use { it.connect(InetSocketAddress(ip, PORT), 400) }
        true
    } catch (e: Exception) {
        false
    }

    private fun scan(): String? {
        val prefixes = localPrefixes()
        if (prefixes.isEmpty()) return null
        val pool = Executors.newFixedThreadPool(64)
        val found = AtomicReference<String?>(null)
        val latch = CountDownLatch(prefixes.size * 254)
        for (p in prefixes) {
            for (i in 1..254) {
                pool.execute {
                    try {
                        if (found.get() == null) {
                            val ip = "$p.$i"
                            if (portOpen(ip)) {
                                val b = "http://$ip:$PORT"
                                if (probe(b)) found.compareAndSet(null, b)
                            }
                        }
                    } catch (e: Exception) {
                    } finally {
                        latch.countDown()
                    }
                }
            }
        }
        latch.await(15, TimeUnit.SECONDS)
        pool.shutdownNow()
        return found.get()
    }

    // ---------- Viewer ----------

    private fun showViewer() {
        home.visibility = View.GONE
        viewer.visibility = View.VISIBLE
        panelCollapsed = false
        syncPanel(true)
        top.visibility = View.VISIBLE
        refreshWarn()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        liveOn(false)
        screenMode = false
        applyFilter()
        refreshButtons()
        startStream()
        cmd("")
        root.removeCallbacks(poller)
        root.postDelayed(poller, 3000)
    }

    private fun closeViewer() {
        stopTalk()
        cfgView.visibility = View.GONE
        fullMode = false
        padWasOn = false
        btnExitFull.visibility = View.GONE
        batChip.visibility = View.GONE
        warnText = null
        chgWarn.visibility = View.GONE
        filterBtn.visibility = View.GONE
        applyImmersive(false)
        isAdmin = false
        btnCfg.visibility = View.GONE
        sayCell.visibility = View.GONE
        padRepeat?.let { root.removeCallbacks(it) }
        pad.visibility = View.GONE
        root.removeCallbacks(poller)
        screenMode = false
        applyFilter()
        refreshButtons()
        streaming = false
        gen++
        val c = conn
        Thread {
            try { c?.disconnect() } catch (e: Exception) { }
        }.start()
        viewer.visibility = View.GONE
        home.visibility = View.VISIBLE
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        video.setImageDrawable(null)
        vZoom = 1f; vPanX = 0f; vPanY = 0f; vBmpW = 0; vBmpH = 0
        zoomTag.visibility = View.GONE
        startBtn.isEnabled = true
        setStatus("Belum terhubung", GRAY)
    }

    private fun readHeaderLine(i: InputStream): String? {
        val sb = StringBuilder()
        while (true) {
            val c = i.read()
            if (c < 0) return if (sb.isEmpty()) null else sb.toString()
            if (c == '\n'.code) break
            if (c != '\r'.code) sb.append(c.toChar())
        }
        return sb.toString()
    }

    private fun startStream(path: String = "/stream") {
        if (base == null) return
        streaming = true
        val my = ++gen
        Thread {
            var first = true
            var everLive = false
            var fails = 0
            var delay = 1000L
            while (streaming && my == gen) {
                val b = base ?: break
                try {
                    val c = URL(withKey("$b$path")).openConnection() as HttpURLConnection
                    c.connectTimeout = 3000
                    c.readTimeout = 6000
                    conn = c
                    val rc = c.responseCode
                    if (rc == 401 || rc == 403) {
                        c.disconnect()
                        runOnUiThread {
                            if (my == gen) {
                                toast("Kunci akses ditolak oleh kamera")
                                closeViewer()
                            }
                        }
                        break
                    }
                    val inp = BufferedInputStream(c.inputStream, 65536)
                    while (streaming && my == gen) {
                        var len = -1
                        while (true) {
                            val line = readHeaderLine(inp) ?: throw IOException("eof")
                            if (line.isEmpty()) {
                                if (len > 0) break else continue
                            }
                            if (line.startsWith("Content-Length:", true)) {
                                len = line.substring(15).trim().toInt()
                            }
                        }
                        val buf = ByteArray(len)
                        var off = 0
                        while (off < len) {
                            val n = inp.read(buf, off, len - off)
                            if (n < 0) throw IOException("eof")
                            off += n
                        }
                        var bmp = BitmapFactory.decodeByteArray(buf, 0, len)
                        // Teks CAM + tanggal/jam digambar di gambar live (rekaman memakai teks dari HP kamera).
                        if (bmp != null && path != "/screen" && stampOn) {
                            try {
                                val fl = bmp.copy(Bitmap.Config.ARGB_8888, true)
                                if (fl != null) {
                                    drawCamStamp(android.graphics.Canvas(fl), fl.width, fl.height, camName,
                                        java.text.SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.US).format(java.util.Date()),
                                        floatArrayOf(0.026f, 0.034f, 0.045f)[stampSz.coerceIn(0, 2)], rotIdx)
                                    bmp.recycle()
                                    bmp = fl
                                }
                            } catch (e: Throwable) { }
                        }
                        if (bmp != null) {
                            lastBitmap = bmp
                            // Gambar masuk lagi: jeda sambung ulang kembali ke 1 detik.
                            fails = 0
                            delay = 1000L
                            everLive = true
                            val firstNow = first
                            first = false
                            runOnUiThread {
                                video.setImageBitmap(bmp)
                                applyVideoMatrix()
                                if (firstNow) liveOn(true)
                            }
                        }
                    }
                    c.disconnect()
                } catch (e: Exception) {
                    first = true
                    fails++
                    val retry = everLive
                    // Layar live tetap terbuka dengan gambar terakhir; hanya pil status yang berubah.
                    runOnUiThread { if (my == gen) liveOn(false, retry) }
                    if (!(streaming && my == gen)) break
                    // Tiap 3 kali gagal: kalau kamera tidak menjawab di alamat tersimpan, cari ulang di WiFi
                    // (alamat bisa berubah setelah router/HP kamera restart). Alamat VPN (100.x) tidak dipindai.
                    if (fails % 3 == 0) {
                        val cur = base
                        if (cur != null && !cur.removePrefix("http://").startsWith("100.") && !probe(cur, 1500)) {
                            val nb = scan()
                            if (nb != null && streaming && my == gen) {
                                base = nb
                                prefs.edit().putString("base", nb).apply()
                            }
                        }
                    }
                    try { Thread.sleep(delay) } catch (x: InterruptedException) { }
                    delay = minOf(delay * 2, 8000L)
                }
            }
        }.start()
    }

    // ---------- Kontrol kamera ----------

    private fun cmd(q: String) {
        val b = base ?: return
        Thread {
            try {
                val s = httpGet("$b/cmd?$q", 2000)
                runOnUiThread { applyStatus(s) }
            } catch (e: Exception) {
            }
        }.start()
    }

    private fun applyStatus(s: String) {
        val m = HashMap<String, String>()
        s.trim().split(';').forEach {
            val kv = it.split('=')
            if (kv.size == 2) m[kv[0]] = kv[1]
        }
        selectSeg(m["cam"] == "front")
        m["stamp"]?.let { stampOn = it == "1" }
        m["ss"]?.toIntOrNull()?.let { stampSz = it.coerceIn(0, 2) }
        m["cn"]?.let { try { camName = java.net.URLDecoder.decode(it, "UTF-8").ifBlank { "CAM 1" } } catch (e: Exception) { } }
        rotIdx = m["rot"]?.toIntOrNull() ?: 0
        flashOk = m["flash"] == "1"
        torchOn = m["torch"] == "1"
        appsOk = m["apps"]?.split(',')?.filter { it.isNotEmpty() }?.toSet()
            ?: if ((m["wa"] ?: "1") == "1") setOf("wa", "cam", "fb", "tt") else setOf("cam", "fb", "tt")
        touchOk = m["touch"] == "1"
        val bat = m["bat"]?.toIntOrNull() ?: -1
        val chg = m["chg"] == "1"
        val warns = ArrayList<String>()
        var wRed = false
        if (bat in 0..100) {
            val col = when {
                chg -> GREEN
                bat <= 15 -> RED
                else -> WHITE
            }
            batChip.visibility = View.VISIBLE
            batText.text = "$bat%"
            batText.setTextColor(col)
            batIcon.setColor(col)
            batIcon.charging = chg
        } else {
            batChip.visibility = View.GONE
        }
        if (m["low"] == "1") {
            val fr = m["free"]?.toLongOrNull()
            warns.add(if (fr != null) "Memori rekaman hampir penuh (sisa $fr MB)" else "Memori rekaman hampir penuh")
        }
        warnText = if (warns.isEmpty()) null else warns.joinToString("\n")
        warnColor = if (wRed) RED else ORANGE
        refreshWarn()
        isAdmin = m["role"] == "3"
        btnCfg.visibility = if (isAdmin) View.VISIBLE else View.GONE
        sayCell.visibility = if (isAdmin) View.VISIBLE else View.GONE
        refreshButtons()
    }

    private fun refreshButtons() {
        btnFlash.background = rounded(if (torchOn) YELLOW else SEG_BG, 26)
        btnFlash.setColor(if (torchOn) Color.BLACK else Color.WHITE)
        btnFlash.alpha = if (flashOk) 1f else 0.35f
        btnScreen.background = rounded(if (screenMode) BLUE else SEG_BG, 26)
        val padOn = pad.visibility == View.VISIBLE
        btnPad.background = rounded(if (padOn) BLUE else SEG_BG, 26)
    }

    private fun pollStatus() {
        val b = base ?: return
        Thread {
            try {
                val s = httpGet("$b/status", 1500)
                runOnUiThread { if (viewer.visibility == View.VISIBLE) applyStatus(s) }
            } catch (e: Exception) {
            }
        }.start()
    }

    // ---------- Cermin layar ----------

    private fun toggleScreen() {
        val b = base ?: return
        if (screenMode) {
            setScreenMode(false)
            return
        }
        Thread {
            val ok = try {
                httpGet("$b/status", 1500).contains("scr=1")
            } catch (e: Exception) {
                false
            }
            runOnUiThread {
                if (ok) setScreenMode(true)
                else toast("Di HP kamera, tekan \"Izinkan bagikan layar\" dulu")
            }
        }.start()
    }

    private fun setScreenMode(on: Boolean) {
        screenMode = on
        applyFilter()
        refreshWarn()
        vZoom = 1f; vPanX = 0f; vPanY = 0f
        refreshButtons()
        liveOn(false)
        val c = conn
        Thread {
            try { c?.disconnect() } catch (e: Exception) { }
        }.start()
        startStream(if (on) "/screen" else "/stream")
    }

    // ---------- Sentuh jarak jauh (saat mode layar) ----------

    private var tx = 0f
    private var ty = 0f
    private var tt = 0L
    private var tMoved = false

    /** Ubah titik sentuh di ImageView jadi koordinat 0..1 pada layar HP kamera. */
    private fun toNorm(px: Float, py: Float): FloatArray? {
        val bmp = lastBitmap ?: return null
        val inv = android.graphics.Matrix()
        if (!video.imageMatrix.invert(inv)) return null
        val pts = floatArrayOf(px, py)
        inv.mapPoints(pts)
        val nx = pts[0] / bmp.width
        val ny = pts[1] / bmp.height
        if (nx < 0f || nx > 1f || ny < 0f || ny > 1f) return null
        return floatArrayOf(nx, ny)
    }

    private fun f(v: Float) = String.format(Locale.US, "%.4f", v)

    private fun setupRemoteTouch() {
        video.setOnTouchListener { v, e ->
            if (!screenMode) {
                scaleDet.onTouchEvent(e)
                tapDet.onTouchEvent(e)
                return@setOnTouchListener true
            }
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    tx = e.x; ty = e.y; tt = SystemClock.elapsedRealtime(); tMoved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.hypot((e.x - tx).toDouble(), (e.y - ty).toDouble()) > dp(10)) tMoved = true
                }
                MotionEvent.ACTION_UP -> {
                    val a = toNorm(tx, ty)
                    val b = toNorm(e.x, e.y)
                    if (a != null) {
                        if (!touchOk) {
                            toast("Aktifkan \"kontrol sentuh jarak jauh\" di HP kamera dulu")
                        } else if (tMoved && b != null) {
                            val dur = (SystemClock.elapsedRealtime() - tt).coerceIn(120L, 800L)
                            cmd("x=${f(a[0])}&y=${f(a[1])}&x2=${f(b[0])}&y2=${f(b[1])}&d=$dur")
                        } else {
                            val held = SystemClock.elapsedRealtime() - tt
                            val dur = if (held > 500) 700L else 60L
                            cmd("x=${f(a[0])}&y=${f(a[1])}&d=$dur")
                        }
                    }
                }
            }
            true
        }
    }

    // ---------- Panel kontrol melayang ----------

    private fun needTouch() = toast("Aktifkan \"kontrol sentuh jarak jauh\" di HP kamera dulu")

    private fun togglePad() {
        if (pad.visibility == View.VISIBLE) {
            pad.visibility = View.GONE
            padRepeat?.let { root.removeCallbacks(it) }
            padRepeat = null
        } else {
            pad.visibility = View.VISIBLE
            placePad()
            if (!touchOk) needTouch()
            if (!screenMode) toggleScreen()
        }
        refreshButtons()
    }

    private fun placePad() {
        pad.post {
            pad.scaleX = padScale
            pad.scaleY = padScale
            if (!padPlaced) {
                padPlaced = true
                val sx = prefs.getFloat("pad_x", -1f)
                val sy = prefs.getFloat("pad_y", -1f)
                if (sx >= 0f && sy >= 0f) {
                    pad.x = sx
                    pad.y = sy
                } else {
                    pad.x = viewer.width - pad.width * padScale - dp(12)
                    pad.y = dp(110).toFloat()
                }
            }
            clampPad()
        }
    }

    private fun clampPad() {
        val maxX = (viewer.width - pad.width * padScale).coerceAtLeast(0f)
        val maxY = (viewer.height - pad.height * padScale).coerceAtLeast(0f)
        pad.x = pad.x.coerceIn(0f, maxX)
        pad.y = pad.y.coerceIn(0f, maxY)
        if (!padResizing) updateGrip()
    }

    /** Pegangan ukuran di sisi yang lebih lega: panel di setengah kanan layar, pegangan di kiri bawah. */
    private fun gripOnLeft(): Boolean = pad.x + pad.width * padScale / 2f > viewer.width / 2f

    private fun updateGrip() {
        if (!::grip.isInitialized) return
        val left = gripOnLeft()
        val g = if (left) Gravity.START else Gravity.END
        val lp = grip.layoutParams as LinearLayout.LayoutParams
        if (lp.gravity != g) {
            lp.gravity = g
            lp.leftMargin = if (left) -dp(8) else 0
            lp.rightMargin = if (left) 0 else -dp(8)
            grip.layoutParams = lp
        }
        grip.scaleX = if (left) -1f else 1f
    }

    private fun savePad() {
        prefs.edit()
            .putFloat("pad_x", pad.x)
            .putFloat("pad_y", pad.y)
            .putFloat("pad_scale", padScale)
            .apply()
    }

    private fun padSwipe(x1: Float, y1: Float, x2: Float, y2: Float) {
        cmd("x=${f(x1)}&y=${f(y1)}&x2=${f(x2)}&y2=${f(y2)}&d=250")
    }

    private fun padTap(dur: Long) {
        if (!touchOk) {
            needTouch()
            return
        }
        cmd("x=0.5000&y=0.5000&d=$dur")
    }

    /** Panah ditekan: sekali geser, ditahan = geser berulang. dir: 0 atas, 1 bawah, 2 kiri, 3 kanan. */
    private fun padDirDown(dir: Int) {
        if (!touchOk) {
            needTouch()
            return
        }
        val (x1, y1, x2, y2) = when (dir) {
            0 -> listOf(0.5f, 0.72f, 0.5f, 0.28f)
            1 -> listOf(0.5f, 0.28f, 0.5f, 0.72f)
            2 -> listOf(0.8f, 0.5f, 0.2f, 0.5f)
            else -> listOf(0.2f, 0.5f, 0.8f, 0.5f)
        }
        padRepeat?.let { root.removeCallbacks(it) }
        val r = object : Runnable {
            override fun run() {
                padSwipe(x1, y1, x2, y2)
                root.postDelayed(this, 450)
            }
        }
        padRepeat = r
        r.run()
    }

    private fun padDirUp() {
        padRepeat?.let { root.removeCallbacks(it) }
        padRepeat = null
    }

    private fun buildPad() {
        padScale = prefs.getFloat("pad_scale", 1f).coerceIn(0.5f, 2f)
        pad = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(8), dp(14), 0)
            clipToPadding = false
            background = rounded(PAD_THIN, 30)
            visibility = View.GONE
            pivotX = 0f
            pivotY = 0f
            elevation = dp(8).toFloat()
        }

        // Kepala: gagang untuk menggeser panel + tombol ubah ukuran
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val handle = FrameLayout(this)
        handle.addView(
            View(this).apply { background = rounded(Color.parseColor("#47FFFFFF"), 3) },
            FrameLayout.LayoutParams(dp(60), dp(6), Gravity.CENTER)
        )
        var offX = 0f
        var offY = 0f
        handle.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    offX = pad.x - e.rawX
                    offY = pad.y - e.rawY
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                }
                MotionEvent.ACTION_MOVE -> {
                    pad.x = e.rawX + offX
                    pad.y = e.rawY + offY
                    clampPad()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> savePad()
            }
            true
        }
        head.addView(handle, LinearLayout.LayoutParams(MATCH, dp(40)))
        pad.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))

        // Tombol arah bulat: 4 panah + titik tengah (tap)
        val dpad = DPadView(this).apply {
            onDirDown = { padDirDown(it) }
            onDirUp = { padDirUp() }
            onCenterTap = { padTap(60L) }
            onCenterLong = { padTap(700L) }
        }
        pad.addView(dpad, lp(WRAP, WRAP, 4).apply { gravity = Gravity.CENTER_HORIZONTAL })

        // Tombol navigasi: Back / Home / Recent / Notifikasi
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(PAD_RING, 30)
        }
        for ((label, key) in listOf("back" to "back", "home" to "home", "recents" to "recents", "bell" to "notif")) {
            val b = LineIcon(this, label, tint0 = PAD_ICON, sizeFrac = 0.42f).apply {
                setOnTouchListener { v, e ->
                    if (e.action == MotionEvent.ACTION_DOWN) v.alpha = 0.5f
                    else if (e.action == MotionEvent.ACTION_UP || e.action == MotionEvent.ACTION_CANCEL) v.alpha = 1f
                    false
                }
            }
            b.setOnClickListener {
                if (touchOk) cmd("key=$key") else needTouch()
            }
            nav.addView(b, LinearLayout.LayoutParams(0, dp(54), 1f))
        }
        pad.addView(nav, lp(MATCH, WRAP, 12))

        // Pegangan pojok untuk ubah ukuran: tarik, seluruh panel ikut membesar/mengecil.
        grip = LineIcon(this, "grip", tint0 = PAD_ICON, sizeFrac = 0.8f)
        pad.addView(grip, LinearLayout.LayoutParams(dp(30), dp(26)).apply {
            gravity = Gravity.END
            rightMargin = -dp(8)
            topMargin = dp(2)
        })
        var gStart = 1f
        var gDist = 1f
        var gAx = 0f
        var gAy = 0f
        var gRight = 0f
        var gLeft = false
        grip.setOnTouchListener { v, e ->
            val loc = IntArray(2)
            viewer.getLocationOnScreen(loc)
            val px = e.rawX - loc[0]
            val py = e.rawY - loc[1]
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                    padResizing = true
                    gLeft = gripOnLeft()
                    gStart = padScale
                    gRight = pad.x + pad.width * padScale
                    gAx = if (gLeft) gRight else pad.x
                    gAy = pad.y
                    gDist = maxOf(1f, kotlin.math.hypot(px - gAx, py - gAy))
                }
                MotionEvent.ACTION_MOVE -> {
                    val d = kotlin.math.hypot(px - gAx, py - gAy)
                    val maxW = if (gLeft) gRight else viewer.width - pad.x
                    val maxH = viewer.height - pad.y
                    val s = minOf(gStart * d / gDist, maxW / pad.width, maxH / pad.height).coerceIn(0.5f, 2f)
                    padScale = s
                    pad.scaleX = s
                    pad.scaleY = s
                    if (gLeft) pad.x = gRight - pad.width * s
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    padResizing = false
                    clampPad()
                    savePad()
                }
            }
            true
        }

        viewer.addView(pad, FrameLayout.LayoutParams(WRAP, WRAP))
    }

    // ---------- Pilihan aplikasi di HP kamera ----------

    private fun showAppPicker() {
        val items = listOf(
            Triple("wa", "WA", "WhatsApp"),
            Triple("cam", "CAM", "Kamera HP"),
            Triple("fb", "FB", "Facebook"),
            Triple("tt", "TT", "TikTok")
        )
        var dlg: IosDialog? = null
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for ((key, icon, name) in items) {
            val ok = key in appsOk
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(4), dp(6), dp(4), dp(6))
                alpha = if (ok) 1f else 0.35f
            }
            row.addView(
                tv(icon, 13f, WHITE, true).apply {
                    gravity = Gravity.CENTER
                    background = rounded(Color.parseColor("#33FFFFFF"), 22)
                },
                LinearLayout.LayoutParams(dp(44), dp(44))
            )
            row.addView(tv(name, 16f, WHITE, true), lp(WRAP, WRAP).apply { leftMargin = dp(14) })
            row.setOnClickListener {
                dlg?.dismiss()
                if (ok) openRemoteApp(key, name) else toast("$name tidak ditemukan di HP kamera")
            }
            list.addView(row, lp(MATCH, WRAP, 2))
        }
        dlg = IosDialog(this)
            .title("Buka aplikasi di HP kamera")
            .content(list)
            .button("Batal", IosUi.CANCEL)
            .show()
    }

    private fun openRemoteApp(key: String, name: String) {
        cmd("app=$key")
        toast("Membuka $name di HP kamera…")
        if (!screenMode) toggleScreen()
    }

    // ---------- Bicara ke HP kamera ----------

    private fun startTalk() {
        val b = base ?: return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            micPerm.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        talkFlag?.set(false)
        val flag = AtomicBoolean(true)
        talkFlag = flag
        btnMic.background = rounded(RED, 26)
        Thread {
            var rec: AudioRecord? = null
            var sock: Socket? = null
            try {
                val host = URL(b).host
                val s = Socket()
                s.tcpNoDelay = true
                s.connect(InetSocketAddress(host, TALK_PORT), 2000)
                sock = s
                val out = s.getOutputStream()
                out.write((key() + "\n").toByteArray())
                val rate = 16000
                val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                val r = AudioRecord(
                    MediaRecorder.AudioSource.MIC, rate,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    maxOf(minBuf, 4096)
                )
                rec = r
                if (r.state != AudioRecord.STATE_INITIALIZED) throw IOException("mic")
                r.startRecording()
                val buf = ByteArray(2048)
                while (flag.get()) {
                    val n = r.read(buf, 0, buf.size)
                    if (n > 0) out.write(buf, 0, n) else if (n < 0) break
                }
                out.flush()
            } catch (e: Exception) {
                if (flag.get()) toast("Gagal mengirim suara")
            } finally {
                try { rec?.stop() } catch (e: Exception) { }
                try { rec?.release() } catch (e: Exception) { }
                try { sock?.close() } catch (e: Exception) { }
                flag.set(false)
                runOnUiThread { if (talkFlag === flag || talkFlag == null) btnMic.background = rounded(SEG_BG, 26) }
            }
        }.start()
    }

    private fun stopTalk() {
        talkFlag?.set(false)
        btnMic.background = rounded(SEG_BG, 26)
    }
}


/** Teks gaya CCTV: nama kamera di kiri atas, tanggal dan jam di kiri bawah. Putih dengan garis tepi hitam. */
private fun drawCamStamp(cv: android.graphics.Canvas, w: Int, h: Int, name: String, time: String, frac: Float, rot: Int) {
    // Teks ikut berputar bersama gambar: digambar di bidang "tegak", lalu diputar sebesar rotasi gambar.
    val r = ((rot % 4) + 4) % 4
    val vw = if (r % 2 != 0) h else w
    val vh = if (r % 2 != 0) w else h
    cv.save()
    when (r) {
        1 -> { cv.translate(vh.toFloat(), 0f); cv.rotate(90f) }
        2 -> { cv.translate(w.toFloat(), h.toFloat()); cv.rotate(180f) }
        3 -> { cv.translate(0f, vw.toFloat()); cv.rotate(-90f) }
    }
    val size = maxOf(8f, vw * frac)
    val fill = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.WHITE
        textSize = size
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD)
    }
    val edge = android.graphics.Paint(fill).apply {
        color = android.graphics.Color.BLACK
        style = android.graphics.Paint.Style.STROKE
        strokeWidth = maxOf(2f, size * 0.22f)
        strokeJoin = android.graphics.Paint.Join.ROUND
    }
    val m = size * 0.6f
    cv.drawText(name, m, m + size, edge)
    cv.drawText(name, m, m + size, fill)
    cv.drawText(time, m, vh - m, edge)
    cv.drawText(time, m, vh - m, fill)
    cv.restore()
}
