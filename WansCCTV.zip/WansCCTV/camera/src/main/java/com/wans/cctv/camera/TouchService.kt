package com.wans.cctv.camera

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.util.DisplayMetrics
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

/**
 * Menerima perintah sentuh dari HP monitor dan menjalankannya di HP ini
 * (tap, geser, tombol Back/Home/Recent). Harus diaktifkan manual sekali di
 * Pengaturan > Aksesibilitas.
 */
class TouchService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: TouchService? = null

        val enabled: Boolean get() = instance != null

        /** Koordinat x,y dalam 0..1 (relatif ke layar). */
        fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long): Boolean {
            return instance?.doGesture(x1, y1, x2, y2, dur) ?: false
        }

        fun key(name: String): Boolean {
            val s = instance ?: return false
            val a = when (name) {
                "back" -> GLOBAL_ACTION_BACK
                "home" -> GLOBAL_ACTION_HOME
                "recents" -> GLOBAL_ACTION_RECENTS
                "notif" -> GLOBAL_ACTION_NOTIFICATIONS
                "lock" -> GLOBAL_ACTION_LOCK_SCREEN
                else -> return false
            }
            return s.performGlobalAction(a)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    private fun doGesture(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long): Boolean {
        return try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val m = DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(m)
            val p = Path()
            p.moveTo(x1.coerceIn(0f, 1f) * m.widthPixels, y1.coerceIn(0f, 1f) * m.heightPixels)
            if (x1 != x2 || y1 != y2) {
                p.lineTo(x2.coerceIn(0f, 1f) * m.widthPixels, y2.coerceIn(0f, 1f) * m.heightPixels)
            }
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(p, 0, dur.coerceIn(20L, 3000L)))
                .build()
            dispatchGesture(g, null, null)
        } catch (e: Exception) {
            false
        }
    }
}
