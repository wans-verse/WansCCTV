package com.wans.cctv.camera

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.BatteryManager
import android.os.Process
import android.os.SystemClock
import java.io.BufferedInputStream
import java.io.DataInputStream
import java.io.EOFException
import java.io.File
import java.io.FileInputStream

/**
 * Ubah rekaman .mjpg menjadi MP4 (H.264) di HP kamera, hanya memakai MediaCodec + MediaMuxer bawaan Android.
 * Satu konversi dalam satu waktu, berjalan di thread latar berprioritas rendah, dan hasilnya hanya disimpan
 * satu (yang terakhir) di cache supaya tidak memenuhi penyimpanan. Waktu tiap frame mengikuti stempel waktu asli.
 */
object Mp4Converter {

    private const val PROSES = 0
    private const val SIAP = 1
    private const val GAGAL = 2

    /** Baterai di bawah ini (persen) dan tidak dicas: konversi ditolak. */
    private const val MIN_BATTERY = 15
    private const val MARGIN_MB = 100L

    class Job(val rel: String, val dst: File) {
        @Volatile var state = PROSES
        @Volatile var pct = 0
        @Volatile var msg = ""
        @Volatile var cancel = false
    }

    private class Cancelled : Exception()

    @Volatile private var job: Job? = null

    private fun dir(ctx: Context) = File(ctx.applicationContext.cacheDir, "mp4").also { it.mkdirs() }

    /**
     * Mulai konversi (kalau belum), atau laporkan statusnya. Mengembalikan (kode HTTP, isi).
     * Isi: "proses;persen" | "siap;ukuranKB" | "gagal;pesan" | pesan biasa untuk kode non-200.
     */
    @Synchronized
    fun request(ctx: Context, rel: String, src: File, cancel: Boolean): Pair<String, String> {
        val cur = job
        if (cancel) {
            if (cur != null && cur.rel == rel && cur.state == PROSES) cur.cancel = true
            return "200 OK" to "batal"
        }
        if (cur != null && cur.rel == rel) {
            when (cur.state) {
                PROSES -> return "200 OK" to "proses;${cur.pct}"
                SIAP -> if (cur.dst.isFile) return "200 OK" to "siap;${cur.dst.length() / 1024}"
                else -> {
                    job = null
                    return "200 OK" to "gagal;${cur.msg}"
                }
            }
        }
        if (cur != null && cur.state == PROSES) {
            return "503 Service Unavailable" to "Konversi rekaman lain sedang berjalan, tunggu sampai selesai"
        }
        if (lowBattery(ctx)) {
            return "503 Service Unavailable" to "Baterai HP kamera rendah. Colokkan charger dulu, lalu coba lagi"
        }
        val d = dir(ctx)
        d.listFiles()?.forEach { it.delete() } // buang hasil lama / sisa konversi yang terhenti
        val need = src.length() + (MARGIN_MB shl 20) * 2
        if (d.usableSpace < need) {
            return "507 Insufficient Storage" to "Ruang penyimpanan HP kamera kurang untuk konversi MP4"
        }
        val j = Job(rel, File(d, "cctv_${SystemClock.elapsedRealtime()}.mp4"))
        job = j
        Thread({
            try { Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND) } catch (e: Exception) { }
            run(j, src)
        }, "mp4-konversi").apply { isDaemon = true; priority = Thread.MIN_PRIORITY }.start()
        return "200 OK" to "proses;0"
    }

    /** Hasil MP4 yang sudah siap untuk rekaman [rel], atau null. */
    @Synchronized
    fun ready(rel: String): File? {
        val j = job ?: return null
        return if (j.rel == rel && j.state == SIAP && j.dst.isFile) j.dst else null
    }

    /** Dipanggil saat service berhenti. */
    @Synchronized
    fun shutdown(ctx: Context) {
        job?.cancel = true
        job = null
        try { dir(ctx).listFiles()?.forEach { it.delete() } } catch (e: Exception) { }
    }

    private fun lowBattery(ctx: Context): Boolean = try {
        val i: Intent? = ctx.applicationContext.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val plugged = (i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
        level >= 0 && !plugged && level * 100 / scale.coerceAtLeast(1) < MIN_BATTERY
    } catch (e: Exception) {
        false
    }

    private fun run(j: Job, src: File) {
        try {
            convert(j, src)
            if (j.cancel) throw Cancelled()
            j.pct = 100
            j.state = SIAP
        } catch (e: Cancelled) {
            try { j.dst.delete() } catch (x: Exception) { }
            synchronized(this) { if (job === j) job = null }
        } catch (e: Throwable) {
            try { j.dst.delete() } catch (x: Exception) { }
            j.msg = when {
                e is OutOfMemoryError -> "Memori HP kamera tidak cukup untuk konversi"
                e is IllegalStateException && e.message == "kosong" -> "Rekaman kosong atau rusak"
                else -> "Konversi gagal, HP kamera mungkin tidak mendukung. Unduh format asli (.mjpg) saja"
            }
            j.state = GAGAL
        }
    }

    private fun convert(j: Job, src: File) {
        val total = src.length().coerceAtLeast(1L)
        var wr: Writer? = null
        try {
            DataInputStream(BufferedInputStream(FileInputStream(src), 65536)).use { inp ->
                var read = 0L
                var t0 = -1L
                var lastPts = -1L
                var px = IntArray(0)
                while (true) {
                    if (j.cancel || !CameraService.running) throw Cancelled()
                    val t = try { inp.readLong() } catch (e: EOFException) { break }
                    val n = try { inp.readInt() } catch (e: EOFException) { break }
                    if (n <= 0 || n > 2_000_000) break
                    val d = ByteArray(n)
                    try { inp.readFully(d) } catch (e: EOFException) { break }
                    read += 12L + n
                    j.pct = (read * 99 / total).toInt().coerceIn(0, 99)
                    val bmp = BitmapFactory.decodeByteArray(d, 0, n) ?: continue
                    val wv: Writer = wr ?: run {
                        val w0 = bmp.width and -2
                        val h0 = bmp.height and -2
                        if (w0 < 16 || h0 < 16) { bmp.recycle(); throw IllegalStateException("kosong") }
                        val created = Writer(j.dst, w0, h0)
                        wr = created
                        px = IntArray(w0 * h0)
                        t0 = t
                        created
                    }
                    val w = wv.w
                    val h = wv.h
                    val s = if (bmp.width != w || bmp.height != h) Bitmap.createScaledBitmap(bmp, w, h, true) else bmp
                    s.getPixels(px, 0, w, 0, 0, w, h)
                    if (s !== bmp) s.recycle()
                    bmp.recycle()
                    var pts = (t - t0) * 1000L
                    if (pts <= lastPts) pts = lastPts + 1
                    lastPts = pts
                    wv.add(px, pts)
                }
                val wf: Writer = wr ?: throw IllegalStateException("kosong")
                wf.finish(lastPts + 1)
            }
        } finally {
            wr?.release()
        }
    }

    /** Pembungkus encoder H.264 + muxer MP4. Masukan lewat buffer YUV supaya stempel waktu bisa diatur sendiri. */
    private class Writer(val dst: File, val w: Int, val h: Int) {
        private val enc: MediaCodec
        private var mux: MediaMuxer? = null
        private var track = -1
        private var started = false
        private var done = false
        private val info = MediaCodec.BufferInfo()

        init {
            val f = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h)
            f.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
            f.setInteger(MediaFormat.KEY_BIT_RATE, (w * h * 3).coerceIn(600_000, 6_000_000))
            f.setInteger(MediaFormat.KEY_FRAME_RATE, 15)
            f.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
            enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            try {
                enc.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                enc.start()
            } catch (e: Exception) {
                try { enc.release() } catch (x: Exception) { }
                throw e
            }
        }

        fun add(px: IntArray, pts: Long) {
            while (true) {
                val i = enc.dequeueInputBuffer(10_000L)
                if (i >= 0) {
                    val img = enc.getInputImage(i) ?: throw IllegalStateException("format gambar tidak didukung")
                    fill(img, px)
                    enc.queueInputBuffer(i, 0, w * h * 3 / 2, pts, 0)
                    break
                }
                drain(0L)
            }
            drain(0L)
        }

        fun finish(pts: Long) {
            val deadline = SystemClock.elapsedRealtime() + 20_000L
            while (true) {
                val i = enc.dequeueInputBuffer(10_000L)
                if (i >= 0) {
                    enc.queueInputBuffer(i, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    break
                }
                drain(0L)
                if (SystemClock.elapsedRealtime() > deadline) throw IllegalStateException("encoder macet")
            }
            while (!done) {
                drain(10_000L)
                if (SystemClock.elapsedRealtime() > deadline) throw IllegalStateException("encoder macet")
            }
        }

        private fun drain(timeoutUs: Long) {
            while (true) {
                val o = enc.dequeueOutputBuffer(info, timeoutUs)
                if (o == MediaCodec.INFO_TRY_AGAIN_LATER) return
                if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val m = MediaMuxer(dst.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                    mux = m
                    track = m.addTrack(enc.outputFormat)
                    m.start()
                    started = true
                } else if (o >= 0) {
                    val b = enc.getOutputBuffer(o)
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                    if (b != null && info.size > 0 && started) {
                        b.position(info.offset)
                        b.limit(info.offset + info.size)
                        mux?.writeSampleData(track, b, info)
                    }
                    enc.releaseOutputBuffer(o, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) { done = true; return }
                }
            }
        }

        /** ARGB -> YUV420 (BT.601). Chroma dirata-ratakan per blok 2x2. */
        private fun fill(img: Image, px: IntArray) {
            val pl = img.planes
            val yb = pl[0].buffer
            val ub = pl[1].buffer
            val vb = pl[2].buffer
            val ys = pl[0].rowStride
            val yp = pl[0].pixelStride
            val us = pl[1].rowStride
            val up = pl[1].pixelStride
            val vs = pl[2].rowStride
            val vp = pl[2].pixelStride
            for (j in 0 until h) {
                val row = j * w
                val yo = j * ys
                for (i in 0 until w) {
                    val c = px[row + i]
                    val r = c shr 16 and 255
                    val g = c shr 8 and 255
                    val b = c and 255
                    yb.put(yo + i * yp, (((66 * r + 129 * g + 25 * b + 128) shr 8) + 16).toByte())
                }
            }
            for (j in 0 until h / 2) {
                for (i in 0 until w / 2) {
                    var r = 0; var g = 0; var b = 0
                    for (dy in 0..1) for (dx in 0..1) {
                        val c = px[(j * 2 + dy) * w + i * 2 + dx]
                        r += c shr 16 and 255
                        g += c shr 8 and 255
                        b += c and 255
                    }
                    r = r shr 2; g = g shr 2; b = b shr 2
                    val u = ((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128
                    val v = ((112 * r - 94 * g - 18 * b + 128) shr 8) + 128
                    ub.put(j * us + i * up, u.coerceIn(0, 255).toByte())
                    vb.put(j * vs + i * vp, v.coerceIn(0, 255).toByte())
                }
            }
        }

        fun release() {
            try { enc.stop() } catch (e: Exception) { }
            try { enc.release() } catch (e: Exception) { }
            try { if (started) mux?.stop() } catch (e: Exception) { }
            try { mux?.release() } catch (e: Exception) { }
        }
    }
}
