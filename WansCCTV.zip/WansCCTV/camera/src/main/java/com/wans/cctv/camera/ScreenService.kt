package com.wans.cctv.camera

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.io.ByteArrayOutputStream
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

/**
 * Merekam layar HP kamera (MediaProjection) dan menyimpan frame JPEG terbaru.
 * Frame disajikan oleh CameraService lewat endpoint /screen.
 */
class ScreenService : Service() {

    companion object {
        @Volatile
        var active = false
        val frame = AtomicReference<ByteArray?>(null)
        val seq = AtomicLong(0)

        // Lebar gambar yang dikirim (px). Makin besar makin tajam, tapi makin berat.
        private const val OUT_WIDTH = 720
        private const val JPEG_QUALITY = 80
        private const val MIN_INTERVAL = 170L
    }

    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var held: Image? = null
    private var buf: Bitmap? = null
    private var lastEnc = 0L

    private val flush = Runnable {
        val i = held
        held = null
        if (i != null) encode(i)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra("data", Intent::class.java)
        } else {
            intent?.getParcelableExtra("data")
        }
        if (code != Activity.RESULT_OK || data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (active) teardown()
        try {
            startProjection(code, data)
        } catch (e: Exception) {
            teardown()
            stopSelf()
        }
        // Izin proyeksi tidak bisa dipakai ulang setelah service dimatikan sistem
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        teardown()
        super.onDestroy()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("cctv_screen", "Bagikan Layar", NotificationManager.IMPORTANCE_LOW)
        )
        val n: Notification = NotificationCompat.Builder(this, "cctv_screen")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("Layar siap dibagikan")
            .setContentText("Layar HP ini bisa dilihat dari HP monitor")
            .setOngoing(true)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else 0
        ServiceCompat.startForeground(this, 2, n, type)
    }

    @Suppress("DEPRECATION")
    private fun startProjection(code: Int, data: Intent) {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = mpm.getMediaProjection(code, data) ?: throw IllegalStateException("no projection")
        projection = p

        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val m = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        val scale = minOf(1f, OUT_WIDTH.toFloat() / m.widthPixels)
        val w = ((m.widthPixels * scale).toInt() and 1.inv()).coerceAtLeast(2)
        val h = ((m.heightPixels * scale).toInt() and 1.inv()).coerceAtLeast(2)

        val t = HandlerThread("wans-screen")
        t.start()
        thread = t
        val hd = Handler(t.looper)
        handler = hd

        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        reader = r
        r.setOnImageAvailableListener({ rd -> onFrame(rd) }, hd)

        // Wajib didaftarkan sebelum membuat VirtualDisplay (Android 14+)
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                main.post { stopSelf() }
            }
        }, hd)

        vd = p.createVirtualDisplay(
            "wanscctv", w, h, m.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            r.surface, null, hd
        )
        frame.set(null)
        active = true
    }

    private fun onFrame(rd: ImageReader) {
        var got: Image? = null
        try {
            got = rd.acquireLatestImage()
        } catch (e: Exception) {
        }
        val img = got ?: return
        val hd = handler
        val now = SystemClock.elapsedRealtime()
        val wait = MIN_INTERVAL - (now - lastEnc)
        if (wait <= 0 || hd == null) {
            hd?.removeCallbacks(flush)
            try { held?.close() } catch (e: Exception) { }
            held = null
            encode(img)
        } else {
            // Terlalu cepat: simpan frame terbaru, kirim sebentar lagi supaya frame akhir tidak hilang
            try { held?.close() } catch (e: Exception) { }
            held = img
            hd.removeCallbacks(flush)
            hd.postDelayed(flush, wait)
        }
    }

    private fun encode(img: Image) {
        try {
            val plane = img.planes[0]
            val pw = plane.rowStride / plane.pixelStride
            val old = buf
            val b: Bitmap = if (old != null && old.width == pw && old.height == img.height) {
                old
            } else {
                Bitmap.createBitmap(pw, img.height, Bitmap.Config.ARGB_8888).also { buf = it }
            }
            val bb = plane.buffer
            bb.rewind()
            b.copyPixelsFromBuffer(bb)
            val out = if (pw == img.width) b else Bitmap.createBitmap(b, 0, 0, img.width, img.height)
            val bos = ByteArrayOutputStream(120000)
            out.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, bos)
            if (out !== b) out.recycle()
            frame.set(bos.toByteArray())
            seq.incrementAndGet()
            lastEnc = SystemClock.elapsedRealtime()
        } catch (e: Exception) {
        } finally {
            try { img.close() } catch (e: Exception) { }
        }
    }

    private fun teardown() {
        active = false
        try { handler?.removeCallbacks(flush) } catch (e: Exception) { }
        try { held?.close() } catch (e: Exception) { }
        held = null
        try { vd?.release() } catch (e: Exception) { }
        vd = null
        try { reader?.close() } catch (e: Exception) { }
        reader = null
        try { projection?.stop() } catch (e: Exception) { }
        projection = null
        try { thread?.quitSafely() } catch (e: Exception) { }
        thread = null
        handler = null
        buf = null
        frame.set(null)
    }
}
