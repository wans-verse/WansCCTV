package com.wans.cctv.camera

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/**
 * Setelah HP kamera menyala ulang: kalau sebelumnya kamera aktif dan "Jalankan otomatis" menyala,
 * hidupkan lagi. Android 11 ke atas melarang layanan kamera dimulai dari latar belakang
 * (termasuk dari BOOT_COMPLETED), jadi di sana yang dikirim adalah notifikasi "Ketuk untuk mengaktifkan CCTV".
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(ctx: Context, intent: Intent) {
        val a = intent.action
        if (a != Intent.ACTION_BOOT_COMPLETED &&
            a != "android.intent.action.QUICKBOOT_POWERON" &&
            a != "com.htc.intent.action.QUICKBOOT_POWERON"
        ) return
        if (!CamSettings.autoStart(ctx) || !CamSettings.wantOn(ctx)) return
        if (CameraService.running) return
        if (Build.VERSION.SDK_INT < 30) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, CameraService::class.java))
                return
            } catch (e: Exception) {
                // jatuh ke notifikasi di bawah
            }
        }
        notifyTap(ctx)
    }

    companion object {
        const val NOTIF_ID = 2

        fun notifyTap(ctx: Context) {
            try {
                val nm = ctx.getSystemService(NotificationManager::class.java)
                nm.createNotificationChannel(
                    NotificationChannel("cctv_boot", "Pengingat CCTV", NotificationManager.IMPORTANCE_HIGH)
                )
                val open = PendingIntent.getActivity(
                    ctx, 0,
                    Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                val n = NotificationCompat.Builder(ctx, "cctv_boot")
                    .setSmallIcon(android.R.drawable.ic_menu_camera)
                    .setContentTitle("CCTV belum aktif")
                    .setContentText("HP baru menyala. Ketuk untuk mengaktifkan CCTV.")
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setCategory(NotificationCompat.CATEGORY_REMINDER)
                    .setContentIntent(open)
                    .setAutoCancel(true)
                    .build()
                nm.notify(NOTIF_ID, n)
            } catch (e: Exception) {
            }
        }
    }
}
