package com.wans.cctv.camera

import android.content.Context
import java.security.MessageDigest

/** Peran akses: 0 = ditolak, 1 = hanya live, 2 = live + rekaman + kontrol kamera, 3 = admin (semua). */
object Auth {
    const val NONE = 0
    const val LIVE = 1
    const val FULL = 2
    const val ADMIN = 3

    /** Kunci hanya angka, panjangnya diatur di sini (ubah kalau mau lebih pendek/panjang). */
    const val MIN_DIGITS = 4
    const val MAX_DIGITS = 16

    private fun p(c: Context) = c.getSharedPreferences("auth", Context.MODE_PRIVATE)

    /** Kembalikan pesan error kalau kunci tidak valid, null kalau valid. */
    fun validate(key: String): String? = when {
        key.isEmpty() || !key.all { it in '0'..'9' } -> "Kunci harus angka saja"
        key.length < MIN_DIGITS || key.length > MAX_DIGITS -> "Kunci $MIN_DIGITS–$MAX_DIGITS digit angka"
        else -> null
    }

    /** Kunci admin yang diatur manual. Kosong = belum diatur. */
    @Synchronized
    fun adminKey(c: Context): String = p(c).getString("admin", "") ?: ""

    fun hasAdmin(c: Context) = adminKey(c).isNotEmpty()

    /** Atur kunci admin manual. Return pesan error, atau null kalau berhasil. */
    @Synchronized
    fun setAdmin(c: Context, key: String): String? {
        validate(key)?.let { return it }
        if (list(c).any { it.third == key }) return "Kunci sudah dipakai akses keluarga"
        p(c).edit().putString("admin", key).apply()
        return null
    }

    /** Daftar akses keluarga: nama, peran, token. */
    @Synchronized
    fun list(c: Context): List<Triple<String, Int, String>> =
        (p(c).getString("tokens", "") ?: "").lines().filter { it.count { ch -> ch == '|' } == 2 }.map {
            val s = it.split("|")
            Triple(s[0], s[1].toIntOrNull() ?: LIVE, s[2])
        }

    /** Tambah akses keluarga dengan kunci manual. Return pesan error, atau null kalau berhasil. */
    @Synchronized
    fun add(c: Context, name: String, role: Int, key: String): String? {
        validate(key)?.let { return it }
        if (key == adminKey(c) || list(c).any { it.third == key }) return "Kunci sudah dipakai, pilih angka lain"
        val safe = name.replace("|", "").replace("\n", "").take(20)
        save(c, list(c) + Triple(safe, role, key))
        return null
    }

    @Synchronized
    fun remove(c: Context, token: String) = save(c, list(c).filter { it.third != token })

    @Synchronized
    fun removeAll(c: Context) = save(c, emptyList())

    private fun save(c: Context, l: List<Triple<String, Int, String>>) {
        p(c).edit().putString("tokens", l.joinToString("\n") { "${it.first}|${it.second}|${it.third}" }).apply()
    }

    private fun same(a: String, b: String) = MessageDigest.isEqual(a.toByteArray(), b.toByteArray())

    fun role(c: Context, key: String?): Int {
        if (key.isNullOrEmpty()) return NONE
        val admin = adminKey(c)
        if (admin.isNotEmpty() && same(key, admin)) return ADMIN
        var r = NONE
        for ((_, role, t) in list(c)) if (same(key, t)) r = role
        return r
    }
}
