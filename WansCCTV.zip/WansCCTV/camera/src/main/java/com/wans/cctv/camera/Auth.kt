package com.wans.cctv.camera

import android.content.Context
import java.security.MessageDigest
import java.security.SecureRandom

/** Peran akses: 0 = ditolak, 1 = hanya live, 2 = live + rekaman + kontrol kamera, 3 = admin (semua). */
object Auth {
    const val NONE = 0
    const val LIVE = 1
    const val FULL = 2
    const val ADMIN = 3

    private const val ALPHA = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    private val rnd = SecureRandom()
    private fun p(c: Context) = c.getSharedPreferences("auth", Context.MODE_PRIVATE)
    private fun gen(n: Int) = (1..n).map { ALPHA[rnd.nextInt(ALPHA.length)] }.joinToString("")

    @Synchronized
    fun adminKey(c: Context): String =
        p(c).getString("admin", null) ?: gen(16).also { p(c).edit().putString("admin", it).apply() }

    @Synchronized
    fun resetAdmin(c: Context): String = gen(16).also { p(c).edit().putString("admin", it).apply() }

    /** Daftar akses keluarga: nama, peran, token. */
    @Synchronized
    fun list(c: Context): List<Triple<String, Int, String>> =
        (p(c).getString("tokens", "") ?: "").lines().filter { it.count { ch -> ch == '|' } == 2 }.map {
            val s = it.split("|")
            Triple(s[0], s[1].toIntOrNull() ?: LIVE, s[2])
        }

    @Synchronized
    fun add(c: Context, name: String, role: Int): String {
        val t = gen(20)
        val safe = name.replace("|", "").replace("\n", "").take(20)
        val all = list(c) + Triple(safe, role, t)
        save(c, all)
        return t
    }

    @Synchronized
    fun remove(c: Context, token: String) = save(c, list(c).filter { it.third != token })

    @Synchronized
    fun removeAll(c: Context) = save(c, emptyList())

    private fun save(c: Context, l: List<Triple<String, Int, String>>) {
        p(c).edit().putString("tokens", l.joinToString("\n") { "${it.first}|${it.second}|${it.third}" }).apply()
    }

    private fun same(a: String, b: String) = MessageDigest.isEqual(a.toByteArray(), b.toByteArray())

    fun role(c: Context, key: String?): Int {
        if (key.isNullOrEmpty()) return NONE
        if (same(key, adminKey(c))) return ADMIN
        var r = NONE
        for ((_, role, t) in list(c)) if (same(key, t)) r = role
        return r
    }
}
