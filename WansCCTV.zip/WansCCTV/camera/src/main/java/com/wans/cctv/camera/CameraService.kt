package com.wans.cctv.camera

import android.app.KeyguardManager
import android.content.Context
import android.content.SharedPreferences
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Matrix
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Size
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.roundToInt

/** Pengaturan kualitas video kamera (disimpan di HP kamera, berlaku langsung). */
object CamSettings {
    const val PREFS = "cam_settings"
    const val K_RES = "res"
    const val K_FPS = "fps"
    const val K_Q = "q"
    const val K_REC = "rec"      // 0 mati, 1 gerak, 2 terus-menerus
    const val K_DAYS = "days"    // lama riwayat (hari)
    const val K_SENS = "sens"    // 0 rendah, 1 sedang, 2 tinggi
    const val K_NTFY = "ntfy"    // nama topik ntfy.sh untuk notifikasi gerak

    // Sisi pendek gambar (piksel): 240p / 360p / 480p
    val RES = intArrayOf(240, 360, 480)
    // Batas kecepatan kirim gambar (frame per detik)
    val FPS = intArrayOf(5, 10, 15)
    // Kualitas JPEG: Hemat / Sedang / Tinggi
    val QUAL = intArrayOf(45, 55, 65)

    private const val DEF_RES = 360
    private const val DEF_FPS = 10
    private const val DEF_Q = 45

    val DAYS = intArrayOf(1, 3, 7)
    fun rec(c: Context): Int = prefs(c).getInt(K_REC, 1).coerceIn(0, 2)
    fun days(c: Context): Int = prefs(c).getInt(K_DAYS, 7).let { if (it in DAYS) it else 7 }
    fun sens(c: Context): Int = prefs(c).getInt(K_SENS, 1).coerceIn(0, 2)
    fun ntfy(c: Context): String = prefs(c).getString(K_NTFY, "") ?: ""

    fun prefs(c: Context): SharedPreferences = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun res(c: Context): Int = prefs(c).getInt(K_RES, DEF_RES).let { if (it in RES) it else DEF_RES }
    fun fps(c: Context): Int = prefs(c).getInt(K_FPS, DEF_FPS).let { if (it in FPS) it else DEF_FPS }
    fun quality(c: Context): Int = prefs(c).getInt(K_Q, DEF_Q).let { if (it in QUAL) it else DEF_Q }

    /** Jarak minimal antar frame (ms). Kamera mengirim ±30 fps, jadi dibulatkan ke kelipatannya. */
    fun gapMs(fps: Int): Long = when {
        fps <= 5 -> 190L
        fps <= 10 -> 95L
        else -> 60L
    }

    /** Ukuran minta ke kamera (kamera memilih ukuran terdekat yang ia dukung). */
    fun captureSize(res: Int): Size = when (res) {
        240 -> Size(320, 240)
        360 -> Size(480, 360)
        else -> Size(640, 480)
    }
}

class CameraService : LifecycleService() {

    companion object {
        const val PORT = 8080
        const val TALK_PORT = 8081
        const val MAX_VIEWERS = 4
        // Volume suara dari monitor (30% dari maksimum)
        private const val TALK_VOLUME = 0.3f
        // Aplikasi yang boleh dibuka dari monitor: kode -> daftar paket yang dicoba berurutan
        private val APP_PKGS = mapOf(
            "wa" to listOf("com.whatsapp", "com.whatsapp.w4b"),
            "fb" to listOf("com.facebook.katana", "com.facebook.lite"),
            "tt" to listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.zhiliaoapp.musically.go")
        )
        private val APP_KEYS = listOf("wa", "cam", "fb", "tt")
        @Volatile
        var running = false
    }

    private val main = Handler(Looper.getMainLooper())
    private val analyzerExec = Executors.newSingleThreadExecutor()
    private val pool = Executors.newCachedThreadPool()
    private val frame = AtomicReference<ByteArray?>(null)
    private val seq = AtomicLong(0)

    private var provider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var server: ServerSocket? = null
    private var talkServer: ServerSocket? = null
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null
    private var screenWake: PowerManager.WakeLock? = null

    private val screenViewers = AtomicInteger(0)
    private val liveViewers = AtomicInteger(0)
    private val fails = HashMap<String, Pair<Int, Long>>()
    private val recorder by lazy { Recorder(this) { sendPush() } }
    private val volLock = Any()
    private var talkers = 0
    private var savedVol = -1

    @Volatile private var front = false
    @Volatile private var zoom = 1f
    @Volatile private var zMin = 1f
    @Volatile private var zMax = 1f
    @Volatile private var extraRot = 0
    @Volatile private var lastTs = 0L
    @Volatile private var hasFlash = false
    @Volatile private var torchWant = false
    @Volatile private var maxShort = 360
    @Volatile private var minGap = 95L
    @Volatile private var jpegQ = 45

    private val settingsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        loadSettings(key == CamSettings.K_RES)
    }

    private fun loadSettings(rebind: Boolean) {
        maxShort = CamSettings.res(this)
        minGap = CamSettings.gapMs(CamSettings.fps(this))
        jpegQ = CamSettings.quality(this)
        if (rebind) main.post { bindCamera() }
    }

    override fun onCreate() {
        super.onCreate()
        running = true
        startAsForeground()
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "wanscctv:cam").apply { acquire() }
            val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
            wifi = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "wanscctv:wifi").apply { acquire() }
        } catch (e: Exception) {
        }
        loadSettings(false)
        CamSettings.prefs(this).registerOnSharedPreferenceChangeListener(settingsListener)
        startServer()
        startTalkServer()
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            provider = f.get()
            bindCamera()
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        try { CamSettings.prefs(this).unregisterOnSharedPreferenceChangeListener(settingsListener) } catch (e: Exception) { }
        try { server?.close() } catch (e: Exception) { }
        try { talkServer?.close() } catch (e: Exception) { }
        try { provider?.unbindAll() } catch (e: Exception) { }
        try { if (wake?.isHeld == true) wake?.release() } catch (e: Exception) { }
        try { if (wifi?.isHeld == true) wifi?.release() } catch (e: Exception) { }
        releaseScreen()
        try { stopService(Intent(this, ScreenService::class.java)) } catch (e: Exception) { }
        analyzerExec.execute { recorder.close(CamSettings.days(this)) }
        analyzerExec.shutdown()
        pool.shutdownNow()
        super.onDestroy()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("cctv", "CCTV Kamera", NotificationManager.IMPORTANCE_LOW)
        )
        val n = NotificationCompat.Builder(this, "cctv")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("Kamera CCTV aktif")
            .setContentText("Siap disambung dari HP monitor")
            .setOngoing(true)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA else 0
        ServiceCompat.startForeground(this, 1, n, type)
    }

    // ---------- Kamera ----------

    private fun bindCamera() {
        if (!running) return
        val p = provider ?: return
        try {
            p.unbindAll()
            val selector = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
            val analysis = ImageAnalysis.Builder()
                .setTargetResolution(CamSettings.captureSize(maxShort))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
            analysis.setAnalyzer(analyzerExec) { img -> handle(img) }
            camera = p.bindToLifecycle(this, selector, analysis)
            val zs = camera?.cameraInfo?.zoomState?.value
            if (zs != null) {
                zMin = zs.minZoomRatio
                zMax = minOf(zs.maxZoomRatio, 10f)
            }
            zoom = zoom.coerceIn(zMin, zMax)
            camera?.cameraControl?.setZoomRatio(zoom)
            hasFlash = camera?.cameraInfo?.hasFlashUnit() == true
            if (hasFlash) camera?.cameraControl?.enableTorch(torchWant)
        } catch (e: Exception) {
            if (front) {
                // HP tidak punya kamera depan -> kembali ke belakang
                front = false
                main.post { bindCamera() }
            }
        }
    }

    private fun handle(img: ImageProxy) {
        try {
            val now = SystemClock.elapsedRealtime()
            if (now - lastTs < minGap) return
            lastTs = now
            val bmp = img.toBitmap()
            val deg = (img.imageInfo.rotationDegrees + extraRot * 90) % 360
            val out = if (deg == 0) bmp else {
                val m = Matrix()
                m.postRotate(deg.toFloat())
                Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            // Kecilkan ke resolusi pilihan (sisi pendek = 240/360/480) supaya data benar-benar hemat
            val short = minOf(out.width, out.height)
            val scaled = if (short > maxShort) {
                val r = maxShort.toFloat() / short
                Bitmap.createScaledBitmap(
                    out,
                    (out.width * r).roundToInt().coerceAtLeast(2),
                    (out.height * r).roundToInt().coerceAtLeast(2),
                    true
                )
            } else out
            val bos = ByteArrayOutputStream(40000)
            scaled.compress(Bitmap.CompressFormat.JPEG, jpegQ, bos)
            val jb = bos.toByteArray()
            frame.set(jb)
            seq.incrementAndGet()
            recorder.onFrame(scaled, jb, System.currentTimeMillis(), CamSettings.rec(this), CamSettings.sens(this), CamSettings.days(this))
        } catch (e: Exception) {
        } finally {
            img.close()
        }
    }

    // ---------- Server HTTP kecil ----------

    private fun startServer() {
        Thread {
            try {
                val ss = ServerSocket()
                ss.reuseAddress = true
                ss.bind(InetSocketAddress(PORT))
                server = ss
                while (running) {
                    val s = ss.accept()
                    pool.execute { serve(s) }
                }
            } catch (e: Exception) {
            }
        }.start()
    }

    private fun serve(s: Socket) {
        try {
            s.soTimeout = 5000
            s.tcpNoDelay = true
            val rd = BufferedReader(InputStreamReader(s.getInputStream()))
            val first = rd.readLine() ?: return
            while (true) {
                val l = rd.readLine() ?: break
                if (l.isEmpty()) break
            }
            val target = first.split(" ").getOrElse(1) { "/" }
            val path = target.substringBefore('?')
            val q = HashMap<String, String>()
            target.substringAfter('?', "").split('&').forEach {
                val kv = it.split('=')
                if (kv.size == 2) q[kv[0]] = kv[1]
            }
            val out = s.getOutputStream()
            val ip = s.inetAddress?.hostAddress ?: "?"
            if (path == "/playback") { html(out, PLAYBACK_HTML); return }
            if (path == "/") { reply(out, "WansCCTV"); return }
            if (blocked(ip)) { reply(out, "terlalu banyak percobaan", "429 Too Many Requests"); return }
            val role = Auth.role(this, q["k"])
            val adminCmd = listOf("wa", "app", "key", "x", "y").any { q.containsKey(it) }
            val need = when (path) {
                "/stream", "/status" -> Auth.LIVE
                "/cmd" -> if (adminCmd) Auth.ADMIN else Auth.FULL
                "/screen" -> Auth.ADMIN
                "/rec/days", "/rec/list", "/rec/play" -> Auth.FULL
                else -> Auth.ADMIN
            }
            if (role < need) {
                if (role == Auth.NONE) failed(ip)
                reply(out, if (role == Auth.NONE) "kunci salah" else "izin tidak cukup", if (role == Auth.NONE) "401 Unauthorized" else "403 Forbidden")
                return
            }
            when (path) {
                "/stream" -> {
                    if (liveViewers.incrementAndGet() > MAX_VIEWERS) {
                        liveViewers.decrementAndGet()
                        reply(out, "penonton penuh (maks $MAX_VIEWERS)", "503 Service Unavailable")
                    } else {
                        try { stream(out) } finally { liveViewers.decrementAndGet() }
                    }
                }
                "/screen" -> screenStream(out)
                "/cmd" -> {
                    applyCmd(q)
                    Thread.sleep(150)
                    reply(out, status())
                }
                "/status" -> reply(out, status())
                "/rec/days" -> reply(out, recorder.days().joinToString("\n"))
                "/rec/list" -> reply(out, recorder.list(q["d"] ?: "").joinToString("\n"))
                "/rec/play" -> {
                    val f = recorder.file(q["f"] ?: "")
                    if (f == null) reply(out, "tidak ada", "404 Not Found")
                    else playFile(out, f, (q["x"]?.toIntOrNull() ?: 1).coerceIn(1, 8))
                }
                else -> reply(out, "WansCCTV")
            }
        } catch (e: Exception) {
        } finally {
            try { s.close() } catch (e: Exception) { }
        }
    }

    @Synchronized private fun blocked(ip: String): Boolean {
        val f = fails[ip] ?: return false
        return SystemClock.elapsedRealtime() - f.second < 60_000L && f.first >= 8
    }

    @Synchronized private fun failed(ip: String) {
        val now = SystemClock.elapsedRealtime()
        val f = fails[ip]
        fails[ip] = if (f == null || now - f.second > 60_000L) 1 to now else (f.first + 1) to f.second
    }

    private fun html(out: OutputStream, body: String) {
        val b = body.toByteArray()
        out.write(("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: ${b.size}\r\nConnection: close\r\n\r\n").toByteArray())
        out.write(b)
        out.flush()
    }

    /** Putar rekaman sebagai aliran gambar; x = kecepatan (1-8 kali). */
    private fun playFile(out: OutputStream, f: java.io.File, speed: Int) {
        out.write(
            ("HTTP/1.1 200 OK\r\nContent-Type: multipart/x-mixed-replace; boundary=frame\r\n" +
                "Cache-Control: no-cache\r\nConnection: close\r\n\r\n").toByteArray()
        )
        java.io.DataInputStream(java.io.BufferedInputStream(java.io.FileInputStream(f), 65536)).use { inp ->
            var prevT = -1L
            while (running) {
                val t = try { inp.readLong() } catch (e: java.io.EOFException) { break }
                val n = inp.readInt()
                if (n <= 0 || n > 2_000_000) break
                val d = ByteArray(n)
                inp.readFully(d)
                if (prevT > 0) Thread.sleep(((t - prevT) / speed).coerceIn(0L, 1500L))
                prevT = t
                out.write("--frame\r\nContent-Type: image/jpeg\r\nContent-Length: $n\r\n\r\n".toByteArray())
                out.write(d)
                out.write("\r\n".toByteArray())
                out.flush()
            }
        }
    }

    /** Notifikasi gerak lewat ntfy.sh (gratis, tanpa akun). Keluarga memasang aplikasi ntfy dan berlangganan topiknya. */
    private fun sendPush() {
        val topic = CamSettings.ntfy(this)
        if (topic.length < 8) return
        pool.execute {
            try {
                val c = java.net.URL("https://ntfy.sh/$topic").openConnection() as java.net.HttpURLConnection
                c.requestMethod = "POST"
                c.doOutput = true
                c.connectTimeout = 5000
                c.readTimeout = 5000
                c.setRequestProperty("Title", "CCTV: gerakan terdeteksi")
                c.outputStream.use { it.write(("Pukul " + Recorder.time(System.currentTimeMillis()).chunked(2).joinToString(":")).toByteArray()) }
                c.responseCode
                c.disconnect()
            } catch (e: Exception) {
            }
        }
    }

    /** Intent untuk membuka aplikasi dengan kode [key], atau null kalau tidak terpasang. */
    private fun appIntent(key: String): Intent? = try {
        if (key == "cam") {
            val i = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
            if (packageManager.resolveActivity(i, 0) != null) i else null
        } else {
            APP_PKGS[key]?.firstNotNullOfOrNull { packageManager.getLaunchIntentForPackage(it) }
        }
    } catch (e: Exception) {
        null
    }

    private fun status(): String =
        "cam=${if (front) "front" else "back"};zoom=$zoom;min=$zMin;max=$zMax;rot=$extraRot" +
            ";flash=${if (hasFlash) 1 else 0}" +
            ";torch=${if (torchWant && hasFlash) 1 else 0}" +
            ";wa=${if (appIntent("wa") != null) 1 else 0}" +
            ";apps=" + APP_KEYS.filter { appIntent(it) != null }.joinToString(",") +
            ";rec=${if (recorder.recording) 1 else 0}" +
            ";motion=${recorder.lastMotionTs}" +
            ";scr=${if (ScreenService.active) 1 else 0}" +
            ";touch=${if (TouchService.enabled) 1 else 0}"

    private fun applyCmd(q: Map<String, String>) {
        q["cam"]?.let {
            val f = it == "front"
            if (f != front) {
                front = f
                zoom = 1f
                main.post { bindCamera() }
            }
        }
        q["zoom"]?.toFloatOrNull()?.let {
            zoom = it.coerceIn(zMin, zMax)
            camera?.cameraControl?.setZoomRatio(zoom)
        }
        q["rot"]?.toIntOrNull()?.let {
            extraRot = ((it % 4) + 4) % 4
        }
        q["torch"]?.let {
            torchWant = it == "on"
            main.post {
                try {
                    if (hasFlash) camera?.cameraControl?.enableTorch(torchWant)
                } catch (e: Exception) {
                }
            }
        }
        if (q["wa"] == "1") openApp("wa")
        q["app"]?.let { openApp(it) }
        q["key"]?.let { TouchService.key(it) }
        val x = q["x"]?.toFloatOrNull()
        val y = q["y"]?.toFloatOrNull()
        if (x != null && y != null) {
            val x2 = q["x2"]?.toFloatOrNull() ?: x
            val y2 = q["y2"]?.toFloatOrNull() ?: y
            val d = q["d"]?.toLongOrNull() ?: 60L
            TouchService.gesture(x, y, x2, y2, d)
        }
    }

    private fun reply(out: OutputStream, body: String, code: String = "200 OK") {
        val b = body.toByteArray()
        out.write(
            ("HTTP/1.1 $code\r\nContent-Type: text/plain; charset=utf-8\r\n" +
                "Content-Length: ${b.size}\r\nConnection: close\r\n\r\n").toByteArray()
        )
        out.write(b)
        out.flush()
    }

    private fun stream(out: OutputStream) {
        out.write(
            ("HTTP/1.1 200 OK\r\nContent-Type: multipart/x-mixed-replace; boundary=frame\r\n" +
                "Cache-Control: no-cache\r\nConnection: close\r\n\r\n").toByteArray()
        )
        var last = -1L
        while (running) {
            val s = seq.get()
            val d = frame.get()
            if (s == last || d == null) {
                Thread.sleep(25)
                continue
            }
            last = s
            out.write("--frame\r\nContent-Type: image/jpeg\r\nContent-Length: ${d.size}\r\n\r\n".toByteArray())
            out.write(d)
            out.write("\r\n".toByteArray())
            out.flush()
        }
    }

    // ---------- Cermin layar ----------

    private fun screenStream(out: OutputStream) {
        if (!ScreenService.active) {
            reply(out, "noscreen")
            return
        }
        out.write(
            ("HTTP/1.1 200 OK\r\nContent-Type: multipart/x-mixed-replace; boundary=frame\r\n" +
                "Cache-Control: no-cache\r\nConnection: close\r\n\r\n").toByteArray()
        )
        if (screenViewers.getAndIncrement() == 0) wakeUp(30 * 60 * 1000L)
        try {
            var last = -1L
            var lastSend = 0L
            var lastHold = SystemClock.elapsedRealtime()
            while (running && ScreenService.active) {
                val now = SystemClock.elapsedRealtime()
                val s = ScreenService.seq.get()
                val d = ScreenService.frame.get()
                // Layar yang diam tidak menghasilkan frame baru, jadi kirim ulang tiap 1 detik
                if (d != null && (s != last || now - lastSend > 1000)) {
                    last = s
                    lastSend = now
                    out.write("--frame\r\nContent-Type: image/jpeg\r\nContent-Length: ${d.size}\r\n\r\n".toByteArray())
                    out.write(d)
                    out.write("\r\n".toByteArray())
                    out.flush()
                } else {
                    Thread.sleep(30)
                }
                if (now - lastHold > 10 * 60 * 1000L) {
                    lastHold = now
                    holdScreen(30 * 60 * 1000L)
                }
            }
        } finally {
            if (screenViewers.decrementAndGet() <= 0) {
                screenViewers.set(0)
                releaseScreen()
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun holdScreen(ms: Long) {
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            val w = screenWake ?: pm.newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE,
                "wanscctv:screen"
            ).also {
                it.setReferenceCounted(false)
                screenWake = it
            }
            w.acquire(ms)
        } catch (e: Exception) {
        }
    }

    private fun releaseScreen() {
        try {
            if (screenWake?.isHeld == true) screenWake?.release()
        } catch (e: Exception) {
        }
    }

    // Nyalakan layar HP kamera dan buka kunci layar (hanya jika kuncinya geser, bukan PIN/pola)
    private fun wakeUp(ms: Long) {
        var needDismiss = false
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
            needDismiss = !pm.isInteractive || km.isKeyguardLocked
        } catch (e: Exception) {
        }
        holdScreen(ms)
        if (needDismiss) {
            main.post {
                try {
                    startActivity(Intent(this, WakeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {
                }
            }
        }
    }

    private fun openApp(key: String) {
        val i = appIntent(key) ?: return
        wakeUp(20_000L)
        main.postDelayed({
            try {
                startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
            }
        }, 700)
    }

    // ---------- Suara dari monitor ----------

    private fun startTalkServer() {
        Thread {
            try {
                val ss = ServerSocket()
                ss.reuseAddress = true
                ss.bind(InetSocketAddress(TALK_PORT))
                talkServer = ss
                while (running) {
                    val s = ss.accept()
                    pool.execute { playTalk(s) }
                }
            } catch (e: Exception) {
            }
        }.start()
    }

    private fun boostVolume() {
        synchronized(volLock) {
            if (talkers++ == 0) {
                try {
                    val am = getSystemService(AUDIO_SERVICE) as AudioManager
                    savedVol = am.getStreamVolume(AudioManager.STREAM_MUSIC)
                    val target = (am.getStreamMaxVolume(AudioManager.STREAM_MUSIC) * TALK_VOLUME)
                        .roundToInt()
                        .coerceAtLeast(1)
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
                } catch (e: Exception) {
                }
            }
        }
    }

    private fun restoreVolume() {
        synchronized(volLock) {
            if (--talkers <= 0) {
                talkers = 0
                if (savedVol >= 0) {
                    try {
                        val am = getSystemService(AUDIO_SERVICE) as AudioManager
                        am.setStreamVolume(AudioManager.STREAM_MUSIC, savedVol, 0)
                    } catch (e: Exception) {
                    }
                    savedVol = -1
                }
            }
        }
    }

    private fun playTalk(s: Socket) {
        var track: AudioTrack? = null
        var boosted = false
        try {
            s.soTimeout = 8000
            s.tcpNoDelay = true
            // Baris pertama = kunci admin, sebelum data suara
            val inp0 = s.getInputStream()
            val sb = StringBuilder()
            while (true) {
                val ch = inp0.read()
                if (ch < 0 || ch == '\n'.code || sb.length > 64) break
                sb.append(ch.toChar())
            }
            if (Auth.role(this, sb.toString()) < Auth.ADMIN) return
            val rate = 16000
            val minBuf = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val t = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(rate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minBuf * 2, 8192))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            track = t
            boostVolume()
            boosted = true
            t.play()
            val inp = s.getInputStream()
            val buf = ByteArray(4096)
            var have = 0
            while (running) {
                val n = inp.read(buf, have, buf.size - have)
                if (n < 0) break
                have += n
                val even = have and 1.inv()
                if (even > 0) {
                    t.write(buf, 0, even)
                    if (have > even) buf[0] = buf[even]
                    have -= even
                }
            }
        } catch (e: Exception) {
        } finally {
            try { track?.stop() } catch (e: Exception) { }
            try { track?.release() } catch (e: Exception) { }
            if (boosted) restoreVolume()
            try { s.close() } catch (e: Exception) { }
        }
    }
}
