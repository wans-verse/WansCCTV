package com.wans.cctv.camera

import android.content.Context
import android.graphics.Bitmap
import android.os.Environment
import java.io.BufferedOutputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale
import kotlin.math.abs

/**
 * Perekam: deteksi gerak, simpan frame JPEG ke file per segmen, dan hapus yang lama (loop).
 * Format file .mjpg: berulang [waktu ms: Long][panjang: Int][data JPEG].
 * Dipanggil hanya dari satu thread (analyzer), kecuali fungsi baca (days/list/file).
 */
class Recorder(private val ctx: Context, private val onMotion: () -> Unit) {

    companion object {
        const val OFF = 0
        const val MOTION = 1
        const val ALL = 2
        private const val POST_MS = 8_000L      // lanjut rekam setelah gerak terakhir
        private const val PRE_MS = 3_000L       // simpan sebelum gerak
        private const val SEG_MS = 300_000L     // 1 file maksimal 5 menit
        private const val NOTIFY_GAP = 60_000L
        private val NAME = Regex("^\\d{8}/\\d{6}\\.mjpg$")
        fun day(ms: Long): String = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(ms))
        fun time(ms: Long): String = SimpleDateFormat("HHmmss", Locale.US).format(Date(ms))
    }

    @Volatile var lastMotionTs = 0L
    @Volatile var recording = false
    private var prev: IntArray? = null
    private val pre = ArrayDeque<Pair<Long, ByteArray>>()
    private var out: DataOutputStream? = null
    private var cur: File? = null
    private var segStart = 0L
    private var lastMotion = 0L
    private var lastNotify = 0L
    @Volatile private var sd = false

    fun root(): File {
        val dirs = ctx.getExternalFilesDirs(null).filterNotNull()
        val card = dirs.firstOrNull { try { Environment.isExternalStorageRemovable(it) } catch (e: Exception) { false } }
        sd = card != null
        return File(card ?: dirs.firstOrNull() ?: ctx.filesDir, "rekaman").also { it.mkdirs() }
    }

    fun usingSd(): Boolean { root(); return sd }

    private fun moving(b: Bitmap, sens: Int): Boolean {
        val s = Bitmap.createScaledBitmap(b, 40, 30, true)
        val px = IntArray(1200)
        s.getPixels(px, 0, 40, 0, 0, 40, 30)
        if (s !== b) s.recycle()
        val g = IntArray(1200) { val c = px[it]; ((c shr 16 and 255) * 3 + (c shr 8 and 255) * 6 + (c and 255)) / 10 }
        val p = prev
        prev = g
        if (p == null) return false
        val pct = when (sens) { 0 -> 8; 2 -> 2; else -> 4 }
        var n = 0
        for (i in g.indices) if (abs(g[i] - p[i]) > 25) n++
        return n * 100 > 1200 * pct
    }

    fun onFrame(bmp: Bitmap, jpeg: ByteArray, now: Long, mode: Int, sens: Int, days: Int) {
        if (mode == OFF) { close(days); return }
        val mo = moving(bmp, sens)
        if (mo) {
            lastMotion = now
            lastMotionTs = now
            if (now - lastNotify > NOTIFY_GAP) { lastNotify = now; onMotion() }
        }
        val want = mode == ALL || now - lastMotion < POST_MS
        if (want) {
            try {
                if (out == null) open(now)
                for ((t, d) in pre) write(t, d)
                pre.clear()
                write(now, jpeg)
                if (now - segStart > SEG_MS) close(days)
            } catch (e: Exception) {
                close(days)
            }
        } else {
            close(days)
            pre.addLast(now to jpeg)
            while (pre.isNotEmpty() && now - pre.first.first > PRE_MS) pre.removeFirst()
        }
    }

    private fun open(now: Long) {
        val d = File(root(), day(now)).also { it.mkdirs() }
        val f = File(d, time(now) + ".mjpg")
        out = DataOutputStream(BufferedOutputStream(FileOutputStream(f), 32768))
        cur = f
        segStart = now
        recording = true
    }

    private fun write(t: Long, d: ByteArray) {
        val o = out ?: return
        o.writeLong(t)
        o.writeInt(d.size)
        o.write(d)
    }

    fun close(days: Int) {
        val o = out ?: return
        try { o.flush(); o.close() } catch (e: Exception) { }
        out = null
        cur = null
        recording = false
        try { cleanup(days) } catch (e: Exception) { }
    }

    /** Loop: hapus file lebih tua dari [days] hari, lalu hapus yang tertua kalau kartu hampir penuh. */
    fun cleanup(days: Int) {
        val r = root()
        val now = System.currentTimeMillis()
        val files = r.walkTopDown().filter { it.isFile && it.name.endsWith(".mjpg") && it != cur }
            .sortedBy { it.lastModified() }.toMutableList()
        val it = files.iterator()
        while (it.hasNext()) {
            val f = it.next()
            if (now - f.lastModified() > days * 86_400_000L) { f.delete(); it.remove() }
        }
        // Batas pemakaian: kartu SD 85% dari kapasitas; memori internal hanya 4 GB
        val cap = if (sd) (r.totalSpace * 0.85).toLong() else 4L shl 30
        var total = files.sumOf { it.length() }
        while (files.isNotEmpty() && (total > cap || r.usableSpace < (300L shl 20))) {
            val f = files.removeAt(0)
            total -= f.length()
            f.delete()
        }
        r.listFiles()?.filter { it.isDirectory && it.list().isNullOrEmpty() }?.forEach { it.delete() }
    }

    // ---------- Untuk playback ----------

    fun days(): List<String> =
        (root().listFiles()?.filter { it.isDirectory }?.map { it.name } ?: emptyList()).sortedDescending()

    /** Baris: "HHmmss;lamaDetik;ukuranKB" */
    fun list(d: String): List<String> {
        if (!Regex("^\\d{8}$").matches(d)) return emptyList()
        val fs = File(root(), d).listFiles()?.filter { it.name.endsWith(".mjpg") }?.sortedBy { it.name } ?: return emptyList()
        return fs.map {
            val hh = it.name.substring(0, 2).toInt(); val mm = it.name.substring(2, 4).toInt(); val ss = it.name.substring(4, 6).toInt()
            val start = hh * 3600 + mm * 60 + ss
            val c = java.util.Calendar.getInstance().apply { timeInMillis = it.lastModified() }
            val end = c.get(java.util.Calendar.HOUR_OF_DAY) * 3600 + c.get(java.util.Calendar.MINUTE) * 60 + c.get(java.util.Calendar.SECOND)
            "${it.name.substringBefore('.')};${maxOf(0, end - start)};${it.length() / 1024}"
        }
    }

    fun file(rel: String): File? {
        if (!NAME.matches(rel)) return null
        val f = File(root(), rel)
        return if (f.isFile) f else null
    }

    fun storageInfo(): String {
        val r = root()
        val used = r.walkTopDown().filter { it.isFile }.sumOf { it.length() } shr 20
        return (if (sd) "Kartu SD" else "Memori internal (SD tidak terdeteksi)") + " • terpakai $used MB"
    }
}
