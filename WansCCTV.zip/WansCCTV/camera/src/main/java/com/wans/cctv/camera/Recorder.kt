package com.wans.cctv.camera

import android.content.Context
import android.graphics.Bitmap
import android.os.Environment
import java.io.BufferedOutputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Perekam: deteksi gerak, simpan frame JPEG ke file per segmen, dan hapus yang lama (loop).
 * Format file .mjpg: berulang [waktu ms: Long][panjang: Int][data JPEG].
 * Dipanggil hanya dari satu thread (analyzer), kecuali fungsi baca (days/list/file).
 */
class Recorder(private val ctx: Context, private val onMotion: () -> Unit) {

    companion object {
        const val OFF = 0
        const val MOTION = 1
        /** Sisa ruang di bawah ini (MB): rekaman tertua dihapus dan monitor diberi peringatan. */
        const val LOW_MB = 500L
        const val ALL = 2
        private const val POST_MS = 8_000L      // lanjut rekam setelah gerak terakhir
        private const val PRE_MS = 3_000L       // simpan sebelum gerak
        private const val SEG_MS = 300_000L     // 1 file maksimal 5 menit
        private const val NOTIFY_GAP = 60_000L
        private const val GW = 80               // lebar kisi analisis gerak
        private const val GH = 60               // tinggi kisi analisis gerak
        private const val MIN_CELLS = 6         // gerombolan lebih kecil dari ini dianggap noise
        private const val MAX_BOXES = 6
        private val NAME = Regex("^\\d{8}/\\d{6}\\.mjpg$")
        fun day(ms: Long): String = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(ms))
        fun time(ms: Long): String = SimpleDateFormat("HHmmss", Locale.US).format(Date(ms))
    }

    @Volatile var lastMotionTs = 0L
    /** Kotak area gerak frame terakhir: [kiri, atas, kanan, bawah] dalam 0..1. Hanya untuk tampilan live. */
    var boxes: List<FloatArray> = emptyList()
        private set
    @Volatile var recording = false
    private var prev: IntArray? = null
    private val pre = ArrayDeque<Pair<Long, ByteArray>>()
    private var out: DataOutputStream? = null
    @Volatile private var cur: File? = null
    private var segStart = 0L
    private var lastMotion = 0L
    private var lastNotify = 0L
    private var lastSpaceCheck = 0L
    @Volatile private var sd = false

    fun root(): File {
        val dirs = ctx.getExternalFilesDirs(null).filterNotNull()
        val card = dirs.firstOrNull { try { Environment.isExternalStorageRemovable(it) } catch (e: Exception) { false } }
        sd = card != null
        return File(card ?: dirs.firstOrNull() ?: ctx.filesDir, "rekaman").also { it.mkdirs() }
    }

    fun usingSd(): Boolean { root(); return sd }

    private fun moving(b: Bitmap, sens: Int, wantBoxes: Boolean): Boolean {
        val s = Bitmap.createScaledBitmap(b, GW, GH, true)
        val px = IntArray(GW * GH)
        s.getPixels(px, 0, GW, 0, 0, GW, GH)
        if (s !== b) s.recycle()
        val g = IntArray(GW * GH) { val c = px[it]; ((c shr 16 and 255) * 3 + (c shr 8 and 255) * 6 + (c and 255)) / 10 }
        val p = prev
        prev = g
        boxes = emptyList()
        if (p == null) return false
        val pct = when (sens) { 0 -> 8; 2 -> 2; else -> 4 }
        val ch = BooleanArray(GW * GH)
        var n = 0
        for (i in g.indices) if (abs(g[i] - p[i]) > 25) { ch[i] = true; n++ }
        val mo = n * 100 > GW * GH * pct
        if (mo && wantBoxes) boxes = findBoxes(ch)
        return mo
    }

    /** Kelompokkan piksel yang berubah menjadi beberapa area, satu kotak per area. */
    private fun findBoxes(ch: BooleanArray): List<FloatArray> {
        // Gabungkan piksel berdekatan (jarak 2) supaya satu orang tidak pecah jadi banyak kotak
        val d = BooleanArray(GW * GH)
        for (y in 0 until GH) for (x in 0 until GW) {
            if (!ch[y * GW + x]) continue
            for (yy in max(0, y - 2)..min(GH - 1, y + 2)) for (xx in max(0, x - 2)..min(GW - 1, x + 2)) d[yy * GW + xx] = true
        }
        val seen = BooleanArray(GW * GH)
        val stack = IntArray(GW * GH)
        val found = ArrayList<IntArray>()
        for (start in d.indices) {
            if (!d[start] || seen[start]) continue
            var sp = 0
            stack[sp++] = start
            seen[start] = true
            var x0 = GW; var y0 = GH; var x1 = -1; var y1 = -1; var cnt = 0
            while (sp > 0) {
                val i = stack[--sp]
                val x = i % GW
                val y = i / GW
                if (ch[i]) {
                    cnt++
                    x0 = min(x0, x); y0 = min(y0, y); x1 = max(x1, x); y1 = max(y1, y)
                }
                for (dy in -1..1) for (dx in -1..1) {
                    val nx = x + dx
                    val ny = y + dy
                    if (nx < 0 || ny < 0 || nx >= GW || ny >= GH) continue
                    val j = ny * GW + nx
                    if (d[j] && !seen[j]) { seen[j] = true; stack[sp++] = j }
                }
            }
            if (cnt >= MIN_CELLS) found.add(intArrayOf(x0, y0, x1, y1, cnt))
        }
        found.sortByDescending { it[4] }
        return found.take(MAX_BOXES).map {
            floatArrayOf(it[0] / GW.toFloat(), it[1] / GH.toFloat(), (it[2] + 1) / GW.toFloat(), (it[3] + 1) / GH.toFloat())
        }
    }

    fun onFrame(bmp: Bitmap, jpeg: ByteArray, now: Long, mode: Int, sens: Int, days: Int, detect: Boolean = true, boxOn: Boolean = false) {
        val analyse = (detect && mode != OFF) || boxOn
        val mo = if (analyse) moving(bmp, sens, boxOn) else { prev = null; boxes = emptyList(); false }
        if (mode == OFF) { close(days); return }
        if (mo && detect) {
            lastMotion = now
            lastMotionTs = now
            if (now - lastNotify > NOTIFY_GAP) { lastNotify = now; onMotion() }
        }
        val want = mode == ALL || now - lastMotion < POST_MS
        if (want) {
            try {
                if (out == null) open(now)
                for ((t, d) in pre) write(t, d)
                pre.clear()
                write(now, jpeg)
                // Jangan menunggu segmen selesai: cek ruang tiap 30 detik supaya rekaman tidak berhenti karena penuh.
                if (now - lastSpaceCheck > 30_000L) {
                    lastSpaceCheck = now
                    cleanup(days)
                }
                if (now - segStart > SEG_MS) close(days)
            } catch (e: Exception) {
                close(days)
            }
        } else {
            close(days)
            pre.addLast(now to jpeg)
            while (pre.isNotEmpty() && now - pre.first.first > PRE_MS) pre.removeFirst()
        }
    }

    private fun open(now: Long) {
        val d = File(root(), day(now)).also { it.mkdirs() }
        val f = File(d, time(now) + ".mjpg")
        out = DataOutputStream(BufferedOutputStream(FileOutputStream(f), 32768))
        cur = f
        segStart = now
        recording = true
    }

    private fun write(t: Long, d: ByteArray) {
        val o = out ?: return
        o.writeLong(t)
        o.writeInt(d.size)
        o.write(d)
    }

    fun close(days: Int) {
        val o = out ?: return
        try { o.flush(); o.close() } catch (e: Exception) { }
        out = null
        cur = null
        recording = false
        try { cleanup(days) } catch (e: Exception) { }
    }

    /** Loop: hapus file lebih tua dari [days] hari, lalu hapus yang tertua kalau kartu hampir penuh. */
    fun cleanup(days: Int) {
        val r = root()
        val now = System.currentTimeMillis()
        val files = r.walkTopDown().filter { it.isFile && it.name.endsWith(".mjpg") && it != cur }
            .sortedBy { it.lastModified() }.toMutableList()
        val it = files.iterator()
        while (it.hasNext()) {
            val f = it.next()
            if (now - f.lastModified() > days * 86_400_000L) { f.delete(); it.remove() }
        }
        // Batas pemakaian: kartu SD 85% dari kapasitas; memori internal hanya 4 GB
        val cap = if (sd) (r.totalSpace * 0.85).toLong() else 4L shl 30
        var total = files.sumOf { it.length() }
        while (files.isNotEmpty() && (total > cap || r.usableSpace < (LOW_MB shl 20))) {
            val f = files.removeAt(0)
            total -= f.length()
            f.delete()
        }
        r.listFiles()?.filter { it.isDirectory && it.list().isNullOrEmpty() }?.forEach { it.delete() }
    }

    // ---------- Untuk playback ----------

    fun days(): List<String> =
        (root().listFiles()?.filter { it.isDirectory }?.map { it.name } ?: emptyList()).sortedDescending()

    /** Baris: "HHmmss;lamaDetik;ukuranKB" */
    fun list(d: String): List<String> {
        if (!Regex("^\\d{8}$").matches(d)) return emptyList()
        val fs = File(root(), d).listFiles()?.filter { it.name.endsWith(".mjpg") }?.sortedBy { it.name } ?: return emptyList()
        return fs.map {
            val hh = it.name.substring(0, 2).toInt(); val mm = it.name.substring(2, 4).toInt(); val ss = it.name.substring(4, 6).toInt()
            val start = hh * 3600 + mm * 60 + ss
            val c = java.util.Calendar.getInstance().apply { timeInMillis = it.lastModified() }
            val end = c.get(java.util.Calendar.HOUR_OF_DAY) * 3600 + c.get(java.util.Calendar.MINUTE) * 60 + c.get(java.util.Calendar.SECOND)
            "${it.name.substringBefore('.')};${maxOf(0, end - start)};${it.length() / 1024}"
        }
    }

    fun file(rel: String): File? {
        if (!NAME.matches(rel)) return null
        val f = File(root(), rel)
        return if (f.isFile) f else null
    }

    /** True kalau [f] adalah rekaman yang sedang ditulis (belum boleh diunduh). */
    fun isActive(f: File): Boolean = f == cur

    /** Hapus satu rekaman (kecuali yang sedang ditulis). */
    fun delete(rel: String): Boolean {
        if (!NAME.matches(rel)) return false
        val f = File(root(), rel)
        if (!f.isFile || f == cur) return false
        val ok = f.delete()
        f.parentFile?.let { if (it.list().isNullOrEmpty()) it.delete() }
        return ok
    }

    /** Hapus semua rekaman satu hari (kecuali yang sedang ditulis). Mengembalikan jumlah file terhapus. */
    fun deleteDay(d: String): Int {
        if (!Regex("^\\d{8}$").matches(d)) return 0
        val dir = File(root(), d)
        var n = 0
        dir.listFiles()?.filter { it.name.endsWith(".mjpg") && it != cur }?.forEach { if (it.delete()) n++ }
        if (dir.list().isNullOrEmpty()) dir.delete()
        return n
    }

    /** Sisa ruang kosong di penyimpanan rekaman (MB). */
    fun freeMb(): Long = root().usableSpace shr 20

    fun isLow(): Boolean = freeMb() < LOW_MB

    fun usedMb(): Long = root().walkTopDown().filter { it.isFile }.sumOf { it.length() } shr 20

    fun storageInfo(): String {
        val r = root()
        val used = r.walkTopDown().filter { it.isFile }.sumOf { it.length() } shr 20
        return (if (sd) "Kartu SD" else "Memori internal (SD tidak terdeteksi)") + " • terpakai $used MB • sisa ${freeMb()} MB"
    }
}
