package com.wans.cctv.camera

import android.app.Activity
import android.app.KeyguardManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager

/**
 * Activity transparan yang hanya menyalakan layar dan membuka kunci layar tipe "geser".
 * Kalau HP memakai PIN/pola, layar tetap menyala tapi kuncinya tidak bisa dibuka dari jauh.
 */
class WakeActivity : Activity() {

    private val h = Handler(Looper.getMainLooper())

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
        if (!km.isKeyguardLocked || km.isKeyguardSecure) {
            finish()
            return
        }
        h.postDelayed({ finish() }, 6000)
        try {
            km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
                override fun onDismissSucceeded() {
                    finish()
                }

                override fun onDismissError() {
                    finish()
                }

                override fun onDismissCancelled() {
                    finish()
                }
            })
        } catch (e: Exception) {
            finish()
        }
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
