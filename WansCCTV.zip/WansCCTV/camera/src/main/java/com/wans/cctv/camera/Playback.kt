package com.wans.cctv.camera

/** Halaman playback sederhana (dibuka dari browser HP mana pun): http://ALAMAT:8080/playback?k=KUNCI */
const val PLAYBACK_HTML = """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Rekaman</title>
<style>body{margin:0;background:#000;color:#fff;font:15px sans-serif;padding:12px}
select,button{font-size:16px;padding:8px;margin:4px 2px;border-radius:8px;border:0;background:#2c2c2e;color:#fff}
img{width:100%;background:#111;border-radius:8px;margin-top:8px}#i{color:#8e8e93;font-size:13px}</style></head><body>
<b>Riwayat rekaman</b><br>
<select id="d"></select> <select id="x"><option value="1">1x</option><option value="4">4x</option><option value="8">8x</option></select><br>
<select id="f" style="max-width:100%"></select> <button id="p">Putar</button>
<div id="i"></div><img id="v">
<script>
var K=new URLSearchParams(location.search).get('k')||'';
function g(u){return fetch(u+(u.indexOf('?')<0?'?':'&')+'k='+K).then(function(r){if(!r.ok)throw r.status;return r.text()})}
var d=document.getElementById('d'),f=document.getElementById('f'),i=document.getElementById('i');
function lt(s){return s.substr(0,2)+':'+s.substr(2,2)+':'+s.substr(4,2)}
function ld(){g('/rec/list?d='+d.value).then(function(t){f.innerHTML='';
 t.split('\n').filter(Boolean).forEach(function(l){var a=l.split(';'),o=document.createElement('option');
 o.value=d.value+'/'+a[0]+'.mjpg';o.textContent='Jam '+lt(a[0])+' ('+a[1]+' dtk, '+a[2]+' KB)';f.appendChild(o)});
 i.textContent=f.options.length?'':'Tidak ada rekaman di tanggal ini'})}
g('/rec/days').then(function(t){t.split('\n').filter(Boolean).forEach(function(x){var o=document.createElement('option');
 o.value=x;o.textContent=x.substr(6,2)+'-'+x.substr(4,2)+'-'+x.substr(0,4);d.appendChild(o)});ld()})
 .catch(function(){i.textContent='Kunci salah atau tidak punya izin rekaman'});
d.onchange=ld;
document.getElementById('p').onclick=function(){if(f.value)document.getElementById('v').src='/rec/play?f='+f.value+'&x='+document.getElementById('x').value+'&k='+K};
</script></body></html>"""
