package com.wans.cctv.camera

import java.io.File
import java.io.RandomAccessFile

/** Daftar frame sebuah rekaman. Baris: "offsetMs;posisi;ukuran" (offset dari frame pertama). */
fun recIndex(f: File): String {
    val sb = StringBuilder()
    try {
        RandomAccessFile(f, "r").use { r ->
            val len = r.length()
            var pos = 0L
            var t0 = -1L
            while (pos + 12 <= len) {
                r.seek(pos)
                val t = r.readLong()
                val n = r.readInt()
                if (n <= 0 || n > 2_000_000 || pos + 12 + n > len) break
                if (t0 < 0) t0 = t
                sb.append(t - t0).append(';').append(pos + 12).append(';').append(n).append('\n')
                pos += 12L + n
            }
        }
    } catch (e: Exception) {
    }
    return sb.toString()
}

/** Ambil satu frame JPEG dari file rekaman. */
fun recFrame(f: File, pos: Long, n: Int): ByteArray? = try {
    if (pos < 12 || n <= 0 || n > 2_000_000 || pos + n > f.length()) null
    else RandomAccessFile(f, "r").use { r ->
        r.seek(pos)
        val d = ByteArray(n)
        r.readFully(d)
        d
    }
} catch (e: Exception) {
    null
}

/** Halaman playback (dibuka dari browser HP mana pun): http://ALAMAT:8080/playback?k=KUNCI */
const val PLAYBACK_HTML = """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title>Rekaman</title>
<style>
:root{color-scheme:dark;--bg:#000;--card:#1c1c1e;--fill:rgba(120,120,128,.36);--lbl2:#8e8e93;--blue:#0a84ff;--glass:rgba(40,40,44,.62)}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none}
html,body{margin:0;background:var(--bg);color:#fff;font:15px -apple-system,BlinkMacSystemFont,"SF Pro Text","Helvetica Neue",Roboto,sans-serif}
.wrap{max-width:900px;margin:0 auto;padding:max(12px,env(safe-area-inset-top)) 14px max(16px,env(safe-area-inset-bottom))}
h1{font-size:28px;font-weight:700;letter-spacing:-.4px;margin:6px 2px 12px}
.sel{display:flex;gap:8px;margin-bottom:12px}
select{flex:1;min-width:0;appearance:none;-webkit-appearance:none;background:var(--card);color:#fff;border:0;border-radius:12px;padding:12px 14px;font-size:16px;font-family:inherit}
#pl{position:relative;background:#000;border-radius:16px;overflow:hidden;aspect-ratio:16/9;width:100%}
#pl.fs{position:fixed;inset:0;z-index:99;border-radius:0;aspect-ratio:auto;height:100%}
#v{width:100%;height:100%;object-fit:contain;display:block;background:#111}
#ctl{position:absolute;left:0;right:0;bottom:0;padding:34px 14px 12px;background:linear-gradient(transparent,rgba(0,0,0,.72));transition:opacity .25s}
#pl.hide #ctl,#pl.hide #top{opacity:0;pointer-events:none}
#top{position:absolute;top:10px;left:12px;right:12px;display:flex;justify-content:space-between;transition:opacity .25s;pointer-events:none}
.chip{background:var(--glass);-webkit-backdrop-filter:blur(20px);backdrop-filter:blur(20px);border-radius:999px;padding:5px 11px;font-size:13px;font-weight:600;font-variant-numeric:tabular-nums}
#mid{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;gap:34px;transition:opacity .25s}
#pl.hide #mid{opacity:0;pointer-events:none}
.b{width:46px;height:46px;border-radius:50%;border:0;background:var(--glass);-webkit-backdrop-filter:blur(20px);backdrop-filter:blur(20px);color:#fff;display:flex;align-items:center;justify-content:center;padding:0;font:600 12px inherit}
.b svg{width:22px;height:22px;fill:#fff}
.b.big{width:64px;height:64px}.b.big svg{width:30px;height:30px}
.b:active{transform:scale(.92);background:rgba(90,90,96,.8)}
#bar{position:relative;height:28px;display:flex;align-items:center;touch-action:none}
#trk{position:relative;width:100%;height:4px;border-radius:2px;background:rgba(255,255,255,.3);transition:height .12s}
#bar.drag #trk{height:8px}
#buf{position:absolute;left:0;top:0;bottom:0;border-radius:2px;background:rgba(255,255,255,.35)}
#fill{position:absolute;left:0;top:0;bottom:0;width:0;border-radius:2px;background:#fff}
#knob{position:absolute;top:50%;left:0;width:14px;height:14px;margin:-7px 0 0 -7px;border-radius:50%;background:#fff;box-shadow:0 1px 4px rgba(0,0,0,.5);transition:transform .12s}
#bar.drag #knob{transform:scale(1.5)}
#tip{position:absolute;bottom:34px;transform:translateX(-50%);display:none}
#bar.drag #tip{display:block}
.row{display:flex;align-items:center;justify-content:space-between;margin-top:2px}
.row .l{font-size:13px;font-variant-numeric:tabular-nums;color:#ebebf5}
.sp{display:flex;gap:6px}
.pill{border:0;border-radius:999px;padding:6px 11px;background:var(--glass);-webkit-backdrop-filter:blur(20px);backdrop-filter:blur(20px);color:#fff;font:600 13px inherit}
.pill.on{background:#fff;color:#000}
#msg{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:var(--lbl2);text-align:center;padding:20px;pointer-events:none}
#fl,#fr{position:absolute;top:0;bottom:0;width:34%;display:flex;align-items:center;justify-content:center;font-weight:700;opacity:0;transition:opacity .2s;pointer-events:none}
#fl{left:0;background:radial-gradient(circle at 0 50%,rgba(255,255,255,.25),transparent 70%)}
#fr{right:0;background:radial-gradient(circle at 100% 50%,rgba(255,255,255,.25),transparent 70%)}
.list{margin-top:14px;background:var(--card);border-radius:14px;overflow:hidden}
.it{display:flex;justify-content:space-between;align-items:center;padding:13px 16px;border-bottom:.5px solid rgba(84,84,88,.6)}
.it:last-child{border:0}.it:active{background:#2c2c2e}
.it.on{color:var(--blue);font-weight:600}.it small{color:var(--lbl2);font-weight:400}
#i{color:var(--lbl2);font-size:13px;margin:10px 4px}
#tb{display:none;gap:8px;margin-top:12px;flex-wrap:wrap}
.p2{border:0;border-radius:10px;padding:9px 14px;background:var(--fill);color:#fff;font:600 14px inherit}
.p2.red{background:rgba(255,69,58,.16);color:#ff453a}
.p2:disabled{opacity:.4}
.lf{display:flex;align-items:center;gap:12px}.rt{display:flex;align-items:center;gap:10px}
.ck{display:none;width:20px;height:20px;border-radius:50%;border:1.5px solid #636366}
.sm .ck{display:block}.it.sel .ck{background:var(--blue);border-color:var(--blue);box-shadow:inset 0 0 0 3px #1c1c1e}
.tr{display:none;border:0;background:none;padding:4px;margin:-4px}
.ad .tr{display:block}.sm .tr{display:none}
.tr svg{width:20px;height:20px;fill:none;stroke:#ff453a;stroke-width:1.5;stroke-linecap:round;stroke-linejoin:round;opacity:.85}
#ov,#ov2{position:fixed;inset:0;background:rgba(0,0,0,.55);display:none;align-items:center;justify-content:center;z-index:200;padding:24px}
.dlg{background:#2c2c2e;border-radius:18px;padding:20px;max-width:320px;width:100%}
#dm{font-size:16px;line-height:1.4;margin-bottom:16px}
.dr{display:flex;gap:8px;justify-content:flex-end}
.dl{display:block;border:0;background:none;padding:4px;margin:-4px}
.sm .dl{display:none}
.dl svg{width:20px;height:20px;fill:none;stroke:var(--blue);stroke-width:1.5;stroke-linecap:round;stroke-linejoin:round}
#dt{font-size:16px;font-weight:600;margin-bottom:8px}
.hint{font-size:13px;line-height:1.4;color:var(--lbl2);margin-bottom:10px}
.col{display:flex;flex-direction:column;gap:8px;margin-bottom:12px}
.col .p2{width:100%;padding:12px}
.pg{display:none;height:6px;border-radius:3px;background:var(--fill);margin:4px 0 10px;overflow:hidden}
#pgf{height:100%;width:0;background:var(--blue);transition:width .3s}
</style></head><body><div class="wrap">
<h1>Rekaman</h1>
<div class="sel"><select id="d"></select></div>
<div id="pl" class="hide">
 <img id="v" alt="">
 <div id="msg">Pilih rekaman di bawah</div>
 <div id="fl">« 10 dtk</div><div id="fr">10 dtk »</div>
 <div id="top"><span class="chip" id="clk">--:--:--</span><span class="chip" id="st"></span></div>
 <div id="mid">
  <button class="b" id="bk"><svg viewBox="0 0 24 24"><path d="M12 5V2L7 6l5 4V7a5 5 0 1 1-5 5H5a7 7 0 1 0 7-7z"/></svg></button>
  <button class="b big" id="pp"></button>
  <button class="b" id="fw"><svg viewBox="0 0 24 24"><path d="M12 5V2l5 4-5 4V7a5 5 0 1 0 5 5h2a7 7 0 1 1-7-7z"/></svg></button>
 </div>
 <div id="ctl">
  <div id="bar"><div id="trk"><div id="buf"></div><div id="fill"></div><div id="knob"></div></div><span class="chip" id="tip">0:00</span></div>
  <div class="row"><span class="l" id="tm">0:00 / 0:00</span>
   <div class="sp" id="sp"></div>
   <button class="pill" id="fsb">⤢</button></div>
 </div>
</div>
<div id="i"></div>
<div id="tb"><button class="p2" id="bs">Pilih</button><button class="p2" id="ba">Pilih semua</button><button class="p2 red" id="bd">Hapus hari ini</button></div>
<div class="list" id="f"></div>
<div id="ov2"><div class="dlg"><div id="dt"></div>
<div class="hint">.mjpg adalah format asli kamera dan tidak bisa diputar di galeri biasa; buka dengan VLC. MP4 bisa diputar di mana saja, tetapi HP kamera perlu waktu dan baterai untuk mengonversinya.</div>
<div class="pg" id="pg"><div id="pgf"></div></div>
<div class="hint" id="ds"></div>
<div class="col"><button class="p2" id="d1">Unduh asli (.mjpg)</button><button class="p2" id="d2">Unduh MP4</button></div>
<div class="dr"><button class="p2" id="dc">Tutup</button></div></div></div>
<div id="ov"><div class="dlg"><div id="dm"></div><div class="dr"><button class="p2" id="dn">Batal</button><button class="p2 red" id="dy">Hapus</button></div></div></div>
</div>
<script>
var K=new URLSearchParams(location.search).get('k')||'';
function $(x){return document.getElementById(x)}
function q(u){return u+(u.indexOf('?')<0?'?':'&')+'k='+K}
function g(u){return fetch(q(u)).then(function(r){if(!r.ok)throw r.status;return r.text()})}
var pl=$('pl'),v=$('v'),d=$('d'),fl=$('f'),inf=$('i'),pp=$('pp');
var PLAY='<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>',PAUSE='<svg viewBox="0 0 24 24"><path d="M6 5h4v14H6zm8 0h4v14h-4z"/></svg>';
var fr=[],dur=0,ct=0,playing=false,spd=1,last=0,cur='',shown=-1,loading=false,startSec=0,hideT=0,drag=false,names=[];
function lt(s){return s.substr(0,2)+':'+s.substr(2,2)+':'+s.substr(4,2)}
function mmss(ms){var s=Math.max(0,Math.floor(ms/1000)),h=Math.floor(s/3600),m=Math.floor(s%3600/60),c=s%60;
 return (h?h+':'+(m<10?'0':''):'')+m+':'+(c<10?'0':'')+c}
function clock(ms){var s=startSec+Math.floor(ms/1000);s=s%86400;var h=Math.floor(s/3600),m=Math.floor(s%3600/60),c=s%60;
 return (h<10?'0':'')+h+':'+(m<10?'0':'')+m+':'+(c<10?'0':'')+c}
[1,2,4,8].forEach(function(x){var b=document.createElement('button');b.className='pill'+(x==1?' on':'');b.textContent=x+'×';
 b.onclick=function(e){e.stopPropagation();spd=x;[].forEach.call($('sp').children,function(c){c.classList.toggle('on',c===b)});wake()};$('sp').appendChild(b)});
function setPP(){pp.innerHTML=playing?PAUSE:PLAY;$('st').textContent=playing?spd+'×':'Jeda'}
function wake(){pl.classList.remove('hide');clearTimeout(hideT);if(playing&&!drag)hideT=setTimeout(function(){pl.classList.add('hide')},3000)}
function find(ms){var lo=0,hi=fr.length-1;while(lo<hi){var m=(lo+hi+1)>>1;if(fr[m][0]<=ms)lo=m;else hi=m-1}return lo}
function ui(){var p=dur?Math.min(1,ct/dur)*100:0;$('fill').style.width=p+'%';$('knob').style.left=p+'%';
 $('tm').textContent=mmss(ct)+' / '+mmss(dur);$('clk').textContent=clock(ct);$('tip').style.left=p+'%';$('tip').textContent=clock(ct)}
function show(i){if(loading||i===shown||!fr.length)return;loading=true;var im=new Image(),n=cur,s=i;
 im.onload=function(){loading=false;if(n===cur){v.src=im.src;shown=s}};
 im.onerror=function(){loading=false;shown=s};
 im.src=q('/rec/fr?f='+cur+'&p='+fr[i][1]+'&n='+fr[i][2])}
function tick(t){requestAnimationFrame(tick);var dt=last?t-last:0;last=t;
 if(playing&&!drag&&fr.length){ct+=dt*spd;if(ct>=dur){ct=dur;playing=false;setPP();wake()}}
 if(fr.length){show(find(ct));ui()}}
requestAnimationFrame(tick);
function seek(ms){ct=Math.max(0,Math.min(dur,ms));ui()}
function toggle(){if(!fr.length)return;if(ct>=dur-50)ct=0;playing=!playing;setPP();wake()}
pp.onclick=function(e){e.stopPropagation();toggle()};
$('bk').onclick=function(e){e.stopPropagation();seek(ct-10000);wake()};
$('fw').onclick=function(e){e.stopPropagation();seek(ct+10000);wake()};
function flash(id){var e=$(id);e.style.opacity=1;setTimeout(function(){e.style.opacity=0},350)}
var lastTap=0;
v.onclick=$('msg').onclick=function(e){var now=Date.now(),r=pl.getBoundingClientRect(),x=(e.clientX-r.left)/r.width;
 if(now-lastTap<300&&fr.length){if(x<.35){seek(ct-10000);flash('fl')}else if(x>.65){seek(ct+10000);flash('fr')}else toggle();lastTap=0;wake();return}
 lastTap=now;if(pl.classList.contains('hide'))wake();else pl.classList.add('hide')};
pl.onclick=function(e){if(e.target===pl)wake()};
var bar=$('bar');
function bpos(e){var r=$('trk').getBoundingClientRect(),x=(e.touches?e.touches[0].clientX:e.clientX);return Math.max(0,Math.min(1,(x-r.left)/r.width))}
function bd(e){if(!fr.length)return;drag=true;bar.classList.add('drag');clearTimeout(hideT);seek(bpos(e)*dur);e.preventDefault()}
function bm(e){if(drag){seek(bpos(e)*dur);e.preventDefault()}}
function bu(){if(drag){drag=false;bar.classList.remove('drag');wake()}}
bar.addEventListener('touchstart',bd,{passive:false});bar.addEventListener('touchmove',bm,{passive:false});bar.addEventListener('touchend',bu);
bar.addEventListener('mousedown',bd);window.addEventListener('mousemove',bm);window.addEventListener('mouseup',bu);
$('fsb').onclick=function(e){e.stopPropagation();var on=pl.classList.toggle('fs');
 try{if(on&&pl.requestFullscreen)pl.requestFullscreen();else if(!on&&document.fullscreenElement)document.exitFullscreen()}catch(x){}wake()};
document.addEventListener('fullscreenchange',function(){if(!document.fullscreenElement)pl.classList.remove('fs')});
document.addEventListener('keydown',function(e){if(e.key===' '){toggle();e.preventDefault()}else if(e.key==='ArrowLeft')seek(ct-5000);else if(e.key==='ArrowRight')seek(ct+5000)});
function open(name,secs){cur=d.value+'/'+name+'.mjpg';startSec=+name.substr(0,2)*3600+ +name.substr(2,2)*60+ +name.substr(4,2);
 playing=false;fr=[];dur=0;ct=0;shown=-1;setPP();$('msg').textContent='Memuat…';$('msg').style.display='flex';
 g('/rec/idx?f='+cur).then(function(t){fr=t.split('\n').filter(Boolean).map(function(l){var a=l.split(';');return[+a[0],+a[1],+a[2]]});
  if(!fr.length){$('msg').textContent='Rekaman kosong';return}
  dur=fr[fr.length-1][0]+100;$('msg').style.display='none';$('buf').style.width='100%';playing=true;setPP();wake();ui()})
 .catch(function(){$('msg').textContent='Gagal memuat rekaman'})}
var admin=false,selMode=false,sel={},ICO='<svg viewBox="0 0 24 24"><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 11v6M14 11v6"/></svg>';
var DLI='<svg viewBox="0 0 24 24"><path d="M12 4v11M7.5 10.5L12 15l4.5-4.5M5 19h14"/></svg>';
var dlPath='',pollT=0,mp4Busy=false,mp4Ready=false;
function gm(u){return fetch(q(u)).then(function(r){return r.text().then(function(t){return{ok:r.ok,t:t.trim()}})})}
function save(u){var a=document.createElement('a');a.href=q(u);document.body.appendChild(a);a.click();document.body.removeChild(a)}
function dstat(t,bad){var e=$('ds');e.textContent=t;e.style.color=bad?'#ff453a':''}
function dprog(p){$('pg').style.display=p<0?'none':'block';$('pgf').style.width=Math.max(0,p)+'%'}
function dlStop(cancel){clearTimeout(pollT);pollT=0;if(cancel&&mp4Busy&&dlPath)gm('/rec/mp4?f='+dlPath+'&cancel=1').catch(function(){});mp4Busy=false}
function dlClose(){dlStop(true);$('ov2').style.display='none'}
function dlOpen(path,a){dlStop(true);dlPath=path;mp4Ready=false;$('dt').textContent='Unduh rekaman jam '+lt(a[0]);dstat('');dprog(-1);$('d2').textContent='Unduh MP4';$('ov2').style.display='flex'}
function poll(){var p=dlPath;gm('/rec/mp4?f='+p).then(function(r){if(p!==dlPath||!mp4Busy)return;var a=r.t.split(';');
 if(!r.ok){mp4Busy=false;dprog(-1);dstat(r.t,true);return}
 if(a[0]==='proses'){dprog(+a[1]||0);dstat('Mengonversi ke MP4… '+(+a[1]||0)+'%. Ini memakan waktu dan baterai HP kamera, biarkan halaman ini terbuka.');pollT=setTimeout(poll,1200)}
 else if(a[0]==='siap'){mp4Busy=false;mp4Ready=true;dprog(100);dstat('MP4 siap ('+a[1]+' KB). Ketuk Simpan MP4.');$('d2').textContent='Simpan MP4'}
 else{mp4Busy=false;dprog(-1);dstat(a[1]||'Konversi gagal',true)}
 }).catch(function(){mp4Busy=false;dprog(-1);dstat('Gagal menghubungi kamera',true)})}
$('d1').onclick=function(){var p=dlPath;gm('/rec/dl?f='+p+'&c=1').then(function(r){if(r.ok){dstat('Unduhan dimulai, lihat notifikasi unduhan di browser.');save('/rec/dl?f='+p)}else dstat(r.t,true)}).catch(function(){dstat('Gagal menghubungi kamera',true)})};
$('d2').onclick=function(){var p=dlPath;if(mp4Busy)return;
 if(mp4Ready){gm('/rec/dl?f='+p+'&fmt=mp4&c=1').then(function(r){if(r.ok){dstat('Unduhan dimulai, lihat notifikasi unduhan di browser.');save('/rec/dl?f='+p+'&fmt=mp4')}else dstat(r.t,true)}).catch(function(){dstat('Gagal menghubungi kamera',true)});return}
 mp4Busy=true;dprog(0);dstat('Menyiapkan konversi…');poll()};
$('dc').onclick=dlClose;
function nsel(){return Object.keys(sel).length}
function tb(){$('tb').style.display=admin?'flex':'none';fl.classList.toggle('ad',admin);fl.classList.toggle('sm',selMode);
 $('bs').textContent=selMode?'Batal':'Pilih';$('ba').style.display=selMode?'':'none';
 var b=$('bd');b.textContent=selMode?'Hapus ('+nsel()+')':'Hapus hari ini';b.disabled=selMode&&!nsel()}
function ask(m,y){$('dm').textContent=m;$('ov').style.display='flex';$('dn').onclick=function(){$('ov').style.display='none'};
 $('dy').onclick=function(){$('ov').style.display='none';y()}}
function drop(f){if(cur&&f(cur)){playing=false;fr=[];dur=0;ct=0;cur='';shown=-1;v.removeAttribute('src');$('msg').textContent='Pilih rekaman di bawah';$('msg').style.display='flex';setPP();pl.classList.add('hide')}}
function del(qs,f){var snap=Object.assign({},sel);g('/rec/del?'+qs).then(function(){sel=snap;drop(f);selMode=false;sel={};loadDays()}).catch(function(){inf.textContent='Gagal menghapus. Hanya kunci admin yang bisa menghapus.'})}
function ld(){sel={};g('/rec/list?d='+d.value).then(function(t){fl.innerHTML='';
 t.split('\n').filter(Boolean).forEach(function(l){var a=l.split(';'),e=document.createElement('div');e.className='it';
  e.innerHTML='<div class="lf"><span class="ck"></span><span>'+lt(a[0])+'</span></div><div class="rt"><small>'+a[1]+' dtk · '+a[2]+' KB</small><button class="dl">'+DLI+'</button><button class="tr">'+ICO+'</button></div>';
  var path=d.value+'/'+a[0]+'.mjpg';e.dataset.p=path;
  e.querySelector('.dl').onclick=function(ev){ev.stopPropagation();dlOpen(path,a)};
  e.querySelector('.tr').onclick=function(ev){ev.stopPropagation();ask('Hapus rekaman jam '+lt(a[0])+'? Tidak bisa dikembalikan.',function(){del('f='+path,function(c){return c===path})})};
  e.onclick=function(){if(selMode){if(sel[path]){delete sel[path];e.classList.remove('sel')}else{sel[path]=1;e.classList.add('sel')}tb();return}
   [].forEach.call(fl.children,function(c){c.classList.remove('on')});e.classList.add('on');open(a[0],+a[1]);window.scrollTo(0,0)};fl.appendChild(e)});
 inf.textContent=fl.children.length?(selMode?'Pilih rekaman yang mau dihapus':'Ketuk rekaman untuk memutar'):'Tidak ada rekaman di tanggal ini';tb()})}
function loadDays(){var keep=d.value;return g('/rec/days').then(function(t){d.innerHTML='';var a=t.split('\n').filter(Boolean);
 a.forEach(function(x){var o=document.createElement('option');o.value=x;o.textContent=x.substr(6,2)+'-'+x.substr(4,2)+'-'+x.substr(0,4);d.appendChild(o)});
 if(a.indexOf(keep)>=0)d.value=keep;ld()})
 .catch(function(){inf.textContent='Kunci salah atau tidak punya izin rekaman'})}
$('bs').onclick=function(){selMode=!selMode;sel={};[].forEach.call(fl.children,function(c){c.classList.remove('sel')});inf.textContent=selMode?'Pilih rekaman yang mau dihapus':'Ketuk rekaman untuk memutar';tb()};
$('ba').onclick=function(){var all=nsel()<fl.children.length;sel={};[].forEach.call(fl.children,function(c){c.classList.toggle('sel',all);if(all)sel[c.dataset.p]=1});tb()};
$('bd').onclick=function(){
 if(selMode){var ks=Object.keys(sel);if(!ks.length)return;
  ask('Hapus '+ks.length+' rekaman yang dipilih? Tidak bisa dikembalikan.',function(){del('f='+ks.join(','),function(c){return sel[c]})})}
 else{var day=d.value;if(!day||!fl.children.length)return;
  ask('Hapus semua rekaman tanggal '+d.options[d.selectedIndex].textContent+'? Tidak bisa dikembalikan.',function(){del('d='+day,function(c){return c.indexOf(day+'/')==0})})}};
g('/rec/role').then(function(t){admin=t.trim()==='3'}).catch(function(){}).then(loadDays);
d.onchange=ld;setPP();
</script></body></html>"""
