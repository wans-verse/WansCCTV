package com.wans.cctv.camera

import java.io.File
import java.io.RandomAccessFile

/** Daftar frame sebuah rekaman. Baris: "offsetMs;posisi;ukuran" (offset dari frame pertama). */
fun recIndex(f: File): String {
    val sb = StringBuilder()
    try {
        RandomAccessFile(f, "r").use { r ->
            val len = r.length()
            var pos = 0L
            var t0 = -1L
            while (pos + 12 <= len) {
                r.seek(pos)
                val t = r.readLong()
                val n = r.readInt()
                if (n <= 0 || n > 2_000_000 || pos + 12 + n > len) break
                if (t0 < 0) t0 = t
                sb.append(t - t0).append(';').append(pos + 12).append(';').append(n).append('\n')
                pos += 12L + n
            }
        }
    } catch (e: Exception) {
    }
    return sb.toString()
}

/** Ambil satu frame JPEG dari file rekaman. */
fun recFrame(f: File, pos: Long, n: Int): ByteArray? = try {
    if (pos < 12 || n <= 0 || n > 2_000_000 || pos + n > f.length()) null
    else RandomAccessFile(f, "r").use { r ->
        r.seek(pos)
        val d = ByteArray(n)
        r.readFully(d)
        d
    }
} catch (e: Exception) {
    null
}

/** Halaman playback (dibuka dari browser HP mana pun): http://ALAMAT:8080/playback?k=KUNCI */
const val PLAYBACK_HTML = """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title>Rekaman</title>
<style>
:root{color-scheme:dark;--bg:#000;--card:#1c1c1e;--fill:rgba(120,120,128,.36);--lbl2:#8e8e93;--blue:#0a84ff;--glass:rgba(40,40,44,.62)}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none}
html,body{margin:0;background:var(--bg);color:#fff;font:15px -apple-system,BlinkMacSystemFont,"SF Pro Text","Helvetica Neue",Roboto,sans-serif}
.wrap{max-width:900px;margin:0 auto;padding:max(12px,env(safe-area-inset-top)) 14px max(16px,env(safe-area-inset-bottom))}
h1{font-size:28px;font-weight:700;letter-spacing:-.4px;margin:6px 2px 12px}
.sel{display:flex;gap:8px;margin-bottom:12px}
select{flex:1;min-width:0;appearance:none;-webkit-appearance:none;background:var(--card);color:#fff;border:0;border-radius:12px;padding:12px 14px;font-size:16px;font-family:inherit}
#pl{position:relative;background:#000;border-radius:16px;overflow:hidden;aspect-ratio:16/9;width:100%}
#pl.fs{position:fixed;inset:0;z-index:99;border-radius:0;aspect-ratio:auto;height:100%}
#v{width:100%;height:100%;object-fit:contain;display:block;background:#111}
#ctl{position:absolute;left:0;right:0;bottom:0;padding:34px 14px 12px;background:linear-gradient(transparent,rgba(0,0,0,.72));transition:opacity .25s}
#pl.hide #ctl,#pl.hide #top{opacity:0;pointer-events:none}
#top{position:absolute;top:10px;left:12px;right:12px;display:flex;justify-content:space-between;transition:opacity .25s;pointer-events:none}
.chip{background:var(--glass);-webkit-backdrop-filter:blur(20px);backdrop-filter:blur(20px);border-radius:999px;padding:5px 11px;font-size:13px;font-weight:600;font-variant-numeric:tabular-nums}
#mid{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;gap:34px;transition:opacity .25s}
#pl.hide #mid{opacity:0;pointer-events:none}
.b{width:46px;height:46px;border-radius:50%;border:0;background:var(--glass);-webkit-backdrop-filter:blur(20px);backdrop-filter:blur(20px);color:#fff;display:flex;align-items:center;justify-content:center;padding:0;font:600 12px inherit}
.b svg{width:22px;height:22px;fill:#fff}
.b.big{width:64px;height:64px}.b.big svg{width:30px;height:30px}
.b:active{transform:scale(.92);background:rgba(90,90,96,.8)}
#bar{position:relative;height:28px;display:flex;align-items:center;touch-action:none}
#trk{position:relative;width:100%;height:4px;border-radius:2px;background:rgba(255,255,255,.3);transition:height .12s}
#bar.drag #trk{height:8px}
#buf{position:absolute;left:0;top:0;bottom:0;border-radius:2px;background:rgba(255,255,255,.35)}
#fill{position:absolute;left:0;top:0;bottom:0;width:0;border-radius:2px;background:#fff}
#knob{position:absolute;top:50%;left:0;width:14px;height:14px;margin:-7px 0 0 -7px;border-radius:50%;background:#fff;box-shadow:0 1px 4px rgba(0,0,0,.5);transition:transform .12s}
#bar.drag #knob{transform:scale(1.5)}
#tip{position:absolute;bottom:34px;transform:translateX(-50%);display:none}
#bar.drag #tip{display:block}
.row{display:flex;align-items:center;justify-content:space-between;margin-top:2px}
.row .l{font-size:13px;font-variant-numeric:tabular-nums;color:#ebebf5}
.sp{display:flex;gap:6px}
.pill{border:0;border-radius:999px;padding:6px 11px;background:var(--glass);-webkit-backdrop-filter:blur(20px);backdrop-filter:blur(20px);color:#fff;font:600 13px inherit}
.pill.on{background:#fff;color:#000}
#msg{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:var(--lbl2);text-align:center;padding:20px;pointer-events:none}
#fl,#fr{position:absolute;top:0;bottom:0;width:34%;display:flex;align-items:center;justify-content:center;font-weight:700;opacity:0;transition:opacity .2s;pointer-events:none}
#fl{left:0;background:radial-gradient(circle at 0 50%,rgba(255,255,255,.25),transparent 70%)}
#fr{right:0;background:radial-gradient(circle at 100% 50%,rgba(255,255,255,.25),transparent 70%)}
.list{margin-top:14px;background:var(--card);border-radius:14px;overflow:hidden}
.it{display:flex;justify-content:space-between;align-items:center;padding:13px 16px;border-bottom:.5px solid rgba(84,84,88,.6)}
.it:last-child{border:0}.it:active{background:#2c2c2e}
.it.on{color:var(--blue);font-weight:600}.it small{color:var(--lbl2);font-weight:400}
#i{color:var(--lbl2);font-size:13px;margin:10px 4px}
</style></head><body><div class="wrap">
<h1>Rekaman</h1>
<div class="sel"><select id="d"></select></div>
<div id="pl" class="hide">
 <img id="v" alt="">
 <div id="msg">Pilih rekaman di bawah</div>
 <div id="fl">« 10 dtk</div><div id="fr">10 dtk »</div>
 <div id="top"><span class="chip" id="clk">--:--:--</span><span class="chip" id="st"></span></div>
 <div id="mid">
  <button class="b" id="bk"><svg viewBox="0 0 24 24"><path d="M12 5V2L7 6l5 4V7a5 5 0 1 1-5 5H5a7 7 0 1 0 7-7z"/></svg></button>
  <button class="b big" id="pp"></button>
  <button class="b" id="fw"><svg viewBox="0 0 24 24"><path d="M12 5V2l5 4-5 4V7a5 5 0 1 0 5 5h2a7 7 0 1 1-7-7z"/></svg></button>
 </div>
 <div id="ctl">
  <div id="bar"><div id="trk"><div id="buf"></div><div id="fill"></div><div id="knob"></div></div><span class="chip" id="tip">0:00</span></div>
  <div class="row"><span class="l" id="tm">0:00 / 0:00</span>
   <div class="sp" id="sp"></div>
   <button class="pill" id="fsb">⤢</button></div>
 </div>
</div>
<div id="i"></div>
<div class="list" id="f"></div>
</div>
<script>
var K=new URLSearchParams(location.search).get('k')||'';
function $(x){return document.getElementById(x)}
function q(u){return u+(u.indexOf('?')<0?'?':'&')+'k='+K}
function g(u){return fetch(q(u)).then(function(r){if(!r.ok)throw r.status;return r.text()})}
var pl=$('pl'),v=$('v'),d=$('d'),fl=$('f'),inf=$('i'),pp=$('pp');
var PLAY='<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>',PAUSE='<svg viewBox="0 0 24 24"><path d="M6 5h4v14H6zm8 0h4v14h-4z"/></svg>';
var fr=[],dur=0,ct=0,playing=false,spd=1,last=0,cur='',shown=-1,loading=false,startSec=0,hideT=0,drag=false,names=[];
function lt(s){return s.substr(0,2)+':'+s.substr(2,2)+':'+s.substr(4,2)}
function mmss(ms){var s=Math.max(0,Math.floor(ms/1000)),h=Math.floor(s/3600),m=Math.floor(s%3600/60),c=s%60;
 return (h?h+':'+(m<10?'0':''):'')+m+':'+(c<10?'0':'')+c}
function clock(ms){var s=startSec+Math.floor(ms/1000);s=s%86400;var h=Math.floor(s/3600),m=Math.floor(s%3600/60),c=s%60;
 return (h<10?'0':'')+h+':'+(m<10?'0':'')+m+':'+(c<10?'0':'')+c}
[1,2,4,8].forEach(function(x){var b=document.createElement('button');b.className='pill'+(x==1?' on':'');b.textContent=x+'×';
 b.onclick=function(e){e.stopPropagation();spd=x;[].forEach.call($('sp').children,function(c){c.classList.toggle('on',c===b)});wake()};$('sp').appendChild(b)});
function setPP(){pp.innerHTML=playing?PAUSE:PLAY;$('st').textContent=playing?spd+'×':'Jeda'}
function wake(){pl.classList.remove('hide');clearTimeout(hideT);if(playing&&!drag)hideT=setTimeout(function(){pl.classList.add('hide')},3000)}
function find(ms){var lo=0,hi=fr.length-1;while(lo<hi){var m=(lo+hi+1)>>1;if(fr[m][0]<=ms)lo=m;else hi=m-1}return lo}
function ui(){var p=dur?Math.min(1,ct/dur)*100:0;$('fill').style.width=p+'%';$('knob').style.left=p+'%';
 $('tm').textContent=mmss(ct)+' / '+mmss(dur);$('clk').textContent=clock(ct);$('tip').style.left=p+'%';$('tip').textContent=clock(ct)}
function show(i){if(loading||i===shown||!fr.length)return;loading=true;var im=new Image(),n=cur,s=i;
 im.onload=function(){loading=false;if(n===cur){v.src=im.src;shown=s}};
 im.onerror=function(){loading=false;shown=s};
 im.src=q('/rec/fr?f='+cur+'&p='+fr[i][1]+'&n='+fr[i][2])}
function tick(t){requestAnimationFrame(tick);var dt=last?t-last:0;last=t;
 if(playing&&!drag&&fr.length){ct+=dt*spd;if(ct>=dur){ct=dur;playing=false;setPP();wake()}}
 if(fr.length){show(find(ct));ui()}}
requestAnimationFrame(tick);
function seek(ms){ct=Math.max(0,Math.min(dur,ms));ui()}
function toggle(){if(!fr.length)return;if(ct>=dur-50)ct=0;playing=!playing;setPP();wake()}
pp.onclick=function(e){e.stopPropagation();toggle()};
$('bk').onclick=function(e){e.stopPropagation();seek(ct-10000);wake()};
$('fw').onclick=function(e){e.stopPropagation();seek(ct+10000);wake()};
function flash(id){var e=$(id);e.style.opacity=1;setTimeout(function(){e.style.opacity=0},350)}
var lastTap=0;
v.onclick=$('msg').onclick=function(e){var now=Date.now(),r=pl.getBoundingClientRect(),x=(e.clientX-r.left)/r.width;
 if(now-lastTap<300&&fr.length){if(x<.35){seek(ct-10000);flash('fl')}else if(x>.65){seek(ct+10000);flash('fr')}else toggle();lastTap=0;wake();return}
 lastTap=now;if(pl.classList.contains('hide'))wake();else pl.classList.add('hide')};
pl.onclick=function(e){if(e.target===pl)wake()};
var bar=$('bar');
function bpos(e){var r=$('trk').getBoundingClientRect(),x=(e.touches?e.touches[0].clientX:e.clientX);return Math.max(0,Math.min(1,(x-r.left)/r.width))}
function bd(e){if(!fr.length)return;drag=true;bar.classList.add('drag');clearTimeout(hideT);seek(bpos(e)*dur);e.preventDefault()}
function bm(e){if(drag){seek(bpos(e)*dur);e.preventDefault()}}
function bu(){if(drag){drag=false;bar.classList.remove('drag');wake()}}
bar.addEventListener('touchstart',bd,{passive:false});bar.addEventListener('touchmove',bm,{passive:false});bar.addEventListener('touchend',bu);
bar.addEventListener('mousedown',bd);window.addEventListener('mousemove',bm);window.addEventListener('mouseup',bu);
$('fsb').onclick=function(e){e.stopPropagation();var on=pl.classList.toggle('fs');
 try{if(on&&pl.requestFullscreen)pl.requestFullscreen();else if(!on&&document.fullscreenElement)document.exitFullscreen()}catch(x){}wake()};
document.addEventListener('fullscreenchange',function(){if(!document.fullscreenElement)pl.classList.remove('fs')});
document.addEventListener('keydown',function(e){if(e.key===' '){toggle();e.preventDefault()}else if(e.key==='ArrowLeft')seek(ct-5000);else if(e.key==='ArrowRight')seek(ct+5000)});
function open(name,secs){cur=d.value+'/'+name+'.mjpg';startSec=+name.substr(0,2)*3600+ +name.substr(2,2)*60+ +name.substr(4,2);
 playing=false;fr=[];dur=0;ct=0;shown=-1;setPP();$('msg').textContent='Memuat…';$('msg').style.display='flex';
 g('/rec/idx?f='+cur).then(function(t){fr=t.split('\n').filter(Boolean).map(function(l){var a=l.split(';');return[+a[0],+a[1],+a[2]]});
  if(!fr.length){$('msg').textContent='Rekaman kosong';return}
  dur=fr[fr.length-1][0]+100;$('msg').style.display='none';$('buf').style.width='100%';playing=true;setPP();wake();ui()})
 .catch(function(){$('msg').textContent='Gagal memuat rekaman'})}
function ld(){g('/rec/list?d='+d.value).then(function(t){fl.innerHTML='';
 t.split('\n').filter(Boolean).forEach(function(l){var a=l.split(';'),e=document.createElement('div');e.className='it';
  e.innerHTML='<span>'+lt(a[0])+'</span><small>'+a[1]+' dtk · '+a[2]+' KB</small>';
  e.onclick=function(){[].forEach.call(fl.children,function(c){c.classList.remove('on')});e.classList.add('on');open(a[0],+a[1]);window.scrollTo(0,0)};fl.appendChild(e)});
 inf.textContent=fl.children.length?'Ketuk rekaman untuk memutar':'Tidak ada rekaman di tanggal ini'})}
g('/rec/days').then(function(t){t.split('\n').filter(Boolean).forEach(function(x){var o=document.createElement('option');
 o.value=x;o.textContent=x.substr(6,2)+'-'+x.substr(4,2)+'-'+x.substr(0,4);d.appendChild(o)});ld()})
 .catch(function(){inf.textContent='Kunci salah atau tidak punya izin rekaman'});
d.onchange=ld;setPP();
</script></body></html>"""
