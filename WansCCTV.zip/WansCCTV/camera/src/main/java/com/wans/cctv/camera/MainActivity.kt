package com.wans.cctv.camera

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.content.ClipData
import android.content.ClipboardManager
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Collections

private val BG = Color.BLACK
private val CARD = Color.parseColor("#1C1C1E")
private val GRAY = Color.parseColor("#8E8E93")
private val WHITE = Color.WHITE
private val BLUE = Color.parseColor("#0A84FF")
private val GREEN = Color.parseColor("#30D158")
private val RED = Color.parseColor("#FF453A")
private val RED_BG = Color.parseColor("#3A1E1E")
private val SEG_BG = Color.parseColor("#3A3A3C")
private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

private fun localIp(): String? {
    try {
        for (ni in Collections.list(NetworkInterface.getNetworkInterfaces() ?: return null)) {
            if (!ni.isUp || ni.isLoopback) continue
            for (a in Collections.list(ni.inetAddresses)) {
                if (a is Inet4Address && a.isSiteLocalAddress) return a.hostAddress
            }
        }
    } catch (e: Exception) {
    }
    return null
}

/** Alamat Tailscale (100.64.x.x – 100.127.x.x) kalau aplikasi Tailscale aktif, untuk akses dari luar rumah. */
private fun vpnIp(): String? {
    try {
        for (ni in Collections.list(NetworkInterface.getNetworkInterfaces() ?: return null)) {
            if (!ni.isUp || ni.isLoopback) continue
            for (a in Collections.list(ni.inetAddresses)) {
                if (a is Inet4Address) {
                    val b = a.address
                    if ((b[0].toInt() and 255) == 100 && (b[1].toInt() and 255) in 64..127) return a.hostAddress
                }
            }
        }
    } catch (e: Exception) {
    }
    return null
}

class MainActivity : ComponentActivity() {

    private val h = Handler(Looper.getMainLooper())
    private lateinit var dot: View
    private lateinit var statusT: TextView
    private lateinit var addrT: TextView
    private lateinit var toggle: TextView
    private lateinit var screenT: TextView
    private lateinit var screenBtn: TextView
    private var askedScreen = false
    private lateinit var storT: TextView
    private lateinit var accessT: TextView
    private lateinit var ntfyHint: TextView
    private lateinit var battBtn: TextView

    // Alur izin saat pertama kali aplikasi dibuka setelah dipasang.
    private var setupRunning = false
    private var setupStep = 0
    private val appPrefs by lazy { getSharedPreferences("setup", MODE_PRIVATE) }

    private val perm = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        startCam(!setupRunning)
        if (setupRunning) nextSetupStep()
    }

    private val stepReq = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (setupRunning) nextSetupStep()
    }

    private val screenReq = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val d = r.data
        if (r.resultCode == Activity.RESULT_OK && d != null) {
            val i = Intent(this, ScreenService::class.java)
                .putExtra("code", r.resultCode)
                .putExtra("data", d)
            ContextCompat.startForegroundService(this, i)
        }
        h.postDelayed({ refresh() }, 600)
        if (setupRunning) nextSetupStep()
    }

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            h.postDelayed(this, 1000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(c: Int, r: Int) = GradientDrawable().apply {
        setColor(c)
        cornerRadius = dp(r).toFloat()
    }

    private fun tv(t: String, sp: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = t
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(color)
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    }

    private fun pill(t: String, fill: Int, fg: Int): TextView = tv(t, 17f, fg, true).apply {
        gravity = Gravity.CENTER
        background = rounded(fill, 16)
        setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_DOWN) v.alpha = 0.6f
            else if (e.action == MotionEvent.ACTION_UP || e.action == MotionEvent.ACTION_CANCEL) v.alpha = 1f
            false
        }
    }

    private fun lp(w: Int, hh: Int, top: Int = 0) = LinearLayout.LayoutParams(w, hh).apply { topMargin = dp(top) }

    /** Pilihan segmen ala iOS: satu baris tombol, yang dipilih berwarna biru. */
    private fun seg(title: String, labels: List<String>, selected: Int, onPick: (Int) -> Unit): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(tv(title, 14f, GRAY, false))
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(SEG_BG, 12)
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }
        val items = mutableListOf<TextView>()
        fun paint(sel: Int) {
            items.forEachIndexed { i, t ->
                t.background = rounded(if (i == sel) BLUE else Color.TRANSPARENT, 10)
            }
        }
        labels.forEachIndexed { i, label ->
            val t = tv(label, 15f, WHITE, true).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(10), 0, dp(10))
                setOnClickListener {
                    paint(i)
                    onPick(i)
                }
            }
            items.add(t)
            row.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        paint(selected)
        box.addView(row, lp(MATCH, WRAP, 6))
        return box
    }

    /** Pengaturan tampilan kotak penanda: warna, tebal garis, dan pratinjau. */
    private fun boxStyleView(sp: android.content.SharedPreferences): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(tv("Warna kotak", 14f, GRAY, false))

        var color = sp.getInt(CamSettings.K_BOX_COLOR, 0).coerceIn(0, CamSettings.BOX_COLORS.size - 1)
        var width = CamSettings.boxWidth(this)

        val preview = object : View(this) {
            override fun onDraw(c: android.graphics.Canvas) {
                val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                    style = android.graphics.Paint.Style.STROKE
                    this.color = CamSettings.BOX_COLORS[color]
                    strokeWidth = width * resources.displayMetrics.density * 0.75f
                }
                val m = p.strokeWidth
                c.drawRect(m + dp(16), m + dp(10), this.width - m - dp(16), this.height - m - dp(10), p)
            }
        }.apply { background = rounded(Color.parseColor("#2C2C2E"), 12) }

        val swatches = mutableListOf<View>()
        fun paintSwatches() {
            swatches.forEachIndexed { i, v ->
                v.background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.OVAL
                    setColor(CamSettings.BOX_COLORS[i])
                    if (i == color) setStroke(dp(2), BLUE) else setStroke(dp(1), Color.parseColor("#48484A"))
                }
            }
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in CamSettings.BOX_COLORS.indices) {
            val v = View(this)
            v.setOnClickListener {
                color = i
                sp.edit().putInt(CamSettings.K_BOX_COLOR, i).apply()
                paintSwatches()
                preview.invalidate()
            }
            swatches.add(v)
            row.addView(v, LinearLayout.LayoutParams(dp(34), dp(34)).apply { rightMargin = dp(12) })
        }
        paintSwatches()
        box.addView(row, lp(WRAP, WRAP, 8))

        val wl = tv("Tebal garis: $width px", 14f, GRAY, false)
        box.addView(wl, lp(WRAP, WRAP, 14))
        val bar = android.widget.SeekBar(this).apply {
            max = 4
            progress = width - 1
            IosUi.styleSeekBar(this)
            setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: android.widget.SeekBar?, p: Int, fromUser: Boolean) {
                    width = p + 1
                    wl.text = "Tebal garis: $width px"
                    preview.invalidate()
                }
                override fun onStartTrackingTouch(s: android.widget.SeekBar?) {}
                override fun onStopTrackingTouch(s: android.widget.SeekBar?) {
                    sp.edit().putInt(CamSettings.K_BOX_W, width).apply()
                }
            })
        }
        box.addView(bar, lp(MATCH, WRAP, 2))
        box.addView(preview, lp(MATCH, dp(64), 10))
        return box
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(72), dp(24), dp(32))
        }
        col.addView(tv("Kamera", 34f, WHITE, true))
        col.addView(tv("HP kamera • biarkan tetap menyala", 15f, GRAY, false), lp(WRAP, WRAP, 2))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(CARD, 20)
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        dot = View(this)
        row.addView(dot, LinearLayout.LayoutParams(dp(12), dp(12)))
        statusT = tv("Memulai…", 17f, WHITE, true)
        row.addView(statusT, lp(WRAP, WRAP).apply { leftMargin = dp(12) })
        card.addView(row, lp(MATCH, WRAP))
        addrT = tv("", 14f, GRAY, false)
        card.addView(addrT, lp(WRAP, WRAP, 10))
        screenT = tv("", 14f, GRAY, false)
        card.addView(screenT, lp(WRAP, WRAP, 4))
        // Tombol izin bagikan layar: izin ini bisa mati sendiri, jadi bisa diminta ulang dari sini.
        screenBtn = pill("Izinkan bagikan layar", BLUE, WHITE).apply { textSize = 15f }
        screenBtn.setOnClickListener {
            askedScreen = true
            askScreen()
        }
        card.addView(screenBtn, lp(MATCH, dp(50), 14))
        col.addView(card, lp(MATCH, WRAP, 28))

        val sp = CamSettings.prefs(this)
        val cfg = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(CARD, 20)
        }
        cfg.addView(tv("Kualitas video", 17f, WHITE, true))
        cfg.addView(tv("Makin rendah, makin hemat data dan ringan. Berlaku langsung.", 13f, GRAY, false), lp(WRAP, WRAP, 2))
        cfg.addView(
            seg("Resolusi", listOf("240p", "360p", "480p"), CamSettings.RES.indexOf(CamSettings.res(this))) { i ->
                sp.edit().putInt(CamSettings.K_RES, CamSettings.RES[i]).apply()
            },
            lp(MATCH, WRAP, 16)
        )
        cfg.addView(
            seg("Kecepatan gambar", listOf("5 fps", "10 fps", "15 fps"), CamSettings.FPS.indexOf(CamSettings.fps(this))) { i ->
                sp.edit().putInt(CamSettings.K_FPS, CamSettings.FPS[i]).apply()
            },
            lp(MATCH, WRAP, 14)
        )
        cfg.addView(
            seg("Kualitas gambar", listOf("Hemat", "Sedang", "Tinggi"), CamSettings.QUAL.indexOf(CamSettings.quality(this))) { i ->
                sp.edit().putInt(CamSettings.K_Q, CamSettings.QUAL[i]).apply()
            },
            lp(MATCH, WRAP, 14)
        )
        col.addView(cfg, lp(MATCH, WRAP, 16))

        // ----- Rekaman -----
        val rc = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(CARD, 20)
        }
        rc.addView(tv("Rekaman", 17f, WHITE, true))
        storT = tv("", 13f, GRAY, false)
        rc.addView(storT, lp(WRAP, WRAP, 2))
        rc.addView(seg("Mode rekam", listOf("Mati", "Gerak", "24 jam"), CamSettings.rec(this)) { i ->
            sp.edit().putInt(CamSettings.K_REC, i).apply()
        }, lp(MATCH, WRAP, 14))
        rc.addView(seg("Lama riwayat (loop, yang lama otomatis dihapus)", listOf("1 hari", "3 hari", "7 hari"),
            CamSettings.DAYS.indexOf(CamSettings.days(this))) { i ->
            sp.edit().putInt(CamSettings.K_DAYS, CamSettings.DAYS[i]).apply()
        }, lp(MATCH, WRAP, 14))
        rc.addView(seg("Deteksi gerakan (notifikasi + rekam saat gerak)", listOf("Aktif", "Nonaktif"), if (CamSettings.detect(this)) 0 else 1) { i ->
            sp.edit().putBoolean(CamSettings.K_DETECT, i == 0).apply()
        }, lp(MATCH, WRAP, 14))
        rc.addView(seg("Kepekaan gerak", listOf("Rendah", "Sedang", "Tinggi"), CamSettings.sens(this)) { i ->
            sp.edit().putInt(CamSettings.K_SENS, i).apply()
        }, lp(MATCH, WRAP, 14))
        rc.addView(seg("Kotak penanda gerak (hanya di layar live, rekaman tetap bersih)", listOf("Aktif", "Nonaktif"), if (CamSettings.boxes(this)) 0 else 1) { i ->
            sp.edit().putBoolean(CamSettings.K_BOX, i == 0).apply()
        }, lp(MATCH, WRAP, 14))
        rc.addView(boxStyleView(sp), lp(MATCH, WRAP, 14))
        val ntfyBtn = pill("Notifikasi gerak (ntfy)", CARD, BLUE).apply { textSize = 15f }
        ntfyBtn.setOnClickListener { ntfyDialog() }
        rc.addView(ntfyBtn, lp(MATCH, dp(50), 12))
        col.addView(rc, lp(MATCH, WRAP, 16))

        // ----- Jalan otomatis & baterai -----
        val bc = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(CARD, 20)
        }
        bc.addView(tv("Jalan otomatis & baterai", 17f, WHITE, true))
        bc.addView(
            seg("Jalankan otomatis saat HP menyala", listOf("Aktif", "Nonaktif"), if (CamSettings.autoStart(this)) 0 else 1) { i ->
                sp.edit().putBoolean(CamSettings.K_AUTOSTART, i == 0).apply()
                if (i == 0) askBatteryOpt()
            },
            lp(MATCH, WRAP, 14)
        )
        bc.addView(
            tv(
                "Setelah HP menyala ulang, muncul notifikasi \"Ketuk untuk mengaktifkan CCTV\" " +
                    "(Android 11 ke atas tidak mengizinkan kamera hidup sendiri dari latar belakang). " +
                    "Di HP Vivo, Xiaomi, Oppo dan sejenisnya, aktifkan juga izin \"Mulai otomatis\" untuk aplikasi ini di pengaturan HP.",
                13f, GRAY, false
            ),
            lp(MATCH, WRAP, 8)
        )
        battBtn = pill("Izinkan abaikan optimasi baterai", CARD, BLUE).apply { textSize = 15f }
        battBtn.setOnClickListener { askBatteryOpt() }
        bc.addView(battBtn, lp(MATCH, dp(50), 10))
        bc.addView(
            seg("Notifikasi baterai dan charger", listOf("Aktif", "Nonaktif"), if (CamSettings.battNotif(this)) 0 else 1) { i ->
                sp.edit().putBoolean(CamSettings.K_BATT_NOTIF, i == 0).apply()
            },
            lp(MATCH, WRAP, 16)
        )
        bc.addView(
            tv("Dikirim saat charger dilepas atau dipasang, dan saat baterai tinggal 15% dan 5%.", 13f, GRAY, false),
            lp(MATCH, WRAP, 8)
        )
        ntfyHint = tv("Isi nama topik ntfy untuk menerima notifikasi (tombol \"Notifikasi gerak (ntfy)\" di kartu Rekaman).", 13f, RED, false)
        bc.addView(ntfyHint, lp(MATCH, WRAP, 8))
        col.addView(bc, lp(MATCH, WRAP, 16))

        // ----- Akses & keamanan -----
        val ac = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(CARD, 20)
        }
        ac.addView(tv("Akses keluarga & keamanan", 17f, WHITE, true))
        accessT = tv("", 13f, GRAY, false)
        ac.addView(accessT, lp(WRAP, WRAP, 6))
        val addLive = pill("Tambah akses: hanya live", CARD, BLUE).apply { textSize = 15f }
        addLive.setOnClickListener { addAccess(Auth.LIVE) }
        ac.addView(addLive, lp(MATCH, dp(50), 12))
        val addFull = pill("Tambah akses: live + rekaman", CARD, BLUE).apply { textSize = 15f }
        addFull.setOnClickListener { addAccess(Auth.FULL) }
        ac.addView(addFull, lp(MATCH, dp(50), 8))
        val revoke = pill("Cabut / hapus akses", CARD, RED).apply { textSize = 15f }
        revoke.setOnClickListener { revokeDialog() }
        ac.addView(revoke, lp(MATCH, dp(50), 8))
        val reset = pill("Atur / ganti kunci admin", CARD, RED).apply { textSize = 15f }
        reset.setOnClickListener { adminKeyDialog(false) }
        ac.addView(reset, lp(MATCH, dp(50), 8))
        col.addView(ac, lp(MATCH, WRAP, 16))

        toggle = pill("Mulai Kamera", BLUE, WHITE)
        toggle.setOnClickListener {
            if (CameraService.running) {
                CamSettings.prefs(this).edit().putBoolean(CamSettings.K_WANT_ON, false).apply()
                stopService(Intent(this, CameraService::class.java))
                stopService(Intent(this, ScreenService::class.java))
            } else {
                askAndStart()
            }
            h.postDelayed({ refresh() }, 300)
        }
        col.addView(toggle, lp(MATCH, dp(58), 16))

        val sv = ScrollView(this).apply {
            setBackgroundColor(BG)
            isFillViewport = true
            addView(col)
        }
        setContentView(sv)
        if (!appPrefs.getBoolean("first_done", false)) {
            // Pertama kali dibuka setelah instal: minta semua izin berurutan.
            setupRunning = true
            setupStep = 0
            nextSetupStep()
        } else {
            askAndStart()
            if (!Auth.hasAdmin(this)) adminKeyDialog(true)
        }
    }

    private fun launchStep(i: Intent) {
        try {
            stepReq.launch(i)
        } catch (e: Exception) {
            nextSetupStep()
        }
    }

    private fun accessibilityOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains("$packageName/", ignoreCase = true)
    }

    /** Urutan: izin kamera+notifikasi → baterai → bagikan layar → kontrol sentuh → izin app (Vivo) → kunci admin. */
    private fun nextSetupStep() {
        when (setupStep++) {
            0 -> askAndStart()
            1 -> {
                val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
                if (pm.isIgnoringBatteryOptimizations(packageName)) nextSetupStep()
                else launchStep(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            }
            2 -> if (ScreenService.active) nextSetupStep() else { askedScreen = true; askScreen() }
            3 -> if (accessibilityOn()) nextSetupStep() else launchStep(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            4 -> launchStep(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            else -> {
                setupRunning = false
                appPrefs.edit().putBoolean("first_done", true).apply()
                if (!Auth.hasAdmin(this)) adminKeyDialog(true)
                refresh()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        h.post(tick)
    }

    override fun onPause() {
        super.onPause()
        h.removeCallbacks(tick)
    }

    private fun askAndStart() {
        val need = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        perm.launch(need.toTypedArray())
    }

    private fun startCam(askScr: Boolean = true) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            if (!CameraService.running) {
                ContextCompat.startForegroundService(this, Intent(this, CameraService::class.java))
                if (askScr && !ScreenService.active && !askedScreen) {
                    askedScreen = true
                    askScreen()
                }
            }
        } else {
            statusT.text = "Izin kamera ditolak"
        }
        h.postDelayed({ refresh() }, 400)
    }

    private fun askScreen() {
        try {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            screenReq.launch(mpm.createScreenCaptureIntent())
        } catch (e: Exception) {
            screenT.text = "Layar: tidak bisa diminta izin"
        }
    }

    private fun copy(label: String, text: String) {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText(label, text))
    }

    private fun numField(hint: String) =
        IosUi.field(this, hint, InputType.TYPE_CLASS_NUMBER).apply {
            filters = arrayOf(android.text.InputFilter.LengthFilter(Auth.MAX_DIGITS))
        }

    /** Dialog atur kunci admin manual (angka). Kalau [force], tidak bisa ditutup sebelum diisi. */
    private fun adminKeyDialog(force: Boolean) {
        val et = numField("Kunci admin (${Auth.MIN_DIGITS}–${Auth.MAX_DIGITS} digit angka)")
        val box = LinearLayout(this).apply { addView(et, lp(MATCH, WRAP)) }
        val d = IosDialog(this)
            .title(if (force) "Buat kunci admin" else "Atur kunci admin")
            .message("Isi sendiri, angka saja. Masukkan kunci yang sama di HP monitor.")
            .content(box)
            .cancelable(!force)
        if (!force) d.button("Batal", IosUi.CANCEL)
        d.button("Simpan", IosUi.BOLD, dismiss = false) {
            val err = Auth.setAdmin(this, et.text.toString().trim())
            if (err != null) {
                d.setError(err)
            } else {
                d.dismiss()
                refresh()
                IosUi.toast(this, "Kunci admin disimpan")
            }
        }
        d.show()
    }

    private fun addAccess(role: Int) {
        val name = IosUi.field(this, "Nama (mis. Ibu)")
        val key = numField("Kunci (${Auth.MIN_DIGITS}–${Auth.MAX_DIGITS} digit angka)")
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(name, lp(MATCH, WRAP))
            addView(key, lp(MATCH, WRAP, 8))
        }
        val d = IosDialog(this)
            .title(if (role == Auth.LIVE) "Akses hanya live" else "Akses live + rekaman")
            .content(box)
            .button("Batal", IosUi.CANCEL)
        d.button("Simpan", IosUi.BOLD, dismiss = false) {
            val n = name.text.toString().trim().ifEmpty { "Anggota" }
            val k = key.text.toString().trim()
            val err = Auth.add(this, n, role, k)
            if (err != null) {
                d.setError(err)
            } else {
                d.dismiss()
                refresh()
                IosUi.toast(this, "Akses $n disimpan. Berikan kunci ini ke $n.", true)
            }
        }
        d.show()
    }

    private fun revokeDialog() {
        val l = Auth.list(this)
        if (l.isEmpty()) { IosUi.toast(this, "Belum ada akses keluarga"); return }
        val names = l.map { it.first + if (it.second == Auth.LIVE) " (live)" else " (live+rekaman)" }
        IosDialog(this)
            .title("Cabut akses siapa?")
            .items(names) { i -> Auth.remove(this, l[i].third); refresh() }
            .button("Cabut semua", IosUi.DESTRUCTIVE) { Auth.removeAll(this); refresh() }
            .button("Batal", IosUi.CANCEL)
            .show()
    }

    private fun ntfyDialog() {
        val sp = CamSettings.prefs(this)
        val et = IosUi.field(this, "topik rahasia (min. 8 huruf)", InputType.TYPE_CLASS_TEXT, CamSettings.ntfy(this))
        val box = LinearLayout(this).apply { addView(et, lp(MATCH, WRAP)) }
        IosDialog(this)
            .title("Topik ntfy")
            .message("Pasang aplikasi ntfy di HP keluarga lalu berlangganan topik ini. Kosongkan untuk mematikan. Siapa pun yang tahu topiknya bisa membaca notifikasi, jadi jangan dibagikan sembarangan.")
            .content(box)
            .button("Batal", IosUi.CANCEL)
            .button("Simpan", IosUi.BOLD) { sp.edit().putString(CamSettings.K_NTFY, et.text.toString().trim()).apply() }
            .show()
    }

    private fun askBatteryOpt() {
        val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName)) return
        try {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
        }
    }

    private fun refresh() {
        val on = CameraService.running
        val pmr = getSystemService(POWER_SERVICE) as android.os.PowerManager
        battBtn.visibility = if (pmr.isIgnoringBatteryOptimizations(packageName)) View.GONE else View.VISIBLE
        ntfyHint.visibility = if (CamSettings.ntfy(this).length >= 8) View.GONE else View.VISIBLE
        dot.background = rounded(if (on) GREEN else RED, 6)
        statusT.text = if (on) "Kamera aktif" else "Kamera mati"
        val ip = localIp()
        val vip = vpnIp()
        addrT.text = (if (ip != null) "Alamat: $ip:${CameraService.PORT}" else "Tidak terhubung WiFi") +
            (if (vip != null) "\nDari luar rumah (Tailscale): $vip" else "")
        val sc = ScreenService.active
        screenT.text = if (sc) "Layar: siap dibagikan" else "Layar: belum diizinkan"
        screenBtn.visibility = if (sc) View.GONE else View.VISIBLE
        storT.text = Recorder(this) { }.storageInfo()
        accessT.text = "Kunci admin: " + Auth.adminKey(this).ifEmpty { "belum diatur" } + "\nAkses keluarga: " + Auth.list(this).size + " orang"
        toggle.text = if (on) "Hentikan Kamera" else "Mulai Kamera"
        toggle.background = rounded(if (on) RED_BG else BLUE, 16)
        toggle.setTextColor(if (on) RED else WHITE)
    }
}
