package com.wans.cctv.camera

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Collections

private val BG = Color.BLACK
private val CARD = Color.parseColor("#1C1C1E")
private val GRAY = Color.parseColor("#8E8E93")
private val WHITE = Color.WHITE
private val BLUE = Color.parseColor("#0A84FF")
private val GREEN = Color.parseColor("#30D158")
private val RED = Color.parseColor("#FF453A")
private val RED_BG = Color.parseColor("#3A1E1E")
private val SEG_BG = Color.parseColor("#3A3A3C")
private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

private fun localIp(): String? {
    try {
        for (ni in Collections.list(NetworkInterface.getNetworkInterfaces() ?: return null)) {
            if (!ni.isUp || ni.isLoopback) continue
            for (a in Collections.list(ni.inetAddresses)) {
                if (a is Inet4Address && a.isSiteLocalAddress) return a.hostAddress
            }
        }
    } catch (e: Exception) {
    }
    return null
}

class MainActivity : ComponentActivity() {

    private val h = Handler(Looper.getMainLooper())
    private lateinit var dot: View
    private lateinit var statusT: TextView
    private lateinit var addrT: TextView
    private lateinit var toggle: TextView
    private lateinit var screenT: TextView
    private lateinit var screenBtn: TextView
    private var askedScreen = false
    private lateinit var storT: TextView
    private lateinit var accessT: TextView

    private val perm = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        startCam()
    }

    private val screenReq = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val d = r.data
        if (r.resultCode == Activity.RESULT_OK && d != null) {
            val i = Intent(this, ScreenService::class.java)
                .putExtra("code", r.resultCode)
                .putExtra("data", d)
            ContextCompat.startForegroundService(this, i)
        }
        h.postDelayed({ refresh() }, 600)
    }

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            h.postDelayed(this, 1000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(c: Int, r: Int) = GradientDrawable().apply {
        setColor(c)
        cornerRadius = dp(r).toFloat()
    }

    private fun tv(t: String, sp: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = t
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(color)
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    }

    private fun pill(t: String, fill: Int, fg: Int): TextView = tv(t, 17f, fg, true).apply {
        gravity = Gravity.CENTER
        background = rounded(fill, 16)
        setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_DOWN) v.alpha = 0.6f
            else if (e.action == MotionEvent.ACTION_UP || e.action == MotionEvent.ACTION_CANCEL) v.alpha = 1f
            false
        }
    }

    private fun lp(w: Int, hh: Int, top: Int = 0) = LinearLayout.LayoutParams(w, hh).apply { topMargin = dp(top) }

    /** Pilihan segmen ala iOS: satu baris tombol, yang dipilih berwarna biru. */
    private fun seg(title: String, labels: List<String>, selected: Int, onPick: (Int) -> Unit): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(tv(title, 14f, GRAY, false))
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(SEG_BG, 12)
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }
        val items = mutableListOf<TextView>()
        fun paint(sel: Int) {
            items.forEachIndexed { i, t ->
                t.background = rounded(if (i == sel) BLUE else Color.TRANSPARENT, 10)
            }
        }
        labels.forEachIndexed { i, label ->
            val t = tv(label, 15f, WHITE, true).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(10), 0, dp(10))
                setOnClickListener {
                    paint(i)
                    onPick(i)
                }
            }
            items.add(t)
            row.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        paint(selected)
        box.addView(row, lp(MATCH, WRAP, 6))
        return box
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(72), dp(24), dp(32))
        }
        col.addView(tv("Kamera", 34f, WHITE, true))
        col.addView(tv("HP kamera • biarkan tetap menyala", 15f, GRAY, false), lp(WRAP, WRAP, 2))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(CARD, 20)
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        dot = View(this)
        row.addView(dot, LinearLayout.LayoutParams(dp(12), dp(12)))
        statusT = tv("Memulai…", 17f, WHITE, true)
        row.addView(statusT, lp(WRAP, WRAP).apply { leftMargin = dp(12) })
        card.addView(row, lp(MATCH, WRAP))
        addrT = tv("", 14f, GRAY, false)
        card.addView(addrT, lp(WRAP, WRAP, 10))
        screenT = tv("", 14f, GRAY, false)
        card.addView(screenT, lp(WRAP, WRAP, 4))
        col.addView(card, lp(MATCH, WRAP, 28))

        val sp = CamSettings.prefs(this)
        val cfg = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(CARD, 20)
        }
        cfg.addView(tv("Kualitas video", 17f, WHITE, true))
        cfg.addView(tv("Makin rendah, makin hemat data dan ringan. Berlaku langsung.", 13f, GRAY, false), lp(WRAP, WRAP, 2))
        cfg.addView(
            seg("Resolusi", listOf("240p", "360p", "480p"), CamSettings.RES.indexOf(CamSettings.res(this))) { i ->
                sp.edit().putInt(CamSettings.K_RES, CamSettings.RES[i]).apply()
            },
            lp(MATCH, WRAP, 16)
        )
        cfg.addView(
            seg("Kecepatan gambar", listOf("5 fps", "10 fps", "15 fps"), CamSettings.FPS.indexOf(CamSettings.fps(this))) { i ->
                sp.edit().putInt(CamSettings.K_FPS, CamSettings.FPS[i]).apply()
            },
            lp(MATCH, WRAP, 14)
        )
        cfg.addView(
            seg("Kualitas gambar", listOf("Hemat", "Sedang", "Tinggi"), CamSettings.QUAL.indexOf(CamSettings.quality(this))) { i ->
                sp.edit().putInt(CamSettings.K_Q, CamSettings.QUAL[i]).apply()
            },
            lp(MATCH, WRAP, 14)
        )
        col.addView(cfg, lp(MATCH, WRAP, 16))

        // ----- Rekaman -----
        val rc = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(CARD, 20)
        }
        rc.addView(tv("Rekaman", 17f, WHITE, true))
        storT = tv("", 13f, GRAY, false)
        rc.addView(storT, lp(WRAP, WRAP, 2))
        rc.addView(seg("Mode rekam", listOf("Mati", "Gerak", "24 jam"), CamSettings.rec(this)) { i ->
            sp.edit().putInt(CamSettings.K_REC, i).apply()
        }, lp(MATCH, WRAP, 14))
        rc.addView(seg("Lama riwayat (loop, yang lama otomatis dihapus)", listOf("1 hari", "3 hari", "7 hari"),
            CamSettings.DAYS.indexOf(CamSettings.days(this))) { i ->
            sp.edit().putInt(CamSettings.K_DAYS, CamSettings.DAYS[i]).apply()
        }, lp(MATCH, WRAP, 14))
        rc.addView(seg("Kepekaan gerak", listOf("Rendah", "Sedang", "Tinggi"), CamSettings.sens(this)) { i ->
            sp.edit().putInt(CamSettings.K_SENS, i).apply()
        }, lp(MATCH, WRAP, 14))
        val ntfyBtn = pill("Notifikasi gerak (ntfy)", CARD, BLUE).apply { textSize = 15f }
        ntfyBtn.setOnClickListener { ntfyDialog() }
        rc.addView(ntfyBtn, lp(MATCH, dp(50), 12))
        col.addView(rc, lp(MATCH, WRAP, 16))

        // ----- Akses & keamanan -----
        val ac = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(CARD, 20)
        }
        ac.addView(tv("Akses keluarga & keamanan", 17f, WHITE, true))
        accessT = tv("", 13f, GRAY, false)
        ac.addView(accessT, lp(WRAP, WRAP, 6))
        val addLive = pill("Tambah akses: hanya live", CARD, BLUE).apply { textSize = 15f }
        addLive.setOnClickListener { addAccess(Auth.LIVE) }
        ac.addView(addLive, lp(MATCH, dp(50), 12))
        val addFull = pill("Tambah akses: live + rekaman", CARD, BLUE).apply { textSize = 15f }
        addFull.setOnClickListener { addAccess(Auth.FULL) }
        ac.addView(addFull, lp(MATCH, dp(50), 8))
        val revoke = pill("Cabut / hapus akses", CARD, RED).apply { textSize = 15f }
        revoke.setOnClickListener { revokeDialog() }
        ac.addView(revoke, lp(MATCH, dp(50), 8))
        val reset = pill("Ganti kunci admin", CARD, RED).apply { textSize = 15f }
        reset.setOnClickListener {
            Auth.resetAdmin(this)
            refresh()
            Toast.makeText(this, "Kunci admin diganti. Masukkan kunci baru di HP monitor.", Toast.LENGTH_LONG).show()
        }
        ac.addView(reset, lp(MATCH, dp(50), 8))
        col.addView(ac, lp(MATCH, WRAP, 16))

        toggle = pill("Mulai Kamera", BLUE, WHITE)
        toggle.setOnClickListener {
            if (CameraService.running) {
                stopService(Intent(this, CameraService::class.java))
                stopService(Intent(this, ScreenService::class.java))
            } else {
                askAndStart()
            }
            h.postDelayed({ refresh() }, 300)
        }
        col.addView(toggle, lp(MATCH, dp(58), 16))

        val battery = pill("Izinkan jalan di latar belakang", CARD, BLUE).apply { textSize = 15f }
        battery.setOnClickListener {
            try {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                try {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                } catch (x: Exception) {
                }
            }
        }
        col.addView(battery, lp(MATCH, dp(50), 12))

        screenBtn = pill("Izinkan bagikan layar", CARD, BLUE).apply { textSize = 15f }
        screenBtn.setOnClickListener { askScreen() }
        col.addView(screenBtn, lp(MATCH, dp(50), 12))

        val touchBtn = pill("Aktifkan kontrol sentuh jarak jauh", CARD, BLUE).apply { textSize = 15f }
        touchBtn.setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } catch (e: Exception) {
            }
        }
        col.addView(touchBtn, lp(MATCH, dp(50), 12))

        val settingsBtn = pill("Pengaturan izin aplikasi (pop-up Vivo)", CARD, BLUE).apply { textSize = 15f }
        settingsBtn.setOnClickListener {
            try {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
            }
        }
        col.addView(settingsBtn, lp(MATCH, dp(50), 12))

        val tip = tv(
            "Buka aplikasi ini sekali setiap HP selesai restart. Setelah kamera aktif, " +
                "aplikasi boleh ditutup — kamera tetap jalan di latar belakang. " +
                "Pasang HP di tempat yang aman dan colok charger. " +
                "Untuk melihat layar dari monitor, tekan \"Izinkan bagikan layar\" lalu \"Mulai sekarang\". " +
                "Di Vivo, nyalakan juga izin pop-up dari latar belakang di pengaturan aplikasi.",
            13f, GRAY, false
        )
        col.addView(tip, lp(MATCH, WRAP, 22))

        val sv = ScrollView(this).apply {
            setBackgroundColor(BG)
            isFillViewport = true
            addView(col)
        }
        setContentView(sv)
        askAndStart()
    }

    override fun onResume() {
        super.onResume()
        h.post(tick)
    }

    override fun onPause() {
        super.onPause()
        h.removeCallbacks(tick)
    }

    private fun askAndStart() {
        val need = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        perm.launch(need.toTypedArray())
    }

    private fun startCam() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            if (!CameraService.running) {
                ContextCompat.startForegroundService(this, Intent(this, CameraService::class.java))
                if (!ScreenService.active && !askedScreen) {
                    askedScreen = true
                    askScreen()
                }
            }
        } else {
            statusT.text = "Izin kamera ditolak"
        }
        h.postDelayed({ refresh() }, 400)
    }

    private fun askScreen() {
        try {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            screenReq.launch(mpm.createScreenCaptureIntent())
        } catch (e: Exception) {
            screenT.text = "Layar: tidak bisa diminta izin"
        }
    }

    private fun copy(label: String, text: String) {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText(label, text))
    }

    private fun addAccess(role: Int) {
        val et = EditText(this).apply { hint = "Nama (mis. Ibu)"; setPadding(dp(24), dp(16), dp(24), dp(16)) }
        AlertDialog.Builder(this)
            .setTitle(if (role == Auth.LIVE) "Akses hanya live" else "Akses live + rekaman")
            .setView(et)
            .setPositiveButton("Buat") { _, _ ->
                val name = et.text.toString().trim().ifEmpty { "Anggota" }
                val t = Auth.add(this, name, role)
                copy("kunci", t)
                AlertDialog.Builder(this).setTitle("Kunci untuk $name")
                    .setMessage("$t\n\nSudah disalin. Kirim lewat pesan pribadi, lalu masukkan di aplikasi Monitor (menu IP kamera). Kunci ini hanya untuk $name; cabut kapan saja.")
                    .setPositiveButton("OK", null).show()
                refresh()
            }
            .setNegativeButton("Batal", null).show()
    }

    private fun revokeDialog() {
        val l = Auth.list(this)
        if (l.isEmpty()) { Toast.makeText(this, "Belum ada akses keluarga", Toast.LENGTH_SHORT).show(); return }
        val names = l.map { it.first + if (it.second == Auth.LIVE) " (live)" else " (live+rekaman)" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Cabut akses siapa?")
            .setItems(names) { _, i -> Auth.remove(this, l[i].third); refresh() }
            .setNeutralButton("Cabut semua") { _, _ -> Auth.removeAll(this); refresh() }
            .setNegativeButton("Batal", null).show()
    }

    private fun ntfyDialog() {
        val sp = CamSettings.prefs(this)
        val et = EditText(this).apply {
            hint = "topik rahasia (min. 8 huruf)"
            inputType = InputType.TYPE_CLASS_TEXT
            setText(CamSettings.ntfy(this@MainActivity).ifEmpty { "cctv-" + Auth.adminKey(this@MainActivity).lowercase().take(10) })
            setPadding(dp(24), dp(16), dp(24), dp(16))
        }
        AlertDialog.Builder(this).setTitle("Topik ntfy")
            .setMessage("Pasang aplikasi ntfy di HP keluarga lalu berlangganan topik ini. Kosongkan untuk mematikan. Siapa pun yang tahu topiknya bisa membaca notifikasi, jadi jangan dibagikan sembarangan.")
            .setView(et)
            .setPositiveButton("Simpan") { _, _ -> sp.edit().putString(CamSettings.K_NTFY, et.text.toString().trim()).apply() }
            .setNegativeButton("Batal", null).show()
    }

    private fun refresh() {
        val on = CameraService.running
        dot.background = rounded(if (on) GREEN else RED, 6)
        statusT.text = if (on) "Kamera aktif" else "Kamera mati"
        val ip = localIp()
        addrT.text = if (ip != null) "Alamat: $ip:${CameraService.PORT}" else "Tidak terhubung WiFi"
        val sc = ScreenService.active
        screenT.text = if (sc) "Layar: siap dibagikan" else "Layar: belum diizinkan"
        screenBtn.text = if (sc) "Layar sudah dibagikan ✓" else "Izinkan bagikan layar"
        storT.text = Recorder(this) { }.storageInfo()
        accessT.text = "Kunci admin: " + Auth.adminKey(this) + "\nAkses keluarga: " + Auth.list(this).size + " orang" +
            "\nPlayback: http://" + (ip ?: "ALAMAT") + ":" + CameraService.PORT + "/playback?k=KUNCI"
        toggle.text = if (on) "Hentikan Kamera" else "Mulai Kamera"
        toggle.background = rounded(if (on) RED_BG else BLUE, 16)
        toggle.setTextColor(if (on) RED else WHITE)
    }
}
